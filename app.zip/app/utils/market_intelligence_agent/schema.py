from typing import Dict, List, Callable, Annotated, Optional
from pydantic import BaseModel, Field

# class Citation(BaseModel):
#     """Citation model containing only a URL"""
#     url: str = Field(description="URL link for the citation")

class Citation(BaseModel):
    """Structured citation metadata for research signals"""

    url: str = Field(
        description="Direct URL link for the citation source"
    )

    title: str = Field(
        description="Title or headline of the cited source"
    )

    description: Optional[str] = Field(
        default=None,
        description="Short explanation of what this source covers or supports"
    )

    source_name: str = Field(
        description="Publisher or organization providing the source"
    )

    published_date: Optional[str] = Field(
        default=None,
        description="Publication date (ISO format preferred)"
    )


class ResearchSignals(BaseModel):
    facts: List[str] = Field(default_factory=list)
    statistics: List[str] = Field(default_factory=list)
    trends: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    opportunities: List[str] = Field(default_factory=list)
    citations: List[Citation] = Field(
        default_factory=list,
        description="List of citation URLs"
    )

def merge_tool_results(
    left: Dict[str, Dict[str, ResearchSignals]],
    right: Dict[str, Dict[str, ResearchSignals]],
) -> Dict[str, Dict[str, ResearchSignals]]:
    merged = dict(left)
    for area, tools in right.items():
        merged.setdefault(area, {})
        merged[area].update(tools)
    return merged


class GraphState(BaseModel):
    input: dict

    tool_results: Annotated[
        Dict[str, Dict[str, ResearchSignals]],
        merge_tool_results
    ] = Field(default_factory=dict)
