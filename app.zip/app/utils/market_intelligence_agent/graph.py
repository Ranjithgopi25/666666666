import os
import ssl
import urllib3
import logging

# =========================================================
# SSL / REQUEST PATCHING
# =========================================================
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""

ssl._create_default_https_context = ssl._create_unverified_context

import requests
from requests.adapters import HTTPAdapter

class NoSSLVerifyAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        kwargs["cert_reqs"] = ssl.CERT_NONE
        kwargs["assert_hostname"] = False
        return super().init_poolmanager(*args, **kwargs)

_original_session_init = requests.Session.__init__

def patched_session_init(self, *args, **kwargs):
    _original_session_init(self, *args, **kwargs)
    self.verify = False
    self.mount("https://", NoSSLVerifyAdapter())
    self.mount("http://", NoSSLVerifyAdapter())

requests.Session.__init__ = patched_session_init

# =========================================================
# IMPORTS
# =========================================================
from typing import List, Callable
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langchain.agents import create_agent

from langchain_core.messages import (
    SystemMessage,
    HumanMessage,
    BaseMessage,
    AIMessage,
    ToolMessage,
)

from fastapi.encoders import jsonable_encoder
from tavily import TavilyClient

from app.core.deps import get_llm_client_agent
from app.core.config import config

from .prompt import PROPRIETARY_AGENT_PROMPT
from .schema import ResearchSignals, GraphState
from .market_intelligence import get_market
from .tools.proprietary_tools import PROPRIETARY_TOOLS_MAP

logger = logging.getLogger(__name__)

# =========================================================
# 1. CLIENTS
# =========================================================
llm = get_llm_client_agent()
tavily = TavilyClient(api_key=config.TAVILY_API_KEY)

# =========================================================
# 2. SYSTEM PROMPT
# =========================================================
SYSTEM_PROMPT = """
You are a market intelligence research agent.

TASK:
Extract STRUCTURED market intelligence signals.

RULES:
- Output MUST follow the schema exactly
- No prose or explanations
- Best-effort, factual, professional intelligence
"""

# =========================================================
# 3. LLM NORMALIZER
# =========================================================
def call_llm(prompt: str) -> ResearchSignals:
    structured_llm = llm.with_structured_output(ResearchSignals)
    return structured_llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ]
    )

# =========================================================
# 4. PROMPT BUILDERS
# =========================================================
def pwc_document_prompt(input_data: dict) -> str:
    pwc = input_data["pwc_content"]
    return f"""
Analyze the following internal document and extract market intelligence.

DOCUMENT:
{pwc["supportingDoc"]}

INSTRUCTIONS:
{pwc.get("supportingDoc_instructions", "")}
"""

def generic_tool_prompt(tool_name: str, input_data: dict) -> str:
    return f"""
SOURCE: {tool_name}
TOPIC: {input_data.get("research_topics")}
GUIDELINES: {input_data.get("research_guidelines")}
"""

# =========================================================
# 5. GENERIC LLM NODE
# =========================================================
def make_llm_tool_node(area: str, tool_name: str, prompt_builder: Callable):
    def node(state: GraphState) -> dict:
        signals = call_llm(prompt_builder(state.input))
        return {"tool_results": {area: {tool_name: signals}}}
    return node

# =========================================================
# 6. AGENT FACTORY (TOOL-NATIVE)
# =========================================================
class AgentState(TypedDict):
    messages: List[BaseMessage]

# =========================================================
# 7. PROPRIETARY TOOLS NODE
# =========================================================
def proprietary_tools_node(state: GraphState) -> dict:
    query = state.input.get("research_topics", "")
    guidelines = state.input.get("research_guidelines", "")
    proprietary_cfg = state.input.get("proprietary", {})

    selected_sources = proprietary_cfg.get("sources", [])

    # Conditional Azure AI Search enforcement
    AZURE_SEARCH_TRIGGERS = {
        "pwc_industry_edge",
        "pwc_insights",
        "sb_journal",
    }

    if AZURE_SEARCH_TRIGGERS.intersection(selected_sources):
        if "azure_ai_search" not in selected_sources:
            selected_sources.append("azure_ai_search")

    tools = [
        PROPRIETARY_TOOLS_MAP[src]
        for src in set(selected_sources)
        if src in PROPRIETARY_TOOLS_MAP
    ]

    if not tools:
        return {
            "tool_results": {
                "proprietary": {
                    "error": ResearchSignals(citations=["No valid proprietary tools"])
                }
            }
        }

    agent = create_agent(
        model=llm,
        tools=tools,
        system_prompt=PROPRIETARY_AGENT_PROMPT.format(
            research_topics=query,
            research_guidelines=guidelines,
            selected_sources=", ".join(selected_sources),
        ),
    )

    result = agent.invoke({
        "messages": [HumanMessage(content=query)]
    })

    aggregated_text = []

    for msg in result["messages"]:
        if isinstance(msg, ToolMessage):
            aggregated_text.append(f"[SOURCE: {msg.name}]\n{msg.content}")
        elif isinstance(msg, AIMessage) and isinstance(msg.content, str):
            aggregated_text.append(msg.content)

    raw_research = "\n".join(aggregated_text)

    signals = call_llm(f"""
Analyze the following proprietary research output and extract structured market intelligence.

GUIDELINES:
{guidelines}

CONTENT:
{raw_research}
""")

    return {
        "tool_results": {
            "proprietary": {
                src: signals for src in selected_sources
            }
        }
    }

# =========================================================
# 8. EXTERNAL RESEARCH (TAVILY)
# =========================================================
def tavily_tool_node(state: GraphState) -> dict:
    query = state.input.get("research_topics")
    guidelines = state.input.get("research_guidelines", "")

    response = tavily.search(
        query=query,
        search_depth="advanced",
        max_results=5,
    )

    contents = [
        r.get("content", "")
        for r in response.get("results", [])
        if r.get("content")
    ]

    prompt = f"""
Analyze the following external web research content.

GUIDELINES:
{guidelines}

CONTENT:
{chr(10).join(contents)}
"""

    signals = call_llm(prompt)

    return {"tool_results": {"externalResearch": {"tavily": signals}}}

# =========================================================
# 9. ROUTER
# =========================================================
def router_node(state: GraphState) -> dict:
    return {}

def router_decision(state: GraphState):
    routes = []

    if state.input.get("pwc_content", {}).get("isSelected"):
        routes.append("pwc_document")

    if state.input.get("proprietary", {}).get("isSelected"):
        routes.append("proprietary")

    if state.input.get("externalResearch", {}).get("isSelected"):
        routes.append("externalResearch")

    return routes

# =========================================================
# 10. BUILD GRAPH
# =========================================================
def build_graph():
    graph = StateGraph(GraphState)

    graph.add_node("router", router_node)
    graph.add_node(
        "pwc_document",
        make_llm_tool_node("pwc_content", "document_llm", pwc_document_prompt),
    )
    graph.add_node("proprietary", proprietary_tools_node)
    graph.add_node("externalResearch", tavily_tool_node)

    graph.set_entry_point("router")

    graph.add_conditional_edges(
        "router",
        router_decision,
        {
            "pwc_document": "pwc_document",
            "proprietary": "proprietary",
            "externalResearch": "externalResearch",
        },
    )

    graph.add_edge("pwc_document", END)
    graph.add_edge("proprietary", END)
    graph.add_edge("externalResearch", END)

    return graph.compile()

# =========================================================
# 11. ENTRY
# =========================================================
graph = build_graph()

def get_market_insights(input_data: dict) -> dict:
    result = graph.invoke(GraphState(input=input_data))
    return jsonable_encoder(result.get("tool_results", {}))

if __name__ == "__main__":
    input_data = get_market()
    output = get_market_insights(input_data)
    print(output)
