from langchain_core.tools import tool
from typing import List
import logging

logger = logging.getLogger(__name__)


@tool("Factiva")
def search_factiva(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Factiva]")
    return f"Factiva data for: {query}\nGuidelines: {guidelines}"


@tool("S&P Global - Capital IQ Xpressfeed")
def search_capitaliq_xpressfeed(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Capital IQ Xpressfeed]")
    return f"Capital IQ Xpressfeed data for: {query}\nGuidelines: {guidelines}"


@tool("S&P Global - Connect")
def search_sp_global_connect(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: S&P Global Connect]")
    return f"S&P Global Connect data for: {query}\nGuidelines: {guidelines}"


@tool("BoardEx")
def search_boardex(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: BoardEx]")
    return f"BoardEx data for: {query}\nGuidelines: {guidelines}"


@tool("Audit Analytics")
def search_audit_analytics(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Audit Analytics]")
    return f"Audit Analytics data for: {query}\nGuidelines: {guidelines}"


@tool("S&P Global - SNL Insurance")
def search_snl_insurance(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: SNL Insurance]")
    return f"SNL Insurance data for: {query}\nGuidelines: {guidelines}"


@tool("Claritas")
def search_claritas(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Claritas]")
    return f"Claritas data for: {query}\nGuidelines: {guidelines}"


@tool("Equifax")
def search_equifax(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Equifax]")
    return f"Equifax data for: {query}\nGuidelines: {guidelines}"


@tool("Equifax IXI")
def search_equifax_ixi(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Equifax IXI]")
    return f"Equifax IXI data for: {query}\nGuidelines: {guidelines}"


@tool("Definitive Healthcare Provider Database")
def search_definitive_healthcare(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Definitive Healthcare]")
    return f"Definitive Healthcare data for: {query}\nGuidelines: {guidelines}"


@tool("Sg2 Health Care Intelligence")
def search_sg2_healthcare(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: SG2 Healthcare]")
    return f"SG2 Healthcare data for: {query}\nGuidelines: {guidelines}"


@tool("Strata Market Insights")
def search_strata_market_insights(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Strata Market Insights]")
    return f"Strata Market Insights data for: {query}\nGuidelines: {guidelines}"


@tool("Global Data (Retail)")
def search_globaldata_retail(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: GlobalData Retail]")
    return f"GlobalData Retail data for: {query}\nGuidelines: {guidelines}"


@tool("Technology Business Review")
def search_technology_business_review(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: Technology Business Review]")
    return f"Technology Business Review data for: {query}\nGuidelines: {guidelines}"


@tool("IBIS World")
def search_ibis_world(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: IBIS World]")
    return f"IBIS World industry data for: {query}\nGuidelines: {guidelines}"


@tool("CFRA Industry Surveys")
def search_cfra_industry_surveys(query: str, guidelines: str = "") -> str:
    logger.info("[Tool: CFRA Industry Surveys]")
    return f"CFRA Industry Surveys data for: {query}\nGuidelines: {guidelines}"

THIRD_PARTY_TOOLS_MAP = {
    "Factiva": search_factiva,
    "S&P Global- Capital IQ Xpressfeed": search_capitaliq_xpressfeed,
    "S&P Global- Connect": search_sp_global_connect,
    "BoardEx": search_boardex,
    "Audit Analytics": search_audit_analytics,
    "S&P Global- SNL Insurance": search_snl_insurance,
    "Claritas": search_claritas,
    "Equifax": search_equifax,
    "Equifax IXI": search_equifax_ixi,
    "Definitive Healthcare Provider Database": search_definitive_healthcare,
    "Sg2 Health Care Intelligence": search_sg2_healthcare,
    "Strata Market Insights": search_strata_market_insights,
    "Global Data(Retail)": search_globaldata_retail,
    "Technology Business Review": search_technology_business_review,
    "IBIS World": search_ibis_world,
    "CFRA Industry Surveys": search_cfra_industry_surveys,
}

