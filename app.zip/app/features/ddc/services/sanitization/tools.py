import re
import difflib
import functools
import time
from datetime import datetime
from dataclasses import dataclass
from typing import Optional
from pydantic import BaseModel

# ---------------------------
# CONSTANTS
# ---------------------------

SUPPORTED_MIME_TYPES = {
    "image/png",
    "image/jpeg",
    "image/jpg",
    "image/webp",
}

_XML_INVALID_CHARS = re.compile(
    r"[\x00-\x08\x0B\x0C\x0E-\x1F]"
)

# ---------------------------
# MODELS
# ---------------------------

@dataclass
class LogoClassificationResult:
    owner: str | None
    logo_text: str | None
    confidence: float


class LogoDetectionResult(BaseModel):
    is_logo: bool
    logo_text: Optional[str] = None

# ---------------------------
# HELPERS
# ---------------------------
def normalize_client_identifiers(raw) -> dict:
    """
    Accepts:
      - "Spire"
      - "Spire, Infosys, TCS"
      - {"client_names": [...]}

    Returns:
      {"client_names": [..]}  (always)
    """
    if raw is None:
        return {}

    # Case 1: already correct
    if isinstance(raw, dict):
        names = raw.get("client_names", [])
        return {
            "client_names": [
                n.strip()
                for n in names
                if isinstance(n, str) and n.strip()
            ]
        }

    # Case 2: comma-separated string
    if isinstance(raw, str):
        parts = [
            p.strip()
            for p in raw.split(",")
            if p.strip()
        ]
        return {"client_names": parts} if parts else {}

    # Anything else → ignore
    return {}

def classify_logo_owner( logo_text: str, clients: list, competitors: Optional[list]):
        if not logo_text:
            return "other"

        clients = clients or []
        competitors = competitors or []

        logo_text_lower = logo_text.lower()

        # First, check clients
        for client in clients:
            client_lower = client.lower()
            # Exact or partial match
            if client_lower in logo_text_lower or logo_text_lower in client_lower:
                return "client"
            # Optional: fuzzy matching
            if difflib.SequenceMatcher(None, logo_text_lower, client_lower).ratio() > 0.6:
                return "client"

        # Then check competitors
        for competitor in competitors:
            competitor_lower = competitor.lower()
            if competitor_lower in logo_text_lower or logo_text_lower in competitor_lower:
                return "competitor"
            if difflib.SequenceMatcher(None, logo_text_lower, competitor_lower).ratio() > 0.6:
                return "competitor"

        return "other"


def sanitize_for_xml(text: str) -> str:
    if not text:
        return ""
    return _XML_INVALID_CHARS.sub("", text)




def timed_node(node_name: str):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(state):
            start = time.perf_counter()
            start_ts = datetime.utcnow().isoformat()

            result = func(state)

            duration = time.perf_counter() - start
            end_ts = datetime.utcnow().isoformat()

            stats = state["sanitizer"].sanitization_stats
            stats[f"{node_name}_start_ts"] = start_ts
            stats[f"{node_name}_end_ts"] = end_ts
            stats[f"{node_name}_duration_sec"] = round(duration, 4)

            # logger.info(
            #     f"[NODE] {node_name} | "
            #     f"start={start_ts} | "
            #     f"end={end_ts} | "
            #     f"duration={duration:.4f}s"
            # )

            return result
        return wrapper
    return decorator