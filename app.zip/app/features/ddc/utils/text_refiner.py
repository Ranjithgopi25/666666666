import os
import io
import docx
from pypdf import PdfReader
from pptx import Presentation
from openai import AzureOpenAI
from typing import Optional
import pandas as pd
import logging
from io import BytesIO
from app.core.config import config

logger = logging.getLogger(__name__)

# Azure OpenAI client setup

client = AzureOpenAI(
    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
    api_key=config.AZURE_OPENAI_API_KEY,
    api_version=config.AZURE_OPENAI_API_VERSION
)


# ------------------------------
# 1. TEXT EXTRACTION HELPERS
# ------------------------------

def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    max_chars: Optional[int] = None
    """
    Extract text from PDF file.
    
    Args:
        pdf_bytes: PDF file content as bytes
        max_chars: Optional maximum characters limit (None = no limit, extracts all pages)
    
    Returns:
        Extracted text from all pages
    """
    try:
        if not pdf_bytes:
            logger.warning("Empty PDF file provided")
            return ""
        
        pdf_file = io.BytesIO(pdf_bytes)
        reader = PdfReader(pdf_file)
        text = ""
        total_pages = len(reader.pages)
        
        if total_pages == 0:
            logger.warning("PDF file has no pages")
            return ""
        
        # Extract text from ALL pages
        for page_num, page in enumerate(reader.pages, 1):
            try:
                page_text = page.extract_text()
                if page_text:
                    text += page_text
            except Exception as page_error:
                logger.warning(f"Error extracting text from page {page_num}: {page_error}")
                continue  # Continue with next page instead of failing
            
            # Only check limit if max_chars is specified
            if max_chars and len(text) >= max_chars:
                logger.warning(f"PDF text extraction reached max_chars limit ({max_chars}) at page {page_num}/{total_pages}")
                break
        
        # Apply truncation only if max_chars is specified
        if max_chars:
            text = text[:max_chars]
        
        logger.info(f"Extracted {len(text)} characters from {total_pages} PDF pages")
        return text
    except Exception as e:
        logger.error(f"Error extracting PDF text: {e}")
        raise


def extract_text_from_docx(file_bytes: bytes) -> str:
    doc = docx.Document(io.BytesIO(file_bytes))
    return "\n".join([para.text for para in doc.paragraphs]).strip()


def extract_text_from_txt(file_bytes: bytes) -> str:
    return file_bytes.decode("utf-8", errors="ignore").strip()


def extract_text_from_pptx(file_bytes: bytes) -> str:
    prs = Presentation(io.BytesIO(file_bytes))
    slides_text = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                slides_text.append(shape.text)
    return "\n".join(slides_text).strip()

def extract_text_from_xlsx(path):
    sheets = pd.read_excel(path, sheet_name=None)

    data_str = "".join(f"=== {name} ==={df.to_csv(index=False)}" for name, df in sheets.items())
    
    return data_str

def excel_bytes_to_string(xlsx_bytes: bytes) -> str:
    sheets = pd.read_excel(BytesIO(xlsx_bytes), sheet_name=None, engine="openpyxl")
    return "".join(f"=== {name} ===\n{df.to_csv(index=False)}" for name, df in sheets.items())

def extract_text_from_any(filename: str, file_bytes: bytes) -> str:
    ext = filename.lower()

    if ext.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)
    if ext.endswith(".docx"):
        return extract_text_from_docx(file_bytes)
    if ext.endswith(".txt"):
        return extract_text_from_txt(file_bytes)
    if ext.endswith(".pptx"):
        return extract_text_from_pptx(file_bytes)
    if ext.endswith(".xlsx"):
        return excel_bytes_to_string(file_bytes)    
        
    

    raise ValueError(f"Unsupported file type: {filename}")
    


# ------------------------------
# 2. LLM TEXT REFINER
# ------------------------------
#If there is chart data then extract that too and mention it clearly along with the data in the refined content.

def refine_text_for_slides(raw_text: str) -> str:
    """
    Sends extracted text to Azure OpenAI and returns
    a clean summary suitable as a PlusDocs prompt.
    """
    logger.info(f"raw text inside refine_text_for_slides {raw_text}")

    prompt = f"""
You are a slide content refiner.

The user has provided raw text from a document. Your job:

1. Identify the important topics, key points, and structure. 
2. Remove noise, redundant lines, formatting issues, repeated content, empty lines.
3. Don't miss out on any vital information including links and research content.

Raw text:
------------------
{raw_text}
------------------

Return the refined slide-ready content.
"""

    response = client.chat.completions.create(
        model= 'azure.gpt-5.1',
        messages=[
            {"role": "system", "content": "You refine messy text into structured slide content."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=30000
    )
    logger.info(f"llm response {response.choices[0].message.content.strip()}")
    return response.choices[0].message.content.strip()


def refine_text_for_placemat(raw_text: str, pageNum: str) -> str:
    """
    Sends extracted text to Azure OpenAI and returns
    a clean summary suitable as a PlusDocs prompt.
    """
    logger.info(f"raw text inside refine_text_for_placemat {raw_text} ,page: {pageNum}")
    
    ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
- Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
- Do NOT mention any report, survey, whitepaper, or study unless it exists.
- If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
- Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
- **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

    prompt = f"""
You are a placemat content refiner. You have to refine the content for {pageNum} page(s) of placemat.

The user has provided raw text from a document. Your job:
{ANTI_FABRICATION_RULES}
1. Identify the important topics, key points, and structure. 
2. Remove noise, redundant lines, formatting issues, repeated content, empty lines.
3. Don't miss out on any vital information including links and research content.

Raw text:
------------------
{raw_text}
------------------

Return the refined placemat-ready content.
"""

    response = client.chat.completions.create(
        model= 'azure.gpt-5.1',
        messages=[
            {"role": "system", "content": "You refine messy text into structured slide content."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=30000
    )
    logger.info(f"llm response for placemat: {response.choices[0].message.content.strip()}")
    return response.choices[0].message.content.strip()


def extract_page_count(customization: str) -> int:
    # Default fallback
    layout = None
    pages = None

    # Split by commas
    parts = [p.strip() for p in customization.split(",")]

    for part in parts:
        if part.lower().startswith("layout:"):
            layout = part.split(":", 1)[1].strip().lower()

        elif part.lower().startswith("pages:"):
            value = part.split(":", 1)[1].strip()
            #pages = value
            if value.isdigit():
               pages = int(value)

    # If "Pages" is explicitly given, always use it
    if pages:
        return pages

    # Otherwise infer from layout
    if layout == "two-page":
        return 2
    else:
        # default for one-page or unknown
        return 1


def extract_meaning_from_image(img_bytes: str, ext: str) -> str:
   

    prompt = """
    You area master of extracting data and details from images. Analyze this image and extract:
    - Key data points
    - All and actual Text content
    - Any charts, tables, or trends
    - Meaning/summary of what the image represents
    - Everything that is possible to extract from the image
    """
    print('came inside extract_meaning_from_image')
    response = client.chat.completions.create(
        model="azure.gpt-5.1",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/{ext};base64,{img_bytes}"
                        }
                    }
                ]
            }
        ],
        max_tokens=30000
    )
    
    return response.choices[0].message.content
