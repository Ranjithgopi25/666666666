from pydantic import BaseModel, Field
from typing import Optional, List

class WorkflowRequest(BaseModel):
    """Base request for workflow operations"""
    pass

class PPTUploadRequest(BaseModel):
    """Request for PPT upload workflows"""
    instructions: Optional[str] = Field(None, description="Additional instructions for processing")
    
class StreamingWorkflowRequest(BaseModel):
    """Request for streaming workflows"""
    prompt: str = Field(..., description="User prompt or query")
    context: Optional[str] = Field(None, description="Additional context")

class WorkflowResponse(BaseModel):
    """Base response for workflow operations"""
    success: bool
    message: str
    data: Optional[dict] = None

class ErrorResponse(BaseModel):
    """Error response"""
    error: str
    detail: Optional[str] = None
