import base64
from typing import TypedDict, Annotated, Sequence, Optional, Dict, Any, Literal, List
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langchain_openai import AzureChatOpenAI
from app.features.ddc.agents.tools import get_all_tools
import operator
import json
import logging
from app.features.ddc.agents.prompts import get_system_prompt
from app.core.config import config 

logger = logging.getLogger(__name__)

def _is_all_selected(state, tool_args) -> bool:
    """
    Determines whether user intent means 'ALL sanitization features'
    """
    # Check last user message
    for msg in reversed(state.get("messages", [])):
        if isinstance(msg, HumanMessage):
            if msg.content.strip().lower() in {"all", "everything", "complete", "full"}:
                return True
            break

    # Check if LLM passed 'all' explicitly
    services = tool_args.get("services", [])
    if isinstance(services, list):
        return any(str(s).lower() == "all" for s in services)

    return False


class AgentState(TypedDict):
    """State for the sanitization agent"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    conversation_id: Optional[str]
    collected_data: Dict[str, Any]
    file_data: Optional[bytes]
    file_name: Optional[str]
    custom_template_data: Optional[bytes]
    custom_template_name: Optional[str]
    conversation_history: List[Dict[str, str]]
    sanitized_once: bool   # 👈 ADD

class SanitizationAgent:
    """LangGraph agent for handling sanitization workflow conversationally with tool calling"""
    
    def __init__(self, llm_service, sanitization_service,ppt_service):
        self.llm_service = llm_service
        self.sanitization_service = sanitization_service
        self.ppt_service = ppt_service
        # Store tools - use original tools for binding to LLM
        self.tools = get_all_tools()
        
        # Use Azure OpenAI with config 
        self.llm = AzureChatOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
            temperature=0
        ).bind_tools(self.tools)
        
        # Build graph
        self.graph = self._build_graph()
    
    def _call_model(self, state: AgentState) -> AgentState:
        file_provided = state.get('file_data') is not None
        file_name = state.get('file_name', 'No file')
        conversation_history = state.get('conversation_history', [])
        system_prompt = get_system_prompt(file_provided, file_name, conversation_history, sanitized_once=state.get("sanitized_once", False))
        # system_prompt = get_system_prompt(file_provided, file_name)  # ✅ Use external prompt
        
        messages = [HumanMessage(content=system_prompt)] + state["messages"]
        response = self.llm.invoke(messages)
        return {"messages": [response]}
        
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow with tool calling"""
        workflow = StateGraph(AgentState)
        
        # Create tool node - we'll handle tool execution in a custom way
        workflow.add_node("agent", self._call_model)
        workflow.add_node("tools", self._execute_tools)
        
        # Define edges
        workflow.set_entry_point("agent")
        
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "tools",
                "end": END
            }
        )
        
        workflow.add_edge("tools", "agent")
        # workflow.add_edge("tools", END)
        
        return workflow.compile()
    
    async def _execute_tools(self, state: AgentState) -> AgentState:
        """Execute tool calls with access to services"""
        last_message = state["messages"][-1]

        logger.info(f'came inside _execute_tools')
        
        tool_messages = []
        
        for tool_call in last_message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"].copy()
            
            logger.info(f"[Agent] Executing tool: {tool_name}")
            
            try:
                # ✅ Dynamic injection based on tool
                if tool_name == "sanitize_presentation":

                    # 🛑 HARD GUARD: do NOT allow sanitization without a fresh file
                    # if not state.get("file_data"):
                    #     logger.warning(
                    #         "[SanitizationAgent] sanitize_presentation called without file_data"
                    #     )

                    #     return {
                    #         "messages": [
                    #             AIMessage(
                    #                 content=(
                    #                     "Please upload a document to start sanitization. "
                    #                     "A new sanitization session requires a new file."
                    #                 )
                    #             )
                    #         ]
                    #     }
                    if tool_name == "sanitize_presentation":

                        # 🛑 HARD GUARD: block reuse after sanitization
                        if state.get("sanitized_once") and not state.get("file_data"):
                            return {
                                "messages": [
                                    AIMessage(
                                        content=(
                                            "This sanitization session is complete. "
                                            "Please upload a new document to start a new sanitization."
                                        )
                                    )
                                ]
                            }

                        if not state.get("file_data"):
                            return {
                                "messages": [
                                    AIMessage(
                                        content=(
                                            "Please upload a document to start sanitization."
                                        )
                                    )
                                ]
                            }

                    # ✅ Only inject AFTER validation
                    tool_args["file_data"] = state.get("file_data")
                    tool_args["file_name"] = state.get("file_name")
                    tool_args["sanitization_service"] = self.sanitization_service
                    tool_args["llm_service"] = self.llm_service

                    # 🔥 FORCE "all" to mean ALL sanitization features
                    if _is_all_selected(state, tool_args):
                        logger.info("[SanitizationAgent] 'all' detected — enabling full sanitization")
                        tool_args["services"] = ["ALL"]

                                    

                elif tool_name == "generate_powerpoint_presentation":
                    tool_args["ppt_service"] = self.ppt_service
                
                
                tool_func = next((t for t in self.tools if t.name == tool_name), None)
                if tool_func:
                    result = await tool_func.ainvoke(tool_args)

                    if tool_name == "sanitize_presentation":
                        state["sanitized_once"] = True
                        state.setdefault("collected_data", {})
                        state["collected_data"]["last_sanitization_result"] = result
                else:
                    result = {"error": f"Unknown tool: {tool_name}"}

        
                # 🔒 SAFE TOOL MESSAGE (LLM ONLY)
                if isinstance(result, dict):
                    safe_result = result.copy()
                elif isinstance(result, str):
                    safe_result = {
                        "status": "success",
                        "presentation_id": result
                    }
                else:
                    safe_result = {
                        "status": "success",
                        "result": str(result)
                    }

                # Remove binary-like fields defensively
                safe_result.pop("file_data_base64", None)
                safe_result.pop("file_data_hex", None)
                safe_result.pop("file_bytes", None)
                safe_result.pop("binary", None)


                tool_message = ToolMessage(
                    content=json.dumps(safe_result),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)

                
            except Exception as e:
                logger.error(f"[Agent] Tool execution error: {e}", exc_info=True)
                tool_message = ToolMessage(
                    content=json.dumps({"error": str(e)}),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
        
        return {"messages": tool_messages}

    def _should_continue(self, state: AgentState) -> Literal["continue", "end"]:
        if state.get("_terminal"):
            return "end"

        last_message = state["messages"][-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "continue"

        return "end"
    
    

    async def process_message_sync(
        self, 
        message: str,
        # message: Optional[str] = None,
        conversation_id: Optional[str] = None,
        file_data: Optional[bytes] = None,
        file_name: Optional[str] = None,
        custom_template_data: Optional[bytes] = None,
        custom_template_name: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        
    ) -> Dict[str, Any]:
        """
        Process user message through the graph (non-streaming version)
        Returns dict with message, and optionally file_bytes + metadata
        """
        is_new_chat = conversation_history == [] or conversation_history is None

        if is_new_chat:
            logger.info("[SanitizationAgent] New chat detected — resetting state")

            file_data = None
            file_name = None
            custom_template_data = None
            custom_template_name = None

        # ✅ Handle file-only uploads (Quick Start safe)
        if not message or not message.strip():
            message = "User uploaded a document for sanitization."


        initial_state = {
            "messages": [HumanMessage(content=message)],
            "conversation_id": conversation_id,
            "collected_data": {},
            "file_data": file_data,
            "file_name": file_name,
            "custom_template_data": custom_template_data,
            "custom_template_name": custom_template_name,
            "conversation_history": conversation_history or [],
            "sanitized_once": False   # 👈 ADD
        }
        
        try:
            # final_state = self.graph.invoke(initial_state)
            final_state = await self.graph.ainvoke(initial_state)
            
            # Extract AI response
            ai_messages = [msg for msg in final_state["messages"] if isinstance(msg, AIMessage)]
            response_message = ai_messages[-1].content if ai_messages else "Processing..."
    
            # 🔹 Extract slide creation result from ToolMessage
            ppt_result = None

            for msg in final_state["messages"]:
                if isinstance(msg, ToolMessage):
                    try:
                        data = json.loads(msg.content)

                        if (
                            data.get("status") == "success"
                            and ("url" in data or "presentation_id" in data)
                        ):
                            ppt_result = data
                            break

                    except json.JSONDecodeError:
                        continue

            # ✅ Read FULL sanitization result from state (NOT ToolMessage)
            sanitization_result = (
                final_state
                .get("collected_data", {})
                .get("last_sanitization_result")
            )

            
            # ✅ Build result
            result = {
                "message": response_message,
                "conversation_id": conversation_id
            }
            
            # ✅ If sanitization completed, include file data
            if sanitization_result:
                file_bytes = bytes.fromhex(sanitization_result["file_data_base64"])
                
                result.update({
                    "file_bytes": file_bytes,
                    "file_name": sanitization_result["file_name"],
                    "file_size": sanitization_result["file_size"],
                    "summary": sanitization_result["summary"],
                    "plan": sanitization_result["plan"]
                })
           
            if ppt_result:
                result.update({
                    "file_url": ppt_result.get("url"),
                    "presentation_id": ppt_result.get("presentation_id"),
                    "file_name": ppt_result.get("file_name", "generated.pptx"),
                    "file_type": "pptx"
                })


            
            return result
                
        except Exception as e:
            logger.error(f"[Agent] Error: {e}", exc_info=True)
            return {
                "message": f"Error: {str(e)}",
                "conversation_id": conversation_id
            }