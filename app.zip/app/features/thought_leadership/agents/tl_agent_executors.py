"""
Workflow execution functions for TL Agent.
Each function handles a specific workflow type and returns either JSON or streaming responses.
"""
import logging
import json
from typing import Dict
from fastapi.responses import StreamingResponse
from app.core.config import config

logger = logging.getLogger(__name__)


async def _execute_refine_content(self, params: dict) -> dict:
        """Execute refine content workflow and return streaming response"""
        from app.features.thought_leadership.services.refine_content_service import RefineContentService
        from app.infrastructure.llm.llm_service import LLMService
        
        try:
            logger.info(f"[RefineContent] Starting content refinement")
            
            llm_service = LLMService()
            refine_service = RefineContentService(llm_service=llm_service)
 
            logger.info(f'here are the params {params}')

            original_content = params.get('original_content', '')
            service_type = params.get('service_type', '')
            expected_word_count = params.get('expected_word_count')
            audience_tone = params.get('audience_tone')
            supporting_doc = params.get('supporting_doc')
            expand_guidelines = params.get('expand_guidelines')

            logger.info(f'[RefineContent] service type length: {service_type}')
            # Validate
            if not original_content or not original_content.strip():
                return {
                    "status": "error",
                    "workflow": "refine_content",
                    "error": "Original content is required"
                }
            if not service_type:
                logger.warning("[RefineContent] No service type provided")
                return {
                    "status": "error",
                    "workflow": "refine_content",
                    "error": "Service type is required"
                }
            if service_type in ["expand", "compress"] and not expected_word_count:
                return {
                    "status": "error",
                    "workflow": "refine_content",
                    "error": f"{service_type.replace('_', ' ').title()} requires a target word count"
                }
            
            if service_type == "adjust_audience_tone" and not audience_tone:
                return {
                    "status": "error",
                    "workflow": "refine_content",
                    "error": "Adjust audience tone requires specifying the desired tone"
                }
            
            logger.info(f'[RefineContent] above to return passed')
            original_word_count = len(original_content.split())
            services = []
            if service_type == "expand":
                services.append({
                    "isSelected": True,
                    "type": "expand",
                    "original_word_count": original_word_count,
                    "expected_word_count": int(expected_word_count) if expected_word_count else None,
                    "supportingDoc": supporting_doc,
                    "expand_guidelines": expand_guidelines
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "expand"
                })
            
            # Compress service
            if service_type == "compress":
                services.append({
                    "isSelected": True,
                    "type": "compress",
                    "original_word_count": original_word_count,
                    "expected_word_count": int(expected_word_count) if expected_word_count else None
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "compress"
                })
            
            # Adjust audience tone service
            if service_type == "adjust_audience_tone":
                services.append({
                    "isSelected": True,
                    "type": "adjust_audience_tone",
                    "audience_tone": audience_tone
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "adjust_audience_tone"
                })
            
            # Improvement suggestions service
            if service_type == "improvement_suggestions":
                services.append({
                    "isSelected": True,
                    "type": "improvement_suggestions",
                    "suggestion_type": "general"
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "improvement_suggestions"
                })
            
            # Enhanced with research service
            if service_type == "enhanced_with_research":
                services.append({
                    "isSelected": True,
                    "type": "enhanced_with_research"
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "enhanced_with_research"
                })
            
            # Edit content service
            if service_type == "edit_content":
                services.append({
                    "isSelected": True,
                    "type": "edit_content",
                    "editors": []
                })
            else:
                services.append({
                    "isSelected": False,
                    "type": "edit_content",
                    "editors": []
                })
            selected_services = [s for s in services if s.get('isSelected', False)]
            logger.info(f"[RefineContent] Selected services: {selected_services}")
            
            if not selected_services:
                logger.warning("[RefineContent] No services selected after building array")
                return {
                    "status": "error",
                    "workflow": "refine_content",
                    "error": "At least one service must be selected"
                }
            
            
            # Build request data
            request_data = {
                "original_content": original_content,
                "services": services,
                "stream": True
            }
            
            logger.info(f'Data passed to refine content service {request_data}')
            return {
                "status": "success",
                "workflow": "refine_content",
                "streaming_response": StreamingResponse(
                    refine_service.refine_content(request_data),
                    media_type="text/event-stream"
                )
            }
            
        except Exception as e:
            logger.error(f"Error executing refine_content: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "refine_content",
                "error": str(e)
            }
    
async def _execute_conduct_research(self, params: dict) -> dict:  # Renamed method
        """Execute conduct research workflow and bypass through LLM for streaming"""
        from app.features.chat.services.data_source_agent import create_data_source_agent
        from app.core.config import config
        
        try:
            logger.info(f"[ConductResearch] Starting research on: {params.get('research_topic')}")
            
            agent = create_data_source_agent(
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            research_scope = params.get('research_scope', 'comprehensive')
            specific_sources = params.get('specific_sources', '')
            depth_level = params.get('depth_level', 'detailed')
            
            research_prompt = f"""Conduct extensive research on the following topic and provide comprehensive information with all citations and source links.

    **Research Topic:** {params.get('research_topic')}

    **Research Scope:** {research_scope}

    **Depth Level:** {depth_level}

    {f"**Specific Sources to Focus On:** {specific_sources}" if specific_sources else ""}

    **Research Instructions:**
    1. If required: Use ALL available data sources to gather comprehensive information
    2. Provide detailed findings with specific data points, statistics, and facts
    4. ALWAYS cite sources with proper attribution
    5. Organize findings in a clear, structured format
    """
            
            agent_messages = [{"role": "user", "content": research_prompt}]
            logger.info(f"[ConductResearch] Calling data_source_agent")
            
            research_results = await agent.process_query(agent_messages)
            
            if research_results:
                logger.info(f"[ConductResearch] Research completed - bypassing through LLM")
                
                # Bypass through LLM for streaming
                async def stream_bypassed_results():
                    import json
                    
                    # Create LLM prompt to process research results
                    bypass_prompt = f"""You are a helpful research assistant. Based on the following research data, provide a clear, well-structured response to the user's question: "{params.get('research_topic')}"

    Research Data:
    {research_results}

    STRICT INSTRUCTIONS - FOLLOW EXACTLY:
    1. Format your ENTIRE response in Markdown
    2. Present information in a natural, conversational manner
    3. Organize the response logically with clear sections using Markdown headers (##)
    4. Place ALL citations and sources at the end under a "## Sources" section with proper attribution
    5. NEVER mention which data sources failed, how many API calls were made, or any technical details about data fetching
    6. NEVER include phrases like "data source failed", "unable to fetch", "API call", "sources checked", etc.
    7. Focus ONLY on delivering the answer with relevant information
    8. Use Markdown formatting: **bold** for emphasis, bullet points with -, numbered lists with 1., etc.
"""
                    
                    messages = [{"role": "user", "content": bypass_prompt}]
                    
                    # Stream LLM response
                    async for chunk in self.llm.astream(messages):
                        if hasattr(chunk, 'content') and chunk.content:
                            yield f"data: {json.dumps({'type': 'content', 'content': chunk.content})}\n\n"
                    
                    yield f"data: {json.dumps({'type': 'metadata', 'workflow': 'conduct_research', 'topic': params.get('research_topic'), 'ready_to_execute': True})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
                
                agent.close()
                
                return {
                    "status": "success",
                    "workflow": "conduct_research",
                    "streaming_response": StreamingResponse(stream_bypassed_results(), media_type="text/event-stream")
                }
            else:
                logger.warning(f"[ConductResearch] No results returned from agent")
                agent.close()
                return {
                    "status": "error",
                    "workflow": "conduct_research",
                    "error": "No research results found"
                }
                    
        except Exception as e:
            logger.error(f"Error executing conduct_research: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "conduct_research",
                "error": str(e)
            }

   
async def _execute_format_translator(self, params: dict) -> dict:
        """Execute format translator workflow and return streaming response"""
        from app.features.thought_leadership.services.format_translator_service import FormatTranslatorService
        from app.infrastructure.llm.llm_service import LLMService
        
        try:
            logger.info(f"[FormatTranslator] Starting format translation")
            
            llm_service = LLMService()
            format_service = FormatTranslatorService(llm_service=llm_service)
            
            content = params.get('content', '')
            target_format = params.get('target_format', '')
            source_format = params.get('source_format', 'Document')
            customization = params.get('customization', '')
            word_limit = params.get('word_limit', '')
            
            # Set default word limits based on platform
            if target_format.lower() in ["social media post", "social media"]:
                if customization and "linkedin" in customization.lower():
                    if not word_limit:
                        word_limit = "300"
                elif customization and ("x.com" in customization.lower() or "twitter" in customization.lower()):
                    if not word_limit:
                        word_limit = "30"
            
            
            if target_format.lower() not in ["social media post", "social media", "webpage ready"]:
                return {
                    "status": "error",
                    "workflow": "format_translator",
                    "error": f"Format '{target_format}' not supported. Only 'Social Media Post' and 'Webpage Ready' are available."
                }
            
            async def format_stream():
                async for chunk in format_service.translate_format(
                    content=content,
                    source_format=source_format,
                    target_format=target_format,
                    customization=customization,
                    podcast_style=None,
                    speaker1_name=None,
                    speaker1_voice=None,
                    speaker1_accent=None,
                    speaker2_name=None,
                    speaker2_voice=None,
                    speaker2_accent=None,
                    word_limit=word_limit
                ):
                    yield chunk
                if target_format.lower() == "webpage ready":
                    logger.info("Webpage Ready format translation completed.")
                    yield f"data: {json.dumps({'type': 'webpage_ready', 'content': 'completed'})}\n\n"

            return {
                "status": "success",
                "workflow": "format_translator",
                "streaming_response": StreamingResponse(format_stream(), media_type="text/event-stream")
            }
            
        except Exception as e:
            logger.error(f"Error executing format_translator: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "format_translator",
                "error": str(e)
            }
    

async def _execute_draft_content(self, params: dict) -> dict:
        """Execute draft content workflow and return streaming response"""
        from app.features.thought_leadership.workflows.draft_content_class import DraftContentResearchService
        from app.features.thought_leadership.services.draft_content_service import DraftContentService
        from app.infrastructure.llm.llm_service import LLMService
        from app.core.config import config
        
        try:
            logger.info(f"[DraftContent] Starting draft content generation")
            
            llm_service = LLMService()
            draft_service = DraftContentService(llm_service=llm_service)
            
            research_service = DraftContentResearchService(
                draft_service=draft_service,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            # Build user prompt from collected params
            content_type = params.get('content_type', '')
            topic = params.get('topic', '')
            word_limit = params.get('word_limit', '')
            audience_tone = params.get('audience_tone', '')
            outline_doc = params.get('outline_doc', '')
            supporting_doc = params.get('supporting_doc', '')
            
            user_prompt = f"""Content Type: {content_type}
            Topic: {topic}
            Word Limit: {word_limit}
            Audience/Tone: {audience_tone}
            Initial Outline/Concept: {outline_doc}
            Supporting Documents: {supporting_doc}"""
                    
            logger.info(f"[_execute_draft_content] user prompt:\n{user_prompt}")
                    
                    # Create request object
            from app.features.thought_leadership.workflows.draft_content_class import DraftContentRequest
            request = DraftContentRequest(
                messages=[{"role": "user", "content": user_prompt}],
                content_type=params.get('content_type'),
                topic=params.get('topic'),
                word_limit=str(params.get('word_limit', '')),
                audience_tone=params.get('audience_tone', ''),
                outline_doc=params.get('outline_doc', ''),
                supporting_doc=params.get('supporting_doc', ''),
                use_factiva_research=False
            )
            
            
            streaming_response = await research_service.generate_draft_content(
                request=request,
                user_prompt=user_prompt,
                is_improvement=False
            )
            
            return {
                "status": "success",
                "workflow": "draft_content",
                "streaming_response": streaming_response
            }
            
        except Exception as e:
            logger.error(f"Error executing draft_content: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "draft_content",
                "error": str(e)
            }
    
async def _execute_detect_edit_intent(self, params: dict) -> dict:
        """Execute detect edit intent workflow - returns JSON without streaming"""
        try:
            user_input = params.get("user_input", "")
            
            system_prompt = """YOU ARE AN INTENT CLASSIFICATION AGENT.

            YOUR TASK:
            Detect **EDIT INTENT ONLY WHEN THE USER INPUT LITERALLY CONTAINS**
            ONE OR MORE OF THE FOLLOWING WORDS:

            - "edit"
            - "editing"
            - "edited"

            Matching is:
            - case-insensitive
            - based on literal string presence
            - valid anywhere in the input text

            ━━━━━━━━━━━━━━━━━━━━
            DETECTION RULES (STRICT, NON-NEGOTIABLE)
            ━━━━━━━━━━━━━━━━━━━━

            1. IF the input text contains "edit", "editing", or "edited"
            → set `"is_edit_intent": true`

            2. IF NONE of these words appear
            → set `"is_edit_intent": false`

            3. DO NOT infer meaning, intent, or user goals.
            4. DO NOT use semantic similarity.
            5. DO NOT treat related or synonymous words as edit.
            6. ONLY literal string matching is allowed.

            ━━━━━━━━━━━━━━━━━━━━
            WORDS THAT MUST NOT TRIGGER EDIT INTENT
            ━━━━━━━━━━━━━━━━━━━━

            The following words or phrases MUST NEVER trigger edit intent
            UNLESS the word "edit", "editing", or "edited" is ALSO present:

            - refine
            - improve
            - enhance
            - polish
            - review
            - rewrite
            - optimize
            - update
            - fix
            - adjust
            - draft
            - drafting
            - create
            - write

            If the input contains ONLY these terms
            and does NOT contain "edit", "editing", or "edited"
            → `"is_edit_intent": false`

            ━━━━━━━━━━━━━━━━━━━━
            EDITOR DETECTION (SECONDARY RULE)
            ━━━━━━━━━━━━━━━━━━━━

            ONLY IF `"is_edit_intent": true`:

            Check whether the user EXPLICITLY mentions any of the following editors:

            - "line"
            - "copy"
            - "development"
            - "content"
            - "brand-alignment"

            Add ONLY the editors that appear verbatim in the input text.
            DO NOT infer, assume, or default editors.

            ━━━━━━━━━━━━━━━━━━━━
            OUTPUT FORMAT (STRICT)
            ━━━━━━━━━━━━━━━━━━━━

            RESPOND WITH ONLY VALID JSON:

            {
            "is_edit_intent": true/false,
            "confidence": 0.0-1.0,
            "reasoning": "short literal explanation",
            "detected_editors": []
            }

            ━━━━━━━━━━━━━━━━━━━━
            ABSOLUTE PROHIBITIONS
            ━━━━━━━━━━━━━━━━━━━━

            - NEVER infer intent
            - NEVER guess user goals
            - NEVER use semantic interpretation
            - NEVER expand the edit trigger list
            - NEVER add text outside the JSON response
"""

            user_prompt = f"Analyze this user input and determine if it indicates edit/improve/review intent:\n\n\"{user_input}\""

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
            
            response = self.llm.invoke(messages)
            response_text = response.content.strip()
            
            # Extract JSON from response
            json_start = response_text.find('{')
            json_end = response_text.rfind('}') + 1
            
            if json_start != -1 and json_end > json_start:
                json_text = response_text[json_start:json_end]
                result = json.loads(json_text)
                
                # Validate result structure
                if not isinstance(result, dict):
                    raise ValueError("Invalid response format: not a dictionary")
                
                is_edit_intent = result.get("is_edit_intent", False)
                confidence = float(result.get("confidence", 0.5))
                reasoning = result.get("reasoning", "No reasoning provided")
                detected_editors_raw = result.get("detected_editors", [])
                
                # Clamp confidence to valid range
                confidence = max(0.0, min(1.0, confidence))
                
                # Validate and map detected editors to valid IDs
                valid_editor_ids = ["line", "copy", "development", "content", "brand-alignment"]
                detected_editors = []
                
                if isinstance(detected_editors_raw, list):
                    for editor in detected_editors_raw:
                        editor_lower = str(editor).lower().strip()
                        for valid_id in valid_editor_ids:
                            if editor_lower == valid_id or editor_lower.replace(" ", "-") == valid_id:
                                if valid_id not in detected_editors:
                                    detected_editors.append(valid_id)
                                break
                
                logger.info(f"Intent detection result: is_edit_intent={is_edit_intent}, confidence={confidence:.2f}, reasoning={reasoning}, detected_editors={detected_editors}")
                
                return {
                    "status": "success",
                    "workflow": "detect_edit_intent",
                    "return_json": True,
                    "result": {
                        "is_edit_intent": bool(is_edit_intent),
                        "confidence": confidence,
                        "detected_editors": detected_editors
                    }
                }
            else:
                raise ValueError("No valid JSON found in response")
                
        except Exception as e:
            logger.error(f"Error executing detect_edit_intent: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "detect_edit_intent",
                "error": str(e)
            }