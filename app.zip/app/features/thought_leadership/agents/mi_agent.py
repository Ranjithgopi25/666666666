from typing import TypedDict, Optional, List, Literal, AsyncGenerator
from langgraph.graph import StateGraph, END
from langchain_openai import AzureChatOpenAI
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import logging
from pydantic import BaseModel
from app.core.config import config
import json

logger = logging.getLogger(__name__)
router = APIRouter()

# Define workflow schemas
WORKFLOW_SCHEMAS = {
    "prep_client_meeting": {
        "required": ["clientname", "topic", "meeting_with"],
        "optional": ["word_limit", "outline_doc", "supporting_doc"],
        "description": "Prepare a client meeting brief with research, when asking for audience_tone check who they are meeting, CEO, any department head or someone else"
    },
    "proposal_insights": {
        "required": ["clientname", "topic"],
        "optional": ["audience_tone", "word_limit", "outline_doc", "supporting_doc"],
        "description": "Gather comprehensive proposal insights with multi-source research"
    },
    "industry_insights": {
        "required": ["industry"],
        "optional": ["audience_tone", "word_limit", "outline_doc", "supporting_doc"],
        "description": "Generate comprehensive industry insights report with multi-source research"
    },
    "pov_content": {
        "required": ["content_type", "topic", "audience_tone", "supporting_doc"],
        "optional": ["word_limit", "outline_doc"],
        "description": "Generate Point of View content (Article (perspective), Blog, Executive Brief) with multi-source research"
    },
    "conduct_research": {
        "required": ["research_topic"],
        "optional": ["research_scope", "specific_sources", "depth_level"],
        "description": "Conduct extensive research on any topic with citations and source links"
    }
}

class AgentState(TypedDict):
    messages: List[dict]
    current_workflow: Optional[str]
    collected_params: dict
    missing_params: List[str]
    user_intent: str
    conversation_history: List[dict]
    execution_result: Optional[dict]

class TLAgentRequest(BaseModel):
    messages: List[dict]

class MarketIntelligenceAgent:
    """LangGraph agent for orchestrating TL workflows with conversational parameter collection"""
    
    def __init__(self):
        self.llm = AzureChatOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
            temperature=0.3
        )
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow"""
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("identify_intent", self._identify_intent)
        workflow.add_node("extract_parameters", self._extract_parameters)
        workflow.add_node("check_completeness", self._check_completeness)
        workflow.add_node("execute_workflow", self._execute_workflow)
        
        # Define edges
        workflow.set_entry_point("identify_intent")
        workflow.add_edge("identify_intent", "extract_parameters")
        workflow.add_edge("extract_parameters", "check_completeness")
        
        # Conditional routing
        workflow.add_conditional_edges(
            "check_completeness",
            self._should_execute,
            {
                "execute": "execute_workflow",
                "ask": END  # Changed: END here, we'll handle streaming separately
            }
        )
        
        workflow.add_edge("execute_workflow", END)
        # workflow.add_edge("ask_missing_params", END)

        return workflow.compile()
    
    def _identify_intent(self, state: AgentState) -> AgentState:
        """Identify user's workflow intent"""
        user_message = state["messages"]
        intent_prompt = f"""Analyze the user's request and identify which workflow they need:

    Available workflows:
    {self._format_workflow_descriptions()}

    User message: {user_message}

    Previous workflow: {state.get('current_workflow', 'None')}

    IMPORTANT DISTINCTIONS:
    - If user asks factual questions, requests information, data, statistics, or wants to know about anything (e.g., "what is temp of goa today", "what were sales of maruti 800 in 2008", "tell me about X"), return "conduct_research"
    - If user requests specific content deliverables (article, blog, meeting brief, proposal, industry insights), return the specific workflow name
    - If user mentions any of these POV content types (Perspective, Blog, Executive Brief), return "pov_content"
    - If user is having casual conversation, greetings, or small talk (like "hi", "hello", "how are you", "what can you do"), return "unclear"

    Examples requiring conduct_research: "what is temperature in goa", "sales data for maruti 800", "climate change information", "latest AI trends", "what happened yesterday", "tell me about quantum computing"

    Examples requiring pov_content: "create a blog", "write a perspective", "executive brief", "blog post", "article", "pov"

    Return ONLY the workflow name (e.g., "prep_client_meeting", "conduct_research", "pov_content") or "unclear" if uncertain.
    If the user is providing information for an ongoing workflow, return the current workflow name.
    """
        
        response = self.llm.invoke([{"role": "user", "content": intent_prompt}])
        identified_workflow = response.content.strip().lower()
        
        if identified_workflow in WORKFLOW_SCHEMAS:
            if state.get("current_workflow") != identified_workflow:
                logger.info(f"Workflow changed: {state.get('current_workflow')} -> {identified_workflow}")
                state["current_workflow"] = identified_workflow
                state["collected_params"] = {}
            else:
                state["current_workflow"] = identified_workflow
        
        state["user_intent"] = identified_workflow
        return state
    
    def _extract_parameters(self, state: AgentState) -> AgentState:
        """Extract parameters from user message"""
        if not state.get("current_workflow") or state["current_workflow"] not in WORKFLOW_SCHEMAS:
            return state
        
        workflow_name = state["current_workflow"]
        schema = WORKFLOW_SCHEMAS[workflow_name]
        user_message = state["messages"]
        

        # Special handling for conduct_research to gather comprehensive info
        if workflow_name == "conduct_research":
            extraction_prompt = f"""Extract parameters from the user's message for the conduct_research workflow.

            Required parameters: {', '.join(schema['required'])}
            Optional parameters: {', '.join(schema['optional'])}

            User message: {user_message}

            Already collected: {state.get('collected_params', {})}

            For conduct_research workflow:
            - research_topic: The main subject/topic to research (be specific and comprehensive)
            - research_scope: Scope of research (e.g., "comprehensive", "specific aspect", "comparative analysis")
            - specific_sources: Any specific sources or databases the user wants to focus on
            - depth_level: Level of detail needed (e.g., "overview", "detailed", "expert-level")

            Return a JSON object with any NEW parameters found. Extract as much context as possible from the user's request.
            Example: {{"research_topic": "Impact of AI on healthcare industry", "research_scope": "comprehensive", "depth_level": "detailed"}}

            If no new parameters found, return {{}}.
            """
        else:
            extraction_prompt = f"""Extract parameters from the user's message for the {workflow_name} workflow.

    Required parameters: {', '.join(schema['required'])}
    Optional parameters: {', '.join(schema['optional'])}

    User message: {user_message}

    Already collected: {state.get('collected_params', {})}

    Return a JSON object with any NEW parameters found. Only include parameters that are explicitly mentioned.
    Example: {{"clientname": "Acme Corp", "topic": "Digital Transformation"}}

    If no new parameters found, return {{}}.
    """
        
        response = self.llm.invoke([{"role": "user", "content": extraction_prompt}])
        
        try:
            import json
            new_params = json.loads(response.content.strip())
            if not state.get("collected_params"):
                state["collected_params"] = {}
            state["collected_params"].update(new_params)
            logger.info(f"Extracted params: {new_params}. Total: {state['collected_params']}")
        except Exception as e:
            logger.error(f"Error parsing extracted params: {e}")
        
        return state
    def _check_completeness(self, state: AgentState) -> AgentState:
        """Check if all required parameters are collected"""
        if not state.get("current_workflow") or state["current_workflow"] not in WORKFLOW_SCHEMAS:
            state["missing_params"] = ["workflow_identification"]
            return state
        
        workflow_name = state["current_workflow"]
        schema = WORKFLOW_SCHEMAS[workflow_name]
        collected = state.get("collected_params", {})
        
        missing = [param for param in schema["required"] if param not in collected or not collected[param]]
        state["missing_params"] = missing
        
        logger.info(f"Completeness check - Missing: {missing}")
        return state
    
    def _should_execute(self, state: AgentState) -> Literal["execute", "ask"]:
        """Decide whether to execute workflow or ask for more params"""
        if state.get("user_intent") == "unclear":
            return "ask"
        if not state.get("missing_params"):
            return "execute"
        return "ask"
    
    async def _ask_missing_params_stream(self, state: AgentState) -> AsyncGenerator[str, None]:
        """Generate and stream a conversational request for missing parameters"""
        import json
        if state.get("user_intent") == "unclear":
            formatted_workflows = []
            for name, schema in WORKFLOW_SCHEMAS.items():
                display_name = name.replace('_', ' ').title()
                formatted_workflows.append(f"- {display_name}: {schema['description']}")
            workflows_text = "\n".join(formatted_workflows)
            
            unclear_prompt = f"""The user's intent is unclear. Generate a friendly, helpful response that:
    1. Acknowledges their message
    2. Lists available workflows naturally in conversation
    3. Asks what they'd like to do

    Available workflows:
    {workflows_text}

    User message: {state["messages"] if state["messages"] else ""}

    Keep it conversational and concise (2-3 sentences)."""

            messages = [{"role": "user", "content": unclear_prompt}]
                
            full_content = ""
            async for chunk in self.llm.astream(messages):
                if hasattr(chunk, 'content') and chunk.content:
                    full_content += chunk.content
                    yield f"data: {json.dumps({'type': 'content', 'content': chunk.content})}\n\n"
            
            yield f"data: {json.dumps({'type': 'metadata', 'workflow': None, 'collected_params': {}, 'missing_params': ['workflow_identification'], 'ready_to_execute': False})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
            
            state["messages"].append({
                "role": "assistant",
                "content": full_content
            })
        
        else:
            workflow_name = state.get("current_workflow")
            missing = state.get("missing_params", [])
            param_descriptions = {
                "clientname": "the client's company name",
                "topic": "the topic or subject",
                "meeting_with": "who you'll be meeting with (CEO, department head, etc.)",
                "audience_tone": "the target audience",
                "word_limit": "the desired word count",
                "content_type": "the type of content (Perspective, Blog, or Executive Brief)",
                "supporting_doc": "any supporting documents",
                "outline_doc": "any outline documents",
                "research_topic": "the research topic",
                "research_scope": "the scope of research",
                "specific_sources": "specific sources to focus on",
                "depth_level": "the level of detail needed"
            }
            
            # Special handling for pov_content workflow
            if workflow_name == "pov_content":
                ask_prompt = f"""Generate a natural, conversational message asking for the missing POV content parameters.

    Workflow: {workflow_name}
    MMissing parameters with descriptions:
    {chr(10).join([f"- {param_descriptions.get(param, param)}" for param in missing])}
    Already provided: {state.get('collected_params', {})}

    POV Content Types Available:
    - Perspective: Thought-leadership article presenting a unique viewpoint
    - Blog: Engaging blog post for wider audience
    - Executive Brief: Concise summary for executive stakeholders

    Be friendly and specific. Ask for the most important missing parameter first.
    If asking for content_type, mention the available types (Perspective, Blog, Executive Brief).
    If asking for topic, ask what subject they want to write about.
    If asking for audience_tone, ask who the target audience is (e.g., executives, technical readers, general public).
    Keep it concise (1-2 sentences max).
    """
            else:
                ask_prompt = f"""Generate a natural, conversational message asking for the missing parameters.

    Workflow: {workflow_name}
    Missing parameters: {', '.join(missing)}
    Already provided: {state.get('collected_params', {})}

    Be friendly and specific. Ask for the most important missing parameter first.
    Keep it concise (1-2 sentences max).
    """
            
            messages = [{"role": "user", "content": ask_prompt}]
            
            full_content = ""
            async for chunk in self.llm.astream(messages):
                if hasattr(chunk, 'content') and chunk.content:
                    full_content += chunk.content
                    yield f"data: {json.dumps({'type': 'content', 'content': chunk.content})}\n\n"
            
            yield f"data: {json.dumps({'type': 'metadata', 'workflow': workflow_name, 'collected_params': state.get('collected_params', {}), 'missing_params': missing, 'ready_to_execute': False})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
            
            state["messages"].append({
                "role": "assistant",
                "content": full_content
            })
    async def _execute_workflow(self, state: AgentState) -> AgentState:
        """Execute the identified workflow with collected parameters"""
        workflow_name = state["current_workflow"]
        params = state["collected_params"]
        
        logger.info(f"Executing workflow: {workflow_name} with params: {params}")
        
        if workflow_name == "prep_client_meeting":
            result = await self._execute_prep_client_meeting(params)
            state["execution_result"] = result
        elif workflow_name == "proposal_insights":
            result = await self._execute_proposal_insights(params)
            state["execution_result"] = result
        elif workflow_name == "industry_insights":
            result = await self._execute_industry_insights(params)
            state["execution_result"] = result
        elif workflow_name == "conduct_research":
            result = await self._execute_conduct_research(params)
            state["execution_result"] = result
        elif workflow_name == "pov_content":
            result = await self._execute_pov_content(params)
            state["execution_result"] = result
        else:
            result = {"error": f"Workflow {workflow_name} not yet implemented"}
            state["execution_result"] = result
        
        return state
    
    async def _execute_conduct_research(self, params: dict) -> dict:  # Renamed method
        """Execute conduct research workflow and bypass through LLM for streaming"""
        from app.features.chat.services.data_source_agent import create_data_source_agent
        from app.core.config import config
        
        try:
            logger.info(f"[ConductResearch] Starting research on: {params.get('research_topic')}")
            
            agent = create_data_source_agent(
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            research_scope = params.get('research_scope', 'comprehensive')
            specific_sources = params.get('specific_sources', '')
            depth_level = params.get('depth_level', 'detailed')
            
            research_prompt = f"""Conduct extensive research on the following topic and provide comprehensive information with all citations and source links.

    **Research Topic:** {params.get('research_topic')}

    **Research Scope:** {research_scope}

    **Depth Level:** {depth_level}

    {f"**Specific Sources to Focus On:** {specific_sources}" if specific_sources else ""}

    **Research Instructions:**
    1. If required: Use ALL available data sources to gather comprehensive information
    2. Provide detailed findings with specific data points, statistics, and facts
    4. ALWAYS cite sources with proper attribution
    5. Organize findings in a clear, structured format
    """
            
            agent_messages = [{"role": "user", "content": research_prompt}]
            logger.info(f"[ConductResearch] Calling data_source_agent")
            
            research_results = await agent.process_query(agent_messages)
            
            if research_results:
                logger.info(f"[ConductResearch] Research completed - bypassing through LLM")
                
                # Bypass through LLM for streaming
                async def stream_bypassed_results():
                    import json
                    
                    # Create LLM prompt to process research results
                    bypass_prompt = f"""You are a helpful research assistant. Based on the following research data, provide a clear, well-structured response to the user's question: "{params.get('research_topic')}"

    Research Data:
    {research_results}

    STRICT INSTRUCTIONS - FOLLOW EXACTLY:
    1. Format your ENTIRE response in Markdown
    2. Present information in a natural, conversational manner
    3. Organize the response logically with clear sections using Markdown headers (##)
    4. Place ALL citations and sources at the end under a "## Sources" section with proper attribution
    5. NEVER mention which data sources failed, how many API calls were made, or any technical details about data fetching
    6. NEVER include phrases like "data source failed", "unable to fetch", "API call", "sources checked", etc.
    7. Focus ONLY on delivering the answer with relevant information
    8. Use Markdown formatting: **bold** for emphasis, bullet points with -, numbered lists with 1., etc.
"""
                    
                    messages = [{"role": "user", "content": bypass_prompt}]
                    
                    # Stream LLM response
                    async for chunk in self.llm.astream(messages):
                        if hasattr(chunk, 'content') and chunk.content:
                            yield f"data: {json.dumps({'type': 'content', 'content': chunk.content})}\n\n"
                    
                    yield f"data: {json.dumps({'type': 'metadata', 'workflow': 'conduct_research', 'topic': params.get('research_topic'), 'ready_to_execute': True})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
                
                agent.close()
                
                return {
                    "status": "success",
                    "workflow": "conduct_research",
                    "streaming_response": StreamingResponse(stream_bypassed_results(), media_type="text/event-stream")
                }
            else:
                logger.warning(f"[ConductResearch] No results returned from agent")
                agent.close()
                return {
                    "status": "error",
                    "workflow": "conduct_research",
                    "error": "No research results found"
                }
                    
        except Exception as e:
            logger.error(f"Error executing conduct_research: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "conduct_research",
                "error": str(e)
            }
    async def _execute_industry_insights(self, params: dict) -> dict:
        """Execute industry insights workflow"""
        from app.features.thought_leadership.workflows.industry_insights_class import IndustryInsightsResearchService
        from app.features.thought_leadership.services.industry_insights_service import IndustryInsightsService
        from app.infrastructure.llm.llm_service import LLMService
        from app.core.config import config
        
        try:
            llm_service = LLMService()
            insights_service = IndustryInsightsService(llm_service=llm_service)
            
            research_service = IndustryInsightsResearchService(
                insights_service=insights_service,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            streaming_response = await research_service.generate_insights_report(
                user_prompt=f"Generate industry insights for {params.get('clientname')}",
                clientname=params.get("clientname"),
                audience_tone=params.get("audience_tone", "Executive"),
                word_limit=params.get("word_limit", 4000),
                outline_doc=params.get("outline_doc", ""),
                supporting_doc=params.get("supporting_doc", "")
            )
            
            return {
                "status": "success",
                "workflow": "industry_insights",
                "streaming_response": streaming_response
            }
            
        except Exception as e:
            logger.error(f"Error executing industry_insights: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "industry_insights",
                "error": str(e)
            }
        
    async def _execute_prep_client_meeting(self, params: dict) -> dict:
        """Execute prep client meeting workflow"""
        from app.features.thought_leadership.workflows.prep_client_meeting_class import MeetingResearchService
        from app.features.thought_leadership.services.prep_client_meeting_service import PrepClientMeetingService
        from app.infrastructure.llm.llm_service import LLMService
        from app.core.config import config
        
        try:
            # Instantiate LLM service directly (no parameters - uses config internally)
            llm_service = LLMService()
            
            # Instantiate PrepClientMeetingService with LLM service
            prep_service = PrepClientMeetingService(llm_service=llm_service)
            
            # Initialize research service
            research_service = MeetingResearchService(
                prep_service=prep_service,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            # Generate meeting brief with research (this returns StreamingResponse)
            streaming_response = await research_service.generate_meeting_brief(
                user_prompt=f"Prepare meeting brief for {params.get('clientname')} on {params.get('topic')}",
                clientname=params.get("clientname"),
                topic=params.get("topic"),
                audience_tone=params.get("audience_tone", "Executive"),
                word_limit=params.get("word_limit", 4000),
                outline_doc=params.get("outline_doc", ""),
                supporting_doc=params.get("supporting_doc", "")
            )
            
            return {
                "status": "success",
                "workflow": "prep_client_meeting",
                "streaming_response": streaming_response
            }
            
        except Exception as e:
            logger.error(f"Error executing prep_client_meeting: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "prep_client_meeting",
                "error": str(e)
            }
    async def _execute_proposal_insights(self, params: dict) -> dict:
        """Execute proposal insights workflow"""
        from app.features.thought_leadership.workflows.proposal_insights_class import ProposalResearchService
        from app.features.thought_leadership.services.proposal_insights_service import ProposalInsightsService
        from app.infrastructure.llm.llm_service import LLMService
        from app.core.config import config
        
        try:
            llm_service = LLMService()
            proposal_service = ProposalInsightsService(llm_service=llm_service)
            
            research_service = ProposalResearchService(
                proposal_service=proposal_service,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            streaming_response = await research_service.generate_proposal_insights(
                user_prompt=f"Gather proposal insights for {params.get('clientname')} on {params.get('topic')}",
                clientname=params.get("clientname"),
                topic=params.get("topic"),
                audience_tone=params.get("audience_tone", "Executive"),
                word_limit=params.get("word_limit", 4000),
                outline_doc=params.get("outline_doc", ""),
                supporting_doc=params.get("supporting_doc", "")
            )
            
            return {
                "status": "success",
                "workflow": "proposal_insights",
                "streaming_response": streaming_response
            }
            
        except Exception as e:
            logger.error(f"Error executing proposal_insights: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "proposal_insights",
                "error": str(e)
            }
    async def _execute_pov_content(self, params: dict) -> dict:
        """Execute POV content workflow"""
        from app.features.thought_leadership.workflows.pov_class import POVResearchService
        from app.features.thought_leadership.services.pov_service import POVService
        from app.infrastructure.llm.llm_service import LLMService
        from app.core.config import config
        
        try:
            llm_service = LLMService()
            pov_service = POVService(llm_service=llm_service)
            
            research_service = POVResearchService(
                pov_service=pov_service,
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            # Create request object
            from app.features.thought_leadership.workflows.pov_class import POVRequest
            request = POVRequest(
                messages=[{"role": "user", "content": f"Generate {params.get('content_type')} on {params.get('topic')}"}],
                content_type=params.get("content_type"),
                topic=params.get("topic"),
                audience_tone=params.get("audience_tone", "Executive"),
                word_limit=str(params.get("word_limit", 2000)),
                outline_doc=params.get("outline_doc", ""),
                supporting_doc=params.get("supporting_doc", ""),
                use_research=False
            )
            
            streaming_response = await research_service.generate_pov_content(
                request=request,
                user_prompt=f"Content Type: {params.get('content_type')}\nTopic: {params.get('topic')}",
                is_improvement=False
            )
            
            return {
                "status": "success",
                "workflow": "pov_content",
                "streaming_response": streaming_response
            }
            
        except Exception as e:
            logger.error(f"Error executing pov_content: {e}", exc_info=True)
            return {
                "status": "error",
                "workflow": "pov_content",
                "error": str(e)
            }
        
    def _format_workflow_descriptions(self) -> str:
        """Format workflow descriptions for display"""
        descriptions = []
        for name, schema in WORKFLOW_SCHEMAS.items():
            desc = f"• {name}: {schema['description']}"
            descriptions.append(desc)
        return "\n".join(descriptions)
    
    async def process(self, messages: List[dict]) -> dict:
        """Process user request through the agent"""
        initial_state = {
            "messages": messages,
            "current_workflow": None,
            "collected_params": {},
            "missing_params": [],
            "user_intent": "",
            "conversation_history": []
        }
        
        result = await self.graph.ainvoke(initial_state)
        return result

# Global agent instance
agent_instance = None

def get_agent():
    global agent_instance
    if agent_instance is None:
        agent_instance = MarketIntelligenceAgent()
    return agent_instance

@router.post("")
async def mi_agent_endpoint(request: TLAgentRequest):
    """
    Conversational TL agent that identifies intent and collects parameters
    """
    try:
        agent = get_agent()
        
        async def stream_agent_response():
            """Stream the complete agent interaction"""
            # Process through the graph
            initial_state = {
                "messages": request.messages,
                "current_workflow": None,
                "collected_params": {},
                "missing_params": [],
                "user_intent": "",
                "conversation_history": []
            }
            
            result = await agent.graph.ainvoke(initial_state)
            
            # If workflow is ready to execute, stream the execution
            if result.get("execution_result") and result["execution_result"].get("streaming_response"):
                # The execution already returns a StreamingResponse, so we need to iterate its body
                streaming_resp = result["execution_result"]["streaming_response"]
                async for chunk in streaming_resp.body_iterator:
                    yield chunk
            
            # If we need to ask for parameters, stream that
            elif result.get("missing_params"):
                async for chunk in agent._ask_missing_params_stream(result):
                    yield chunk
            
            # Fallback
            else:
                yield f"data: {json.dumps({'type': 'content', 'content': 'I am ready to help. What would you like to do?'})}\n\n"
                yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
        
        return StreamingResponse(stream_agent_response(), media_type="text/event-stream")
        
    except Exception as e:
        logger.error(f"TL Agent error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))