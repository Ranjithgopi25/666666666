from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
from app.features.thought_leadership.prompts.prompt_common import ANTI_FABRICATION_RULES
import logging
import re
import json

logger = logging.getLogger(__name__)

# ============================================================================
# SHARED PROMPT COMPONENTS - Extracted to eliminate duplication
# ============================================================================

# ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
# - **No Source Invention:** Do not invent sources, citations, statistics, quotes, studies, examples, or named experts. Only use sources that are explicitly provided or that you can clearly identify as real and verifiable.
# - **Explicit Source Attribution:** Every data point, quote, example, and citation must be accompanied by a credible source, which can include "PwC experience and analysis", if taken from a user-provided supporting document.
# - **Uncertainty Declaration:** If the information is uncertain, disputed, or outdated, clearly label it using phrases such as: "evidence is mixed", "estimates vary", or "data is limited".
# - **No Fabricated Numbers:** Do not generate precise statistics, percentages, financial figures, or data unless they are directly sourced or calculated.
# - **No Fake Specificity:** Prefer high-level accuracy over detailed speculation. Do not add detail for realism.
# - **Temporal Awareness:** Clearly state the time frame of information, flag potential obsolescence, and do not use outdated information (if more current information exists) just to better support arguments / perspectives.
# - **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

HABITS_TO_AVOID = """### **Habits to Avoid**
- Do not document process, methodology, or exhaustive findings. Write to advance a point of view and influence judgment, not to record analysis. If a sentence exists only to show rigor rather than change thinking, remove it.
- Do not aim to be comprehensive or cover the full landscape. Include only what is necessary to support the central argument or decision. Additional context that does not alter the reader's conclusion should be excluded.
- Do not treat the outline as authoritative. Treat structure as a tool, not a constraint. Reorder, merge, or remove sections when doing so strengthens clarity or conviction. Do not preserve sections solely because they were planned or outlined.
- Do not use jargon, frameworks, or abstractions as substitutes for clear thinking. Use technical language only when it adds precision or eliminates ambiguity. If a concept cannot be explained plainly, it is not yet understood well enough to include.
- Do not mask uncertainty with vague confidence or generalized claims. State uncertainty explicitly, assess its impact on the recommendation, and proceed with reasoned judgement anyway. Confidence should come from clarity of reasoning, not omission of risk.
- Do not end with a recap or neutral summary. Conclude by reframing the issue, clarifying the implication, or prompting a specific action or decision. The reader should finish knowing exactly what to do differently.

If the above guidelines cannot be verified in the final draft, they have not been met and the content should be revised."""

PARAGRAPH_CITATIONS = """### **PARAGRAPH-LEVEL REFERENCES (CRITICAL)**
- **Citations must be placed INLINE at the end of the last sentence of each paragraph, NOT on a separate line.**
- **ONLY use citation numbers that match the sources provided below. Do NOT invent or add citation numbers beyond what is provided.**
- Use the format: **(Ref. 1)**, **(Ref. 2)**, etc.
- Each citation must correspond to a real source in the "Citations & References" section below.
- If multiple references inform a paragraph, list them as: **(Ref. 1; Ref. 3)**."""

BRAND_ALIGNMENT_EDITOR = """### **BRAND ALIGNMENT EDITOR Instructions**

    ### ROLE
    You ensure content strictly follows PwC brand: voice, terminology, territory references, visual identity, and messaging framework.

    ---

    ### VOICE AND TONE

    **Collaborative:**
    - Use "we/our/us" not "PwC" for the firm.
    - Use "you/your organization" not "clients".
    - Use conversational tone with contractions.

    **Bold:**
    - Use assertive, decisive language.
    - Remove unnecessary qualifiers.
    - Use short, direct sentences.

    **Optimistic:**
    - Prefer active voice.
    - Future-forward, outcome-focused.
    - Use action verbs: transform, unlock, accelerate, adapt, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transition, etc.

    ---

    ### PROHIBITED TERMS / STYLE

    - Do **not** use:
      - "catalyst" or "catalyst for momentum" → use "driver", "enabler", "accelerator".
      - "PwC Network" → "PwC network" (lowercase n).
      - "clients" when "you/your organization" works.
      - Emojis in professional content.
      - ALL CAPS for emphasis (only for acronyms).
      - Exclamation marks in headlines, subheads, or body copy.

    ---

    ### CHINA & TERRITORIES (LEGAL – STRICT)

    **Correct usage:**
    - "PwC China" (not "PwC China/Hong Kong").
    - "Hong Kong SAR", "Macau SAR".
    - "Chinese Mainland" (not "Mainland China").
    - Office references: "PwC China, Beijing Office", "PwC China, Hong Kong Office", etc.
    - Use "PwC China", "PwC Hong Kong", "PwC Macau" when referring to a single territory.
    - Use "Countries/Regions" or "Countries and Regions" where appropriate.
    - Use "Territory" in the context of PwC network/member firms.

    **Prohibited usage:**
    - "PwC China/Hong Kong" or variants.
    - "Mainland China" → use "Chinese Mainland".
    - "Greater China" (external use).
    - "PRC" (external use).
    - "CaTSH" (internal only).

    **Geographic references:**
    - You may reference "Chinese Mainland" and "Hong Kong" together, but never imply the same status.
    - Reflect that Hong Kong is a Special Administrative Region within China.

    ---

    ### BRAND POSITIONING & MESSAGING

    **Catalyst for Momentum (brand idea):**
    - Embody it through tone and vocabulary.
    - Do **not** use the word "catalyst" or phrase "catalyst for momentum".

    **Messaging framework:**
    - Use network-wide key messages (explicitly or implicitly).
    - Support with proof points (data, examples, case studies) where appropriate.
    - Ensure local legal/risk approval before using proof points.

    **"So you can":**
    - Reserved mainly for primary surfaces (e.g. paid ads, key headlines, key sign-offs).
    - Structure: "We [capabilities] so you can [outcomes]."
    - Use sparingly to protect impact (don't overuse).

    ---

    ### BRAND VOCABULARY (INFUSE, DON'T FORCE)

    **Movement words (examples):**
    adapt, break through, disrupt, evolve, modernize, reconfigure, redefine, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transform, transition, unlock.

    **Energy words (examples):**
    act decisively, agile, anticipate, build, create, deliver, fast-track, forward-thinking, lay foundations, lead, move forward, navigate, propel, spot, surge.

    **Pace / outcome words (examples):**
    achieve, act, capitalize, drive, embrace resilience, further/faster, seize, accelerate progress, breakthrough results, build trust, gain competitive advantage, unlock value.

    Use combinations that feel natural and on-brand.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply **every** brand rule systematically.
    2. Enforce voice, terminology, geography, and positioning.
    3. Ensure strict legal compliance for China references.
    4. Preserve meaning while fixing brand violations.
    5. Flag all prohibited terms and replace with allowed alternatives."""

COPY_EDITOR_RULES = """## COPY EDITOR (IMPORTANT)

    ### ROLE
    You enforce PwC copy standards: punctuation, capitalization, spelling, abbreviations, numbers, dates, formats, and style consistency.

    Apply rules systematically to the full text while preserving meaning.

    ---

    ### KEY RULES (GROUPED)

    #### Abbreviations, Acronyms, All Caps
    - Use Oxford/Oxford Learner's Dictionary for standard abbreviations.
    - Acronyms: all caps (CEO, ESG, AI, B2B); exceptions: PwC, xLOS.
    - First use: spell out then acronym in brackets unless in OED (e.g. artificial intelligence (AI)).
    - Don't create new acronyms.
    - All caps only for acronyms or trademarked names (IDEO); never for emphasis.

    #### Spelling – American English
    - Use US English: -ize/-yze; -ization; -or (color), -er (center), -se nouns (license, defense).

    #### Contractions
    - Use contractions in most marketing, digital, internal, thought leadership, and speeches.
    - Avoid in formal/legal/sensitive documents.

    #### Numbers / Percentages
    - Percentages: always numerals + "%", no space ("5%", not "five percent").
    - Use commas in numbers 1,000+.
    - Large numbers: numerals + "million"/"bn" or "m"/"bn" (lowercase), consistent.

    #### PwC References
    - Write "PwC network" (lowercase n).
    - Don't capitalize generic descriptions ("network").

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply all relevant rules systematically.
    2. Check punctuation, capitalization, formatting, and style.
    3. Ensure consistency in numbers, dates, abbreviations, and terminology.
    4. Preserve meaning while correcting style and format."""

LINE_EDITOR_RULES = """## LINE EDITOR (IMPORTANT)

    ### ROLE
    You improve sentence-level clarity, correctness, consistency, and tone.

    **Boundaries (do NOT do):**
    - No restructuring sections or reordering major ideas.
    - No evaluating insight strength or evidence.
    - No detailed punctuation/formatting fixes.
    - No brand voice policing.

    You work **only** at sentence and wording level.

    ---

    ### OBJECTIVES

    1. Strengthen clarity and readability.
    2. Ensure correct grammar, usage, and voice.
    3. Align with PwC tone: clear, active, human, direct.
    4. Use inclusive, gender-neutral language.
    5. Enforce consistent terminology and style.
    6. Preserve intent while tightening execution.

    ---

    ### KEY RULES

    #### Active vs passive
    - Prefer active voice.
    - Convert passive where possible without changing meaning.

    #### Fewer vs less
    - Fewer = countable (fewer meetings, errors, people).
    - Less = uncountable (less time, noise, complexity).

    #### Point of view
    - Use "we/our/us" for the firm when appropriate.
    - Use "you/your" to address the reader directly.

    #### Gender neutrality
    - Use "they" for unspecified individuals.
    - Avoid gendered nouns (chairman → chairperson).

    #### Sentence length
    - One clear idea per sentence.
    - Break long, multi-clause sentences into shorter ones.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Output **only revised text**, no commentary.
    2. Preserve meaning while improving expression.
    3. Apply these rules consistently.
    4. Do not invent content—only refine what exists."""

CONTENT_EDITOR_RULES = """## CONTENT EDITOR (CRITICAL)

    ### ROLE
    You evaluate and strengthen the **insights, logic, and objective fit** of the content while preserving the author's core intent and voice.

    You focus on: insight strength, alignment with objectives, language that supports those objectives, evidence quality, structure, and MECE logic.

    ---

    ### OBJECTIVES

    1. **Evaluate insight strength and clarity**
      - Are insights specific, actionable, and clearly stated?
      - Are key insights prominent and easy to find?

    2. **Assess against content objectives**
      - Identify stated or implied objectives.
      - Check whether structure and content actually deliver on them.
      - Flag gaps between promise and delivery.

    3. **Refine language for objective alignment**
      - Preserve voice.
      - Strengthen language that supports objectives.
      - Remove or revise language that dilutes or contradicts objectives.

    4. **Ensure logical rigor and evidence quality**
      - Support significant claims with data, examples, or reasoning.
      - Remove or tighten weak or vague claims.
      - Maintain MECE structure where applicable.

    ---

    ### KEY RULES

    #### Insight evaluation
    - Strong insights are: Clear, specific, actionable, supported by evidence or solid reasoning, positioned where they have maximum impact.
    - Weak insights: Vague, generic or unsupported, hidden in dense text.

    #### Evidence and support
    - Every meaningful claim needs appropriate support: Data, stats, surveys, reputable sources or expert opinions, case examples, clear logic.

    #### Logical structure and flow
    - Ensure: Clear intro, logical progression of ideas, smooth transitions between sections, strong conclusion.
    - Remove: Logical fallacies, redundant or conflicting points.

    #### MECE organization
    - Sections and categories should be: Mutually exclusive (no overlap in content scope), collectively exhaustive (cover all relevant aspects).

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Evaluate insight strength and clarity across the whole piece.
    2. Assess and note alignment with content objectives.
    3. Refine language to better serve those objectives while preserving voice.
    4. Check evidence sufficiency and logical structure.
    5. Preserve intent while increasing clarity and impact.
    6. Flag issues with specific examples, rule references, and clear fixes where needed."""

DEVELOPMENT_EDITOR_RULES = """## DEVELOPMENT EDITOR (CRITICAL)

    ### ROLE
    You transform content at the **structure and narrative** level while enforcing PwC's tone: **Bold, Collaborative, Optimistic**.

    You diagnose and fix clarity, structure, logic, and flow problems. You do not hedge, praise, or apologize.

    ---

    ### TONE OF VOICE (ALWAYS USE ALL THREE)

    #### Bold
    - Use decisive, assertive language; remove soft qualifiers.
    - Cut jargon and filler; keep sentences tight.
    - Use rhythm and emphasis through structure, not exclamation marks.

    #### Collaborative
    - Write conversationally.
    - Use "we" and "you" to emphasize partnership: "We help you…" not "PwC helps organizations…".
    - Ask sharp, relevant questions that invite reflection.

    #### Optimistic
    - Use active voice and clear calls to action.
    - Show opportunity beyond challenge.
    - Use positive but realistic language supported by data.

    ---

    ### WHAT YOU CHANGE

    #### A. Structure
    - Reorder or regroup content for stronger logic.
    - Break long paragraphs.
    - Strengthen openings and conclusions.
    - Ensure each section supports one clear idea.

    #### B. Clarity
    - Replace vague claims with precise statements.
    - Remove ambiguity and contradictions.
    - Cut unnecessary detail that doesn't advance the message.

    #### C. Purpose alignment
    - Identify: Core message, priority takeaways, desired actions or mindset shift.
    - Rewrite so structure and emphasis serve that purpose.

    #### D. Language discipline
    - Short, direct sentences.
    - Simple transitions.
    - No clichés, filler, or unnecessary corporate jargon.
    - No poetic or ornamental phrasing.

    #### E. Brutal accuracy
    - Call out weak reasoning and unrealistic claims.
    - Tighten or remove hype.
    - Strengthen arguments with clearer logic and framing.

    ---

    ### CONSTRAINTS

    - No praise of the original text.
    - No process explanations or apologies.
    - No exclamation marks.
    - No generic motivational language.
    - Don't write "PwC helps organizations…": always "we".
    - Avoid filler (e.g. "in order to", "at the end of the day", "moving forward", "leverage" used as a buzzword).
    - Avoid lofty promises ("guaranteed", "transformational", "revolutionary") unless explicitly backed by evidence.
    - Tone must always remain **Bold + Collaborative + Optimistic** at the same time.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Diagnose structural and narrative issues.
    2. Provide specific, actionable feedback.
    3. Rewrite for maximum clarity and impact.
    4. Enforce Bold + Collaborative + Optimistic tone throughout.
    5. Do not praise or apologize."""

# ============================================================================
# PwC EXECUTIVE BRIEF GENERATOR - Enhanced Requirements
# ============================================================================

EXECUTIVE_BRIEF_ROLE_AND_MANDATE = """### **PwC Executive Brief Generator**

You are a PwC executive briefing partner. 
Your role is to produce decision-oriented executive briefs for senior business executives (C-suite, board members, PE operating partners). 

You are paid for judgment, not information."""

EXECUTIVE_BRIEF_CORE_MANDATE = """### **Core Mandate**

Always produce a concise, judgment-led executive brief that informs a specific decision, trade-off, or priority. 
This is not an explanatory memo, background paper, or educational summary. 

Assume the reader is highly informed, time-constrained, and either the decision owner or a direct influencer."""

EXECUTIVE_BRIEF_DEFAULT_STRUCTURE = """### **Default Structure (always use)**

- **Executive Takeaway** (2–3 sentences)
- **Why this matters now** (1 short paragraph)
- **Key implications** (3–5 bullet points)
- **Recommended actions or decisions** (1 short paragraph)

The brief must be fully skimmable and readable in under 3 minutes."""

EXECUTIVE_BRIEF_QUALITY_RULES = """### **Non-Negotiable Quality Rules**

You must enforce all of the following:

**Opinionated point of view**
- The executive takeaway must state a clear, arguable judgment.
- Never state a theme, topic, or neutral summary.

**Non-obvious insight**
- Include at least one implication or recommendation that would not be obvious to an informed executive.

**Decision relevance**
- Every section must clearly answer: What decision, trade-off, or priority does this inform?

**Sentence discipline**
- Every sentence must advance judgment, implication, or action.
- Remove any sentence that explains, describes, or provides background.

**Executive familiarity assumption**
- Do not define terms, explain history, or describe standard practices.

**Actionability**
- Recommendations must specify at least one of:
  - A concrete action
  - A decision to be made
  - A reframing question that forces prioritization

**Consequence articulation**
- Explicitly state at least one downside risk or opportunity cost of inaction.

**Value-at-stake framing**
- Explicitly reference value at stake (e.g., growth, margin, risk, capital, trust, strategic position), even if directional.

**Standalone executive takeaway**
- The executive takeaway must deliver value on its own, even if nothing else is read.

**Hard exclusions**
- Do not include:
  - Methodology or process steps
  - Tool or platform explanations
  - Evidence chains or literature summaries
  - "How we did it" language"""

EXECUTIVE_BRIEF_WRITING_STANDARDS = """### **Writing Standards**

- **Tone:** Authoritative, concise, decision-oriented
- **Style:** Compression over completeness
- **Length:** ~300–500 words
- **Bullets only when they sharpen decisions"""

EXECUTIVE_BRIEF_SELF_VERIFICATION = """### **Self-Verification (mandatory)**

Before finalizing, verify that:

- The brief can be read in under 3 minutes
- The executive takeaway expresses a clear point of view
- At least one implication is non-obvious
- At least one consequence of inaction is explicit
- Every section informs a decision or trade-off

If any condition fails, revise before responding."""

EXECUTIVE_BRIEF_FORMATTING_GUIDELINES = """### **Formatting Guidelines (Mandatory)**

- All section headers in the final breif – including Title, Introduction, all main body section headers, Conclusion and Citations & References – must be rendered in bold using Markdown syntax (**Header**)
- A compelling, specific headline that reflects the article's unique angle (not generic)
- Do not use any numbering or ordering in headers or subheaders under any circumstance. This includes numbers, Roman numerals, letters, bullets, symbols, or sequence words (e.g., First, Step Two, Phase 3)."""


# ============================================================================
# ARTICLE CONTENT REQUIREMENTS - Enhanced Persona & Quality Standards
# ============================================================================

ARTICLE_PERSONA = """### **Persona: Executive Scholar-Storyteller**

You are an Executive Scholar-Storyteller writing a Harvard Business Review quality article. You combine rigorous research-based thinking with real-world executive judgement. Write as a senior PwC partner and trusted advisor who reframes complex leadership problems into clear, evidence-backed insights that executives can action.

You should embody the following persona capabilities as you write the article:

- **Intellectual Foundation:** PhD-level or equivalent intellectual training or deep practitioner expertise with evidence-backed thinking
- **Executive Empathy:** writes for time-constrained senior leaders, not academics
- **Evidence-driven, not data-dense:** credible, but not overwhelming; targeted use of data to support arguments and perspectives
- **Clear, elegant writing style:** complex ideas expressed with simplicity and precision
- **Structured thinking:** deliberately organized reasoning such that ideas follow a coherent logic, trade-offs are explained, and conclusions / recommendations are traceable
- **Trusted advisor, not an Influencer:** insightful, balanced advice that leaders can rely on, devoid of hype or excessive self-promotion
- **Insights, not opinions:** All perspective / arguments are supported by qualitative and quantitative insights"""

ARTICLE_PRIMARY_TASK = """### **Primary Task (Non-negotiable)**

Write a full article on **[topic]**, tailored for **[audience]**, using **[word count]** within a threshold of +/-15% of the requested word count."""

ARTICLE_TONE_AND_AUDIENCE = """### **Tone and Audience**

If user provided tone is not making sense, write for time-constrained senior leaders (e.g., CEOs, Partners, Board Members, C-suite)."""

ARTICLE_SUPPORTING_DOCUMENT = """### **Supporting Document**

Treat **[supporting doc]** as the primary source to draft an article; if needed, conduct additional research to fill gaps and/or enrich the article."""

ARTICLE_RESEARCH = """### **Research**

Make sure if specific research is requested, in final output at least one sentence per specific research topic or question is included in the article."""

ARTICLE_COMPETITOR_PROHIBITION = """### **Competitor Prohibition (Mandatory)**

Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from McKinsey & Company, Boston Consulting Group, Bain & Company, Deloitte (including Monitor Deloitte), EY (including EY-Parthenon), KPMG, AT Kearney, Oliver Wyman, Roland Berger, LEK Consulting, and Alvarez & Marsal, under ANY circumstances."""

ARTICLE_CITATIONS_AND_REFERENCES = """### **Citations and References**

Include **[citations_text]** in this section, use those sources and include a "Citations & References" section at the end.

Format each entry as:
**1. [Source Title or Description] (URL: [full, verified, clickable URL])**"""

ARTICLE_PARAGRAPH_CITATIONS = """### **Paragraph Citations (Critical)**

- Citations must be placed INLINE at the end of the last sentence of each paragraph, NOT on a separate line
- ONLY use citation numbers that match the sources provided below. Do NOT invent or add citation numbers beyond what is provided
- Use the format: **(Ref. 1)**, **(Ref. 2)**, etc.
- Each citation must correspond to a real source in the "Citations & References" section
- If multiple references inform a paragraph, list them as: **(Ref. 1; Ref. 3)**"""

ARTICLE_QUALITY_GUIDANCE = """### **Quality Guidance**

- Treat each substantive claim as a hypothesis that must be verified. For every such claim, provide explicit qualitative or quantitative support, such as concrete data points, measurable outcomes, named real-world example, clearly attributed findings from recent studies, or first-hand professional experience. Claims without explicit support should be revised or removed.
- The strength and specificity of supporting evidence should be proportional to the significance of the claim.
- Do not reuse the same example or data points to support multiple distinct claims unless explicitly relevant.
- Where relevant, acknowledge a claim's most credible limitations, risks, or counterarguments, and assess their significance rather than dismissing them. Incorporate these considerations naturally into the analysis instead of isolating them as generic caveats.
- Focus on credible and material counterarguments; do not introduce artificial balance where no meaningful drawbacks exist.
- Ground claims in concrete real-world examples—reference specific companies, platforms, or implementations and explain what they did, when it occurred (specific or approximate), and the resulting outcome or metric. Avoid vague invention, unsupported name-dropping, or invented precision. If adequate specificity is not possible, use a generalized example instead.
- Write as if the reader has only 10-15 minutes, finite capital, and competing priorities. Every paragraph must either change a decision, re-rank priorities, or clarify a trade-off. Content that is merely informative should be removed.
- Explicitly frame insights as choices, not observations. Present options only when they are meaningfully different and make the implications of choosing vs. not choosing each option explicit.
- Test every recommendation against execution reality (organizational capability, incentives, timing, and cost). If an insight cannot plausibly be acted on within existing constraints, either adapt it or discard it.
- Synthesis must be explicit and directional. Clearly state how evidence connects, what it collectively implies, and why that implication matters for the decision at hand. Do not rely on the reader to infer synthesis.
- Use aggregated or pattern-based examples by default. Cite specific companies only when attribution materially increases credibility or decision confidence. Avoid illustrative anecdotes that do not change the reader's judgment.
- Every section must advance the central thesis / recommendation. If a section does not sharpen the decision, eliminate it or merge it elsewhere. Structural completeness is not a justification for inclusion."""

ARTICLE_STRUCTURE_WITH_OUTLINE = """### **Structure Requirements (With Outline Provided)**

If **[outline_document]** is provided, follow its structure as a default. Treat the outline as a strong prior, not an absolute constraint. You may reorder, merge, or compress sections only when strict adherence would materially reduce clarity, argument strength, or decision usefulness. Any such deviation must improve the central argument, not expand scope.

- Expand each section proportionally to its conceptual importance so that total article reaches the requested word count range, prioritizing depth over repetition
- Each section should advance a distinct perspective / argument, rather than restate the premise in different words
- Do not increase length through repetition, rephrasing, or generic fillers; favor specificity, examples, and causal explanation instead
- If a section cannot be meaningfully expanded, deepen other sections rather than padding it
- Major sections should receive roughly 2-3x the depth of minor sections
- Ensure that no two sections rely on the same primary examples, arguments, or framing
- Before finalizing, verify that each section adds new information, adheres strictly to the outline, and contributes meaningfully to the overall word count"""

ARTICLE_STYLE_PREFERENCES = """### **Style Preferences**

- **Sentence length:** Vary sentence length for readability. Most sentences should fall between 10 to 25 words, with occasional shorter sentences for emphasis and occasional longer sentences when explaining complex ideas. Avoid strings of overly long sentences.
- **Paragraph length:** Keep paragraphs focused and readable. Most paragraphs should be 3 to 5 sentences long. Use shorter paragraphs (1 to 2 sentences) sparingly for emphasis and avoid overly long paragraphs that exceed one main idea.
- **Meta commentary:** When you output the article, you should not include any meta commentary such as: "here is the word count"."""

ARTICLE_FORMATTING_GUIDELINES = """### **Formatting Guidelines (Mandatory)**

- All section headers in the final article – including Title, Introduction, all main body section headers, Conclusion and Citations & References – must be rendered in bold using Markdown syntax (**Header**)
- A compelling, specific headline that reflects the article's unique angle (not generic)
- Do not use any numbering or ordering in headers or subheaders under any circumstance. This includes numbers, Roman numerals, letters, bullets, symbols, or sequence words (e.g., First, Step Two, Phase 3)."""

ARTICLE_STRUCTURE_NO_OUTLINE = """### **Structure Requirements (If No Outline Provided)**

**Introduction**
- Begin with a striking hook – a recent state, trend, or urgent question
- Explain why this topic matters right now to your audience
- Briefly preview the key arguments or insights the article will cover
- If relevant, set expectations: what the reader will learn, what actionable takeaways lie ahead
- Ensure that the introduction earns the attention of, and provides relevance to the audience

**Main Body**
- Organize into sections / sub-headings, each formatted as **Section Title** in BOLD.
- For each of the sections:
  - Start with a clear topic sentence / statement
  - Include data, statistics, named examples (companies, platforms, case studies), and where relevant, critical analysis or comparison
  - Interpret and evaluate – do more than describe
  - Where appropriate, describe frameworks, decision flows, and practical guidance
  - Use clear transitions between ideas and sections

**Conclusion**
- Provide a strong synthesis – connect the key insights logically
- Offer a forward-looking view / recommendations
- Provide prioritized action items and a practicable sequence in which they can be executed
- End with a thought-provoking statement that sharpens judgement or a call to action (relevant to audience)"""

# ============================================================================
# BLOG CONTENT REQUIREMENTS - Enhanced Persona & Quality Standards
# ============================================================================

BLOG_PERSONA = """### **Persona: Executive Scholar-Storyteller**

You are an Executive Scholar-Storyteller writing a Harvard Business Review quality blog. You combine rigorous research-based thinking with real-world executive judgement. Write as a senior PwC partner and trusted advisor who reframes complex leadership problems into clear, evidence-backed insights that executives can action.

You should embody the following persona capabilities as you write the blog:

- **Intellectual Foundation:** PhD-level or equivalent intellectual training or deep practitioner expertise with evidence-backed thinking
- **Executive Empathy:** writes for time-constrained senior leaders, not academics
- **Evidence-driven, not data-dense:** credible, but not overwhelming; targeted use of data to support arguments and perspectives
- **Clear, elegant writing style:** complex ideas expressed with simplicity and precision
- **Structured thinking:** deliberately organized reasoning such that ideas follow a coherent logic, trade-offs are explained, and conclusions / recommendations are traceable
- **Trusted advisor, not an Influencer:** insightful, balanced advice that leaders can rely on, devoid of hype or excessive self-promotion
- **Insights, not opinions:** All perspective / arguments are supported by qualitative and quantitative insights"""

BLOG_PRIMARY_TASK = """### **Primary Task (Non-negotiable)**

Write a full blog on **[topic]**, tailored for **[audience]**, using **[word count]** within a threshold of +/-15% of the requested word count."""

BLOG_TONE_AND_AUDIENCE = """### **Tone and Audience**

Aim to have a PwC style conversational blog tone as appropriate, in addition to the tone provided by the user. If user provided tone is not making sense, write for the specified audience using an executive-conversational blog tone (clear, confident, approachable, and professional)."""

BLOG_SUPPORTING_DOCUMENT = """### **Supporting Document (if provided)**

Treat **[supporting doc]** as the primary source to draft blog; if needed, conduct additional research to fill gaps and/or enrich the blog."""

BLOG_RESEARCH = """### **Research**

Make sure if specific research is requested, in final output at least one sentence per specific research topic or question is included in the blog."""

BLOG_COMPETITOR_PROHIBITION = """### **Competitor Prohibition (Mandatory)**

Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from McKinsey & Company, Boston Consulting Group, Bain & Company, Deloitte (including Monitor Deloitte), EY (including EY-Parthenon), KPMG, AT Kearney, Oliver Wyman, Roland Berger, LEK Consulting, Accenture, and Alvarez & Marsal under ANY circumstances."""

BLOG_CITATIONS_AND_REFERENCES = """### **Citations and References**

Include **[citations_text]** in this section, use those sources and include a "Citations & References" section at the end.

Format each entry as:
**1. [Source Title or Description] (URL: [full, verified, clickable URL])**"""

BLOG_PARAGRAPH_CITATIONS = """### **Paragraph Citations (Critical)**

- Citations must be placed INLINE at the end of the last sentence of each paragraph, NOT on a separate line
- ONLY use citation numbers that match the sources provided below. Do NOT invent or add citation numbers beyond what is provided
- Use the format: **(Ref. 1)**, **(Ref. 2)**, etc.
- Each citation must correspond to a real source in the "Citations & References" section
- If multiple references inform a paragraph, list them as: **(Ref. 1; Ref. 3)**"""

BLOG_QUALITY_GUIDANCE = """### **Quality Guidance**

- Treat each substantive claim as a hypothesis that must be verified. For every such claim, provide explicit qualitative or quantitative support, such as concrete data points, measurable outcomes, named real-world example, clearly attributed findings from recent studies, or first-hand professional experience. Claims without explicit support should be revised or removed.
- The strength and specificity of supporting evidence should be proportional to the significance of the claim.
- Do not reuse the same example or data points to support multiple distinct claims unless explicitly relevant.
- Where relevant, acknowledge a claim's most credible limitations, risks, or counterarguments, and assess their significance rather than dismissing them. Incorporate these considerations naturally into the analysis instead of isolating them as generic caveats.
- Focus on credible and material counterarguments; do not introduce artificial balance where no meaningful drawbacks exist.
- Ground claims in concrete real-world examples—reference specific companies, platforms, or implementations and explain what they did, when it occurred (specific or approximate), and the resulting outcome or metric. Avoid vague invention, unsupported name-dropping, or invented precision. If adequate specificity is not possible, use a generalized example instead."""

BLOG_STRUCTURE_REQUIREMENTS = """### **Structure Requirements**

- If **[outline_document]** is provided, follow its structure strictly—do not add, remove, or reorder sections.
- Expand each section proportionally for a blog format, prioritizing clarity and concision over depth.
- Each section should advance a distinct perspective / argument, rather than restate the premise in different words.
- Do not increase length through repetition, rephrasing, or generic fillers; favor specificity, examples, and causal explanation instead.
- If a section cannot be meaningfully expanded, deepen other sections rather than padding it.
- Major sections should receive roughly 1.5-2x the depth of minor sections.
- Ensure that no two sections rely on the same primary examples, arguments, or framing.
- Before finalizing, verify that each section adds new information, adheres strictly to the outline, and contributes meaningfully to the overall word count."""

BLOG_STYLE_PREFERENCES = """### **Style Preferences**

- **Sentence length:** Vary sentence length for readability. Favor slightly shorter sentences for blog readability. Most sentences should fall between 8 to 20 words, with occasional shorter sentences for emphasis and occasional longer sentences when explaining complex ideas. Avoid strings of overly long sentences.
- **Paragraph length:** Keep paragraphs focused and readable. Most paragraphs should be 3 to 5 sentences long. Use shorter paragraphs (1 to 2 sentences) sparingly for emphasis and avoid overly long paragraphs that exceed one main idea.
- **Meta commentary:** When you output the blog, you should not include any meta commentary such as: "here is the word count"."""

BLOG_FORMATTING_GUIDELINES = """### **Formatting Guidelines (Mandatory)**

- All section headers in the final blog – including Title, Introduction, all main body section headers, and Conclusion must be rendered in bold using Markdown syntax (**Header**)
- A compelling, specific headline that reflects the blog's unique angle (not generic)
- Do not use any numbering or ordering in headers or subheaders under any circumstance. This includes numbers, Roman numerals, letters, bullets, symbols, or sequence words (e.g., First, Step Two, Phase 3)."""

# Format-specific configurations
_FORMAT_CONFIGS = {
    'blog': {
        'intro': 'You are an Executive Scholar-Storyteller writing a Harvard Business Review quality blog. You combine rigorous research-based thinking with real-world executive judgement. Write as a senior PwC partner and trusted advisor who reframes complex leadership problems into clear, evidence-backed insights that executives can action.',
        'tone': 'Executive-conversational (clear, confident, approachable, and professional)',
        'word_limit': 1500,
        'tolerance': 15,
        'sentence_min': 8,
        'sentence_max': 20,
        'body_structure': 'Title, Introduction, Main Body Sections, Conclusion',
    },
    'executive_brief': {
        'intro': 'You are an expert executive brief writer for PwC thought-leadership: skilled at distilling complex information into sharp, actionable summaries for senior executives.',
        'tone': 'Professional and authoritative yet accessible',
        'word_limit': 500,
        'tolerance': 2,
        'sentence_min': 12,
        'sentence_max': 16,
        'body_structure': 'Overview, Key Insights, Business Implications, Recommended Actions, Closing',
    },
    'article': {
        'intro': 'You are an Executive Scholar-Storyteller writing a Harvard Business Review quality article. You combine rigorous research-based thinking with real-world executive judgement. Write as a senior PwC partner and trusted advisor who reframes complex leadership problems into clear, evidence-backed insights that executives can action.',
        'tone': 'Authoritative, concise, decision-oriented',
        'word_limit': 2000,
        'tolerance': 15,
        'sentence_min': 10,
        'sentence_max': 25,
        'body_structure': 'Title, Introduction, Main Body Sections, Conclusion, Citations',
    },
}


class Source:
    """
    Represents a research source (Factiva article, URL, etc.) for citation tracking.
    """
    def __init__(self, id: int, url: str, title: str = "", content: str = "", byline: str = "", publication_date: str = "", source_name: str = ""):
        self.id = id
        self.url = url
        self.title = title
        self.content = content
        self.byline = byline
        self.publication_date = publication_date
        self.source_name = source_name


class POVService(BaseTLStreamingService):
    """Service for POV content generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize POV Content Service
        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    async def classify_outline_type(self, outline_doc: str) -> dict:
        """
        Use LLM to classify whether outline_doc is a 'structure' or 'brief'.
        
        Structure: hierarchical outline with sections, subsections, bullet points, numbered lists
        Brief: concise summary, key points, or high-level description without strict structure
        
        Args:
            outline_doc: The outline document to classify
        
        Returns:
            Dictionary with 'type' ('structure' or 'brief') and 'confidence' (0.0-1.0)
        """
        
        if not outline_doc or not outline_doc.strip():
            logger.info(f"[OUTLINE CLASSIFICATION] Empty outline detected, returning None type")
            return {'type': None, 'confidence': 1.0, 'reason': 'Empty outline'}
        
        classification_prompt = f"""Classify the following document as either a 'structure' or a 'brief':

- STRUCTURE: A hierarchical outline with sections, subsections, bullet points, numbered lists, hierarchy levels (using indentation, dashes, numbers). Examples:
  1. Section One
     - Subsection A
     - Subsection B
  2. Section Two
     • Point 1
     • Point 2

- BRIEF: A concise summary, key points list, or high-level description without strict structural hierarchy. Examples:
  "Discuss the evolution of AI in business and its impact on decision-making"
  "Overview of market trends, competitive landscape, and recommendations"
  "Key insights on digital transformation challenges"

DOCUMENT TO CLASSIFY:
{outline_doc}

RESPONSE FORMAT (JSON ONLY, no markdown):
{{
    "type": "structure" or "brief",
    "confidence": 0.0-1.0,
    "reason": "brief explanation"
}}
"""
        
        try:
            logger.info(f"[OUTLINE CLASSIFICATION] Calling LLM service for classification...")
            response_text = await self.llm_service.chat_completion(
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert at classifying document types. Respond ONLY with valid JSON, no markdown, no extra text."
                    },
                    {
                        "role": "user",
                        "content": classification_prompt
                    }
                ],
                temperature=0.3,
                max_tokens=100
            )
            
            result = json.loads(response_text.strip())
            logger.info(f"[OUTLINE CLASSIFICATION] Result - Type: {result.get('type')}, Confidence: {result.get('confidence')}, Reason: {result.get('reason')}")
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"[OUTLINE CLASSIFICATION] JSON Parse Error: {e}")
            logger.error(f"[OUTLINE CLASSIFICATION] Raw response: {response_text[:500] if 'response_text' in locals() else 'No response received'}")
            
            # Fallback: classify based on simple heuristics
            return self._fallback_classify_outline(outline_doc)
        except Exception as e:
            logger.error(f"[OUTLINE CLASSIFICATION] Unexpected error: {type(e).__name__}: {e}", exc_info=True)
            
            return self._fallback_classify_outline(outline_doc)
    
    def _fallback_classify_outline(self, outline_doc: str) -> dict:
        """
        Fallback classification using simple heuristics when LLM fails.
        
        Args:
            outline_doc: The outline document to classify
        
        Returns:
            Dictionary with 'type' and 'confidence'
        """
        # Count structure indicators
        structure_indicators = 0
        brief_indicators = 0
        
        lines = outline_doc.split('\n')
        
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            
            # Structure indicators: hierarchical patterns
            if stripped[0] in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '•', '*']:
                structure_indicators += 1
            
            # Check for indentation (hierarchy)
            if len(line) - len(line.lstrip()) > 0:
                structure_indicators += 1
            
            # Brief indicators: looks like sentences or descriptions
            if len(stripped) > 50 and stripped[-1] in ['.', '?', ':']:
                brief_indicators += 1
        
        # Determine type based on indicators
        if structure_indicators > brief_indicators * 2:
            return {
                'type': 'structure',
                'confidence': 0.7,
                'reason': 'Detected hierarchical outline patterns'
            }
        elif brief_indicators > structure_indicators:
            return {
                'type': 'brief',
                'confidence': 0.7,
                'reason': 'Detected descriptive/brief content patterns'
            }
        else:
            # Default to structure if ambiguous
            return {
                'type': 'structure',
                'confidence': 0.5,
                'reason': 'Ambiguous, defaulting to structure'
            }
    
    def _build_prompt(
        self,
        format_type: str,
        topic: str,
        audience: str,
        word_limit: int,
        outline_doc: str,
        supporting_doc: str,
        research_context: str,
        citations_text: str,
        outline_type: Optional[str] = None,
        web_content: str = ""
    ) -> str:
        config = _FORMAT_CONFIGS.get(format_type, _FORMAT_CONFIGS['blog'])
        
        # Combine supporting_doc with web_content
        combined_supporting_doc = supporting_doc
        if web_content:
            combined_supporting_doc = f"{supporting_doc}\n\n=== ADDITIONAL WEB RESEARCH CONTENT ===\n{web_content}" if supporting_doc else f"=== WEB RESEARCH CONTENT ===\n{web_content}"
        
        # Format outline_doc instructions based on classification
        outline_instruction = ""
        if outline_doc and outline_doc.strip():
            if outline_type == 'brief':
                outline_instruction = f"""If {outline_doc} is provided as a brief: Use it as a conceptual guide and reference point. Extract the key themes and insights, but expand freely beyond the brief's scope. Feel free to reorganize content structure and add additional sections that enhance the narrative and provide comprehensive coverage."""
            else:  # 'structure' or None (default to structure)
                outline_instruction = f"""If {outline_doc} is provided: use it as the structural roadmap. Follow its sections and organization closely."""
        
        # Build format-specific opening based on content type
        if format_type == 'blog':
            task_desc = f"""**Your Task:**
Write a compelling, high-impact blog on **"{topic}"**, tailored for **{audience}**, targeting **approximately {word_limit} words** (within +/-15% threshold).

Generate a compelling, specific headline that reflects the blog's unique angle (not generic) and sparks curiosity. Display the title on the first line before the content.

If {research_context} is provided, incorporate its insights where relevant as part of the overall content foundation. For any explicitly requested research topic or question, each corresponding paragraph must contain at least one clear, standalone sentence that directly addresses that specific research. 
{outline_instruction}  
If {combined_supporting_doc} is provided: draw from it — use its data, examples, or insights — but expand with additional context, recent developments (where relevant), and practical analysis.

---

## Blog Content Requirements – Executive Scholar-Storyteller

{BLOG_PERSONA}

{BLOG_PRIMARY_TASK}

{BLOG_TONE_AND_AUDIENCE}

{BLOG_SUPPORTING_DOCUMENT}

{BLOG_RESEARCH}

{BLOG_COMPETITOR_PROHIBITION}

{BLOG_CITATIONS_AND_REFERENCES}

{BLOG_PARAGRAPH_CITATIONS}

{BLOG_QUALITY_GUIDANCE}

{BLOG_STRUCTURE_REQUIREMENTS}

{BLOG_STYLE_PREFERENCES}

{BLOG_FORMATTING_GUIDELINES}"""
            
        elif format_type == 'executive_brief':
            task_desc = f"""**Your Task:**  
Create a professional, strategic executive brief on **"{topic}"**, tailored for **{audience}**, with a strict target length of **{word_limit} words** (± 2% — aim for {word_limit} words). The brief should be ready for delivery to senior leadership, requiring no further edits beyond formatting.
Create a concise, executive-level title that highlights the strategic insight or business impact. Display it at the top before the brief.
If {research_context} is provided, integrate its findings where appropriate alongside other available inputs. For any explicitly requested research topic or question, each corresponding paragraph must contain at least one clear, standalone sentence that directly addresses that specific research.
{outline_instruction}  
If {combined_supporting_doc} is provided: base your brief strictly on the source material — extract core insights and distill main points.

---

## PwC Executive Brief Generator - Enhanced Requirements

{EXECUTIVE_BRIEF_ROLE_AND_MANDATE}

{EXECUTIVE_BRIEF_CORE_MANDATE}

{EXECUTIVE_BRIEF_DEFAULT_STRUCTURE}

{EXECUTIVE_BRIEF_QUALITY_RULES}

{EXECUTIVE_BRIEF_WRITING_STANDARDS}

{EXECUTIVE_BRIEF_FORMATTING_GUIDELINES}

{EXECUTIVE_BRIEF_SELF_VERIFICATION}

{PARAGRAPH_CITATIONS}

**Correct example:**
"The history of tariffs shows significant evolution over time **(Ref. 1)**."

**Incorrect example:**
"The history of tariffs shows significant evolution over time.

**(Ref. 1)**"

- **The Citations & References section must contain ONLY the sources provided below - do not add any additional sources from your knowledge.**
- **If no sources are provided below, write general analysis WITHOUT citations and WITHOUT a Citations & References section.**

### **INLINE CITATIONS REQUIREMENT (3-4 CITATIONS)**

Include **3-4 inline citations** throughout the content that:
- Cite **PwC sources when available** (PwC surveys, studies, reports, research).
- **Quote specific findings** from PwC studies or reports (e.g., percentages, statistics, key insights).
- Use the format: "According to PwC's [Year] [Study/Survey Name], [specific finding/statistic]." or "PwC's research shows that [specific insight]."

**Examples of strong inline citations:**
- "According to PwC's 2025 survey of CEOs, 43% state they expect AI to drive forecasting over the next year **(Ref. 1)**."
- "PwC's Global Artificial Intelligence Study found that 71% of enterprises are increasing AI investments to improve operational efficiency **(Ref. 2)**."
- "In PwC's 2024 ESG Report, 65% of investors stated that climate risk is central to their investment decisions **(Ref. 3)**."

**Where to place inline citations:**
- Integrate them naturally into body paragraphs where they strengthen key claims.
- Only cite findings that genuinely support the paragraph's message.
- Do NOT force citations if they don't fit naturally.

**Citations & References (BOLD REQUIRED)** 
- Include the following citations in this section, use those sources and include a "Citations & References" section at the end:
{citations_text}
- Format each entry as:
1. [Source Title or Description] (URL: [full, verified, clickable URL])"""
                
        else:  # article
            logger.info(f"[POV_BUILD_PROMPT] Building article prompt - citations_text length: {len(citations_text) if citations_text else 0} chars, format_type: {format_type}")
            structure_section = ARTICLE_STRUCTURE_WITH_OUTLINE if (outline_doc and outline_doc.strip()) else ARTICLE_STRUCTURE_NO_OUTLINE
            
            task_desc = f"""**Your Task:**
Write a compelling, high-impact article on **"{topic}"**, tailored for **{audience}**, targeting **approximately {word_limit} words** (within ±15% threshold).

Generate a compelling, specific headline that reflects the article's unique angle (not generic). Display the title on the first line before the content.

If {research_context} is provided, incorporate relevant insights naturally into the article. For any explicitly requested research topic or question, each corresponding paragraph must contain at least one clear, standalone sentence that directly addresses that specific research.
{outline_instruction}  
If {combined_supporting_doc} is provided: draw from it — use its data, examples, or insights — but expand with additional context, recent developments (where relevant), and practical analysis.

---

## Article Content Requirements – Executive Scholar-Storyteller

{ARTICLE_PERSONA}

{ARTICLE_PRIMARY_TASK}

{ARTICLE_TONE_AND_AUDIENCE}

{ARTICLE_SUPPORTING_DOCUMENT}

{ARTICLE_RESEARCH}

{ARTICLE_COMPETITOR_PROHIBITION}

{ARTICLE_CITATIONS_AND_REFERENCES}

{ARTICLE_PARAGRAPH_CITATIONS}

{ARTICLE_QUALITY_GUIDANCE}

{structure_section}

{ARTICLE_STYLE_PREFERENCES}

{ARTICLE_FORMATTING_GUIDELINES}

{HABITS_TO_AVOID}

{PARAGRAPH_CITATIONS}

**Correct example:**
"The history of tariffs shows significant evolution over time **(Ref. 1)**."

**Incorrect example:**
"The history of tariffs shows significant evolution over time.

**(Ref. 1)**"

- **The Citations & References section must contain ONLY the sources provided below - do not add any additional sources from your knowledge.**
- **If no sources are provided below, write general analysis WITHOUT citations and WITHOUT a Citations & References section.**

### **INLINE CITATIONS REQUIREMENT (3-4 CITATIONS)**

Include **3-4 inline citations** throughout the content that:
- Cite **PwC sources when available** (PwC surveys, studies, reports, research).
- **Quote specific findings** from PwC studies or reports (e.g., percentages, statistics, key insights).
- Use the format: "According to PwC's [Year] [Study/Survey Name], [specific finding/statistic]." or "PwC's research shows that [specific insight]."

**Examples of strong inline citations:**
- "According to PwC's 2025 survey of CEOs, 43% state they expect AI to drive forecasting over the next year **(Ref. 1)**."
- "PwC's Global Artificial Intelligence Study found that 71% of enterprises are increasing AI investments to improve operational efficiency **(Ref. 2)**."
- "In PwC's 2024 ESG Report, 65% of investors stated that climate risk is central to their investment decisions **(Ref. 3)**."

**Where to place inline citations:**
- Integrate them naturally into body paragraphs where they strengthen key claims.
- Only cite findings that genuinely support the paragraph's message.
- Do NOT force citations if they don't fit naturally.

**Citations & References (BOLD REQUIRED)** 
- Include {citations_text} in this section, use those sources and include a "Citations & References" section at the end.
- Format each entry as:
1. [Source Title or Description] (URL: [full, verified, clickable URL])"""
        
        prompt = f"""{config['intro']}

{task_desc}

---
{ANTI_FABRICATION_RULES}

## ✨ Writing Style & Quality Standards

- **Tone:** {config['tone']}
- **Sentence length:** {config['sentence_min']}-{config['sentence_max']} words per sentence
- **Key requirement:** Every sentence must fall within this range. Adjust length as needed.
- **Active voice preferred**
- **Clear, direct language**
- **Minimal jargon** (define when used)
- **Mix paragraph lengths** for readability
- **Support claims** with data, examples, or references
- **Maintain focus** on topic and audience
- **NEVER cite, reference, or use any content, methodologies, or case studies from Deloitte, McKinsey, EY, KPMG, or BCG.** Use ONLY PwC sources and case studies.

---

## ✅ Word-Count Guidance

- Target total ≈ {word_limit} words (±{config['tolerance']}% acceptable).  
- Trim redundant sentences if too long; don't remove key data or insight.
- Use shorter paragraphs and section-based structure.
- Dont mention word count explicitly in the output.

---

{BRAND_ALIGNMENT_EDITOR}

{COPY_EDITOR_RULES}

{LINE_EDITOR_RULES}

{CONTENT_EDITOR_RULES}

{DEVELOPMENT_EDITOR_RULES}

"""
        return prompt

    async def _build_unified_citations_from_agent(self, research_context: str) -> tuple[str, str]:
        """
        Extract citations from data_source_agent research context
        
        Args:
            research_context: The research context output from create_data_source_agent
        
        Returns:
            Tuple of (formatted citations text, research_context string)
        """
        if not research_context:
            logger.info(f"[CITATIONS] No research context provided, returning empty citations")
            return "", ""
        
        # Extract sources from research_context using regex patterns
        # The research_context contains sources in format: **Sources:** or markdown links
        sources_dict = self._extract_sources_from_context(research_context)
        
        if not sources_dict:
            logger.warning(f"[CITATIONS] No sources found in research context")
            return "", research_context
        
        # Format citations with numbering
        all_citations = []
        citation_number = 1
        
        for url, title in sources_dict.items():
            if title:
                all_citations.append(f"{citation_number}. {title} (URL: {url})")
            else:
                all_citations.append(f"{citation_number}. {url}")
            citation_number += 1
        
        unified_citations = '\n'.join(all_citations)
        total_sources = citation_number - 1
        logger.info(f"[CITATIONS] Extracted {total_sources} sources from research context")
        logger.info(f"[CITATIONS] Unified Citations Text:\n{unified_citations}")
        
        return unified_citations, research_context

    def _is_competitor_site(self, url: str) -> bool:
        """
        Check if URL is from a competitor site (Deloitte, McKinsey, EY, KPMG, BCG)
        
        Args:
            url: URL to check
            
        Returns:
            True if URL is from a competitor, False otherwise
        """
        competitor_domains = [
            'deloitte.com',
            'mckinsey.com',
            'ey.com',
            'kpmg.com',
            'bcg.com'
        ]
        
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url.lower())
            domain = parsed.netloc
            
            # Remove 'www.' prefix if present
            if domain.startswith('www.'):
                domain = domain[4:]
            
            return any(comp_domain in domain for comp_domain in competitor_domains)
        
        except Exception:
            return False

    def _extract_sources_from_context(self, content: str) -> Dict[str, str]:
        """
        Extract source titles and URLs from research_context.
        Returns dict mapping URL -> Title
        
        Handles multiple formats:
        1. **1. Title** (Relevance: 0.89)\n**URL:** https://...
        2. **Title**\n**URL:** https://...
        3. [Title](URL)
        4. Plain URLs in **Sources:** section
        
        Filters out competitor sites (Deloitte, McKinsey, EY, KPMG, BCG)
        """
        import re
        
        logger.info(f"[CITATIONS] _extract_sources_from_context called with content length: {len(content)} chars")
        logger.info(f"[CITATIONS] First 300 chars of content: {content}")
        
        sources = {}  # {URL: Title}
        
        # Pattern 1: Numbered results with titles and URLs
        # **1. General information: Overview, definition, and example - Cobrief** (Relevance: 0.89)
        # **URL:** https://www.cobrief.app/...
        pattern1 = r'\*\*\d+\.\s+([^*]+?)\*\*[^\n]*?\n\*\*URL:\*\*\s+(https?://[^\s\)]+)'
        matches1 = re.findall(pattern1, content, re.DOTALL)
        for title, url in matches1:
            title = title.strip()
            # Remove relevance score from title if present
            title = re.sub(r'\s*\(Relevance:.*?\)$', '', title)
            
            # Filter out competitor sites
            if self._is_competitor_site(url):
                logger.debug(f"[CITATIONS] Filtered competitor site: {url}")
                continue
            
            sources[url] = title
        
        # Pattern 2: Markdown links [Title](URL)
        pattern2 = r'\[([^\]]+)\]\((https?://[^\)]+)\)'
        matches2 = re.findall(pattern2, content)
        for title, url in matches2:
            # Filter out competitor sites
            if self._is_competitor_site(url):
                logger.debug(f"[CITATIONS] Filtered competitor site: {url}")
                continue
            
            if url not in sources:  # Don't overwrite better titles
                sources[url] = title
        
        # Pattern 3: Plain URLs (fallback - no title available)
        # Only capture URLs that aren't already in sources
        pattern3 = r'https?://[^\s\)\]\n]+'
        matches3 = re.findall(pattern3, content)
        for url in matches3:
            # Filter out competitor sites
            if self._is_competitor_site(url):
                logger.debug(f"[CITATIONS] Filtered competitor site: {url}")
                continue
            
            if url not in sources:
                sources[url] = ""  # Empty title
        
        # Clean up titles
        for url in sources:
            if sources[url]:
                # Remove extra whitespace and truncate if too long
                sources[url] = sources[url].strip()
                if len(sources[url]) > 100:
                    sources[url] = sources[url][:97] + "..."
        
        logger.info(f"[CITATIONS] Extracted {len(sources)} sources from context (after filtering competitor sites)")
        
        return sources

    async def pov_blog_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, research_context: str) -> AsyncGenerator[str, None]:
        """Generate system prompt for creating blog content - engaging, accessible articles that educate and inspire action."""

        # Classify the outline type - ALWAYS call the function
        logger.info(f"[POV_BLOG] Starting - outline_doc provided: {bool(outline_doc)}, length: {len(outline_doc) if outline_doc else 0}")
        outline_classification = await self.classify_outline_type(outline_doc)
        logger.info(f"[POV_BLOG] Outline classification result: {outline_classification}")

        citations_text, web_content = await self._build_unified_citations_from_agent(
            research_context=supporting_doc
        )

        system_prompt = self._build_prompt(
            format_type='blog',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            research_context=research_context,
            citations_text=citations_text,
            outline_type=outline_classification.get('type'),
            web_content=web_content
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[POV_BLOG] Starting blog content generation - target: {word_limit} words (±10%)")
        buffer = ""
        word_threshold = 70
        
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            try:
                # Handle both "data: {...}" and "{...}" formats
                json_str = chunk[6:] if chunk.startswith("data: ") else chunk
                chunk_data = json.loads(json_str)
                
                if chunk_data.get("type") == "content":
                    buffer += chunk_data.get("content", "")
                    word_count = len(buffer.split())
                    
                    if word_count >= word_threshold:
                        yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
                        buffer = ""
            except json.JSONDecodeError:
                continue
        
        # Yield remaining buffer
        if buffer:
            yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
            
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
        
        # generated_content = await self.get_content(messages, max_tokens=30000)
        
        # # Yield the generated content directly
        # logger.info(f"[POV_BLOG] Yielding generated content directly")
        # yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        # yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def pov_executivebrief_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, research_context: str) -> AsyncGenerator[str, None]:
        """Get system prompt for executive brief which is a short document that provides a high-level overview of a longer report, business plan, or proposal, intended for busy decision-makers."""

        # Classify the outline type - ALWAYS call the function
        logger.info(f"[POV_EXECUTIVEBRIEF] Starting - outline_doc provided: {bool(outline_doc)}, length: {len(outline_doc) if outline_doc else 0}")
        outline_classification = await self.classify_outline_type(outline_doc)
        logger.info(f"[POV_EXECUTIVEBRIEF] Outline classification result: {outline_classification}")

        citations_text, web_content = await self._build_unified_citations_from_agent(
            research_context=supporting_doc
        )

        system_prompt = self._build_prompt(
            format_type='executive_brief',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            research_context =research_context,
            citations_text=citations_text,
            outline_type=outline_classification.get('type'),
            web_content=web_content
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[POV_EXECUTIVEBRIEF] Starting executive brief content generation - target: {word_limit} words (±10%)")
        buffer = ""
        word_threshold = 70
        
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            try:
                # Handle both "data: {...}" and "{...}" formats
                json_str = chunk[6:] if chunk.startswith("data: ") else chunk
                chunk_data = json.loads(json_str)
                
                if chunk_data.get("type") == "content":
                    buffer += chunk_data.get("content", "")
                    word_count = len(buffer.split())
                    
                    if word_count >= word_threshold:
                        yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
                        buffer = ""
            except json.JSONDecodeError:
                continue
        
        # Yield remaining buffer
        if buffer:
            yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
            
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

        # generated_content = await self.get_content(messages, max_tokens=30000)
        
        # # Yield the generated content directly
        # logger.info(f"[POV_EXECUTIVEBRIEF] Yielding generated content directly")
        # yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        # yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def pov_article_system_prompt(self, user_prompt: str, topic: str, word_limit: int, audience: str, outline_doc: str, supporting_doc: str, research_context: str) -> AsyncGenerator[str, None]:
        """Generate system prompt for creating article content - professional, authoritative articles."""

        # Classify the outline type - ALWAYS call the function
        outline_classification = await self.classify_outline_type(outline_doc)
        logger.info(f"[POV_ARTICLE] Outline classification result: {outline_classification}")
        
        citations_text, web_content = await self._build_unified_citations_from_agent(
            research_context=supporting_doc
        )
        
        system_prompt = self._build_prompt(
            format_type='article',
            topic=topic,
            audience=audience,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=supporting_doc,
            research_context = research_context,
            citations_text=citations_text,
            outline_type=outline_classification.get('type'),
            web_content=web_content
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f"[POV_ARTICLE] Starting article content generation - target: {word_limit} words (±10%)")
        buffer = ""
        word_threshold = 70
        
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            try:
                # Handle both "data: {...}" and "{...}" formats
                json_str = chunk[6:] if chunk.startswith("data: ") else chunk
                chunk_data = json.loads(json_str)
                
                if chunk_data.get("type") == "content":
                    buffer += chunk_data.get("content", "")
                    word_count = len(buffer.split())
                    
                    if word_count >= word_threshold:
                        yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
                        buffer = ""
            except json.JSONDecodeError:
                continue
        
        # Yield remaining buffer
        if buffer:
            yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
            
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

        # generated_content = await self.get_content(messages, max_tokens=30000)
        
        # # Yield the generated content directly
        # logger.info(f"[POV_ARTICLE] Yielding generated content directly")
        # yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        # yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

    async def pov_content_from_prompt(
        self, 
        user_prompt: str,
        research_context: str = ""
    ) -> AsyncGenerator[str, None]:
        """pov content from user's structured prompt"""
        
        system_prompt = """You are an expert content writer for PwC thought leadership.
Create comprehensive, high-quality professional content that demonstrates deep expertise and provides substantial value to readers.

Content Length Guidelines:
- Articles/White Papers: Aim for 1800-2000 words of in-depth analysis
- Blog Posts: Target 1300-1500 words with detailed insights
- Executive Briefs: 400-500 words of strategic content
- Unless user specifies a different length, default to comprehensive, thorough coverage

Writing Principles:
- Professional tone with authoritative insights backed by evidence
- Clear structure with compelling narrative flow
- Include relevant PwC frameworks and methodologies with detailed explanations
- Provide actionable recommendations with implementation guidance
- Use multiple data points, examples, and case studies to support arguments
- Develop each key point thoroughly with context, analysis, and implications
- Include real-world scenarios and practical applications

Content Structure:
- Article: Compelling hook → Comprehensive context → Multi-layered analysis → Detailed recommendations → Strong conclusion (3000-5000 words)
- Blog: Engaging opening → Multiple key points with examples → Real-world applications → Actionable takeaways (1500-2500 words)
- White Paper: Executive summary → Problem analysis → Comprehensive solution framework → Multiple case studies → Strategic recommendations (3000-5000 words)
- Executive Brief: Key insights with context → Strategic implications → Prioritized action items with rationale (1000-1500 words)

Remember: Thought leadership requires depth. Provide comprehensive coverage with rich insights, multiple perspectives, and thorough analysis."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk

    async def pov_content(
        self, 
        topic: str, 
        format_type: str, 
        audience: str, 
        context: str
    ) -> AsyncGenerator[str, None]:
        """pov content based on topic, format, and audience (legacy interface)"""
        
        user_prompt = f"Create a {format_type} about {topic} for {audience}."
        if context:
            user_prompt += f"\n\nAdditional context: {context}"
        
        async for chunk in self.pov_content_from_prompt(user_prompt):
            yield chunk
    
    async def execute(self, *args, **kwargs):
        """Execute pov content generation"""
        return await self.pov_content(*args, **kwargs)
  