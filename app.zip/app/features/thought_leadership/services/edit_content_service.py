from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.prompts.edit_content_prompt import build_editor_system_prompt
from typing import Sequence, Dict, List, Optional, Literal
from pydantic import BaseModel, Field
import re
import json
import ast
import logging

logger = logging.getLogger(__name__)

# Pydantic models for editorial feedback structure
class EditorialFeedbackItem(BaseModel):
    """Individual feedback item with approve/decline capability"""
    issue: str = Field(..., description="Description of the issue found")
    fix: str = Field(..., description="The proposed fix/replacement text")
    impact: str = Field(..., description="Impact of this change")
    rule_used: str = Field(..., description="Editorial rule that was applied")
    priority: Literal["Critical", "Important", "Enhancement"] = Field(..., description="Priority level")
    approved: Optional[bool] = Field(None, description="User approval status: True=approved, False=declined, None=pending")

class ServiceEditorialFeedback(BaseModel):
    """Editorial feedback for a specific service/editor"""
    development: List[EditorialFeedbackItem] = Field(default_factory=list)
    content: List[EditorialFeedbackItem] = Field(default_factory=list)
    copy: List[EditorialFeedbackItem] = Field(default_factory=list)
    line: List[EditorialFeedbackItem] = Field(default_factory=list)
    brand: List[EditorialFeedbackItem] = Field(default_factory=list, alias="brand-alignment")
    
    class Config:
        populate_by_name = True

def normalize_for_comparison(text: str) -> str:
    """Normalize text for comparison (case-insensitive, markdown-stripped for auto-approval)"""
    if not text:
        return ''
    normalized = text.strip()
    
    # Strip markdown formatting for comparison
    # Remove **bold** (must do before *italic* to avoid conflicts)
    normalized = re.sub(r'\*\*([^*]+)\*\*', r'\1', normalized)
    # Remove *italic* (single asterisk, not part of **)
    normalized = re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)', r'\1', normalized)
    # Remove `code` (backticks)
    normalized = re.sub(r'`([^`]+)`', r'\1', normalized)
    # Remove markdown headers (# ## ### etc.)
    normalized = re.sub(r'#+\s*', '', normalized)
    # Remove markdown links [text](url) -> text
    normalized = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', normalized)
    # Remove markdown images ![alt](url) -> alt
    normalized = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', r'\1', normalized)
    
    # Normalize whitespace
    normalized = re.sub(r'\s+', ' ', normalized)
    normalized = normalized.replace('\r\n', '\n').replace('\r', '\n')
    
    # Make case-insensitive for auto-approval comparison
    # This ensures paragraphs with only case or markdown formatting differences are auto-approved
    normalized = normalized.lower()
    return normalized

def validate_string_equality(original: str, edited: str) -> bool:
    if not original and not edited:
        return True
    
    normalized_original = normalize_for_comparison(original or '')
    normalized_edited = normalize_for_comparison(edited or '')
    
    if normalized_original == normalized_edited:
        return True
    
    escaped_original = re.escape(normalized_original)
    pattern = re.compile(f'^{escaped_original}$', re.UNICODE)
    
    return bool(pattern.match(normalized_edited))



# Editor processing order (must match frontend EDITOR_ORDER in edit-content.utils.ts)
EDITOR_ORDER = ['development', 'content', 'line', 'copy', 'brand-alignment']

# Editor display names (must match frontend EDITOR_NAME_MAP in edit-content.utils.ts)
EDITOR_NAMES = {
    'development': 'Development Editor',
    'content': 'Content Editor',
    'line': 'Line Editor',
    'copy': 'Copy Editor',
    'brand-alignment': 'PwC Brand Alignment Editor'
}
EDITOR_TO_FEEDBACK_KEY = {
    'development': 'development',
    'content': 'content',
    'copy': 'copy',
    'line': 'line',
    'brand-alignment': 'brand'  # Editor type maps to 'brand' key in JSON
}


class EditContentService(BaseTLStreamingService):
    """Service for Edit Content workflow with optimized LLM parameters"""
    
    def _is_improvement_request(self, content: str) -> bool:
        """Detect if content is an improvement request for an already-revised article"""
        if not content or not content.strip():
            return False
        
        content_lower = content.lower()
        strong_indicators = [
            r"please review the following revised article.*apply.*additional improvements",
            r"revised article:",
        ]
        
        for pattern in strong_indicators:
            if re.search(pattern, content_lower):
                return True
        
        if "revised article" in content_lower:
            improvement_patterns = [
                r"apply.*improvement[s]?",
                r"additional.*improvement[s]?",
                r"improvement[s]?.*:",
            ]
            for pattern in improvement_patterns:
                if re.search(pattern, content_lower):
                    return True
        
        return False
    
    def _build_user_message(self, content: str, is_improvement: bool) -> str:
        """Build user message based on whether this is an improvement request or initial edit"""
        if is_improvement:
            return f"""This is an improvement iteration. The user has provided specific improvement instructions along with a previously revised article. Please apply ONLY the requested improvements while preserving all previous edits that aren't contradicted by the new instructions.

{content}"""
        else:
            return f"""Please review and edit the following content. 

CRITICAL INSTRUCTIONS:
- Process this content SEQUENTIALLY: section by section, paragraph by paragraph, sentence by sentence
- Read the ENTIRE document completely first to understand structure and context
- Then process EVERY section systematically from beginning to end
- Review EVERY paragraph within each section
- Check EVERY sentence within each paragraph
- Do NOT skip any content, even if it appears correct
- Verify ALL sections are processed (count them as you go)
- Ensure ALL editor rules are applied to ALL content

Content to edit:
{content}"""
    
    def _extract_feedback(self, response: str) -> str:
        """Extract feedback section from LLM response"""
        if not response:
            return ""
        
        feedback_match = re.search(r'===\s*FEEDBACK\s*===\s*([\s\S]*?)(?====\s*PARAGRAPH EDITS\s*===|$)', response, re.IGNORECASE)
        if feedback_match and feedback_match.group(1):
            feedback_text = feedback_match.group(1).strip()
            feedback_text = feedback_text.replace('=== PARAGRAPH EDITS ===', '').strip()
            feedback_text = feedback_text.replace('=== REVISED ARTICLE ===', '').strip()
            return feedback_text
        
        return ""
    def _extract_paragraph_edits(self, response: str, selected_editors: list[str] = None) -> list[dict]:
        """Extract paragraph-level edits from LLM response"""
        if not response:
            return []
        
        # First try to find the section between start and end markers
        paragraph_section = ""
        
        # Try to find content between start and end markers
        start_end_match = re.search(
            r'---\s*PARAGRAPH\s+EDITS\s+START\s*---\s*([\s\S]*?)---\s*END\s+JSON\s*---',
            response,
            re.IGNORECASE
        )
        
        if start_end_match:
            paragraph_section = start_end_match.group(1).strip()
        else:
            # Fallback: try to find section after === PARAGRAPH EDITS ===
            paragraph_edits_match = re.search(r'===\s*PARAGRAPH EDITS\s*===\s*([\s\S]*)', response, re.IGNORECASE)
            if paragraph_edits_match:
                paragraph_section = paragraph_edits_match.group(1).strip()
                # Remove end marker if present
                paragraph_section = re.sub(r'---\s*END\s+JSON\s*---.*$', '', paragraph_section, flags=re.IGNORECASE).strip()
            else:
                return []
        
        paragraph_edits = []
        paragraph_pattern = r'---\s*PARAGRAPH\s+(\d+)\s*---\s*([\s\S]*?)(?=---\s*PARAGRAPH|---\s*END\s+JSON|$)'
        matches = re.finditer(paragraph_pattern, paragraph_section, re.IGNORECASE | re.MULTILINE)
        
        for match in matches:
            paragraph_num = match.group(1)
            json_content = match.group(2).strip()
            
            try:
                cleaned_json = json_content.strip()
                
                # Remove markdown code blocks if present
                json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', cleaned_json, re.IGNORECASE)
                if json_match:
                    cleaned_json = json_match.group(1).strip()
                
                # Try to find JSON object - handle both single-line and multi-line
                # First, try to extract JSON object boundaries
                json_obj_match = re.search(r'\{[\s\S]*\}', cleaned_json)
                if json_obj_match:
                    cleaned_json = json_obj_match.group(0)
                
                # Clean up: remove any leading/trailing non-JSON text
                cleaned_json = cleaned_json.strip()
                
                # Parse JSON
                paragraph_data = json.loads(cleaned_json)
                
                if not isinstance(paragraph_data, dict):
                    logger.warning(f"Paragraph {paragraph_num} data is not a dict, skipping")
                    continue
                
                index = paragraph_data.get('index', int(paragraph_num) - 1)
                original = paragraph_data.get('original', '')
                edited = paragraph_data.get('edited', '')
                tags = paragraph_data.get('tags', [])
                editorial_feedback = paragraph_data.get('editorial_feedback', {})
                
                if not isinstance(tags, list):
                    tags = [tags] if tags else []
                
                if isinstance(editorial_feedback, dict):
                    # Only validate services that were selected
                    if selected_editors:
                        valid_services = []
                        for editor in selected_editors:
                            # Map editor type to feedback key using constant
                            feedback_key = EDITOR_TO_FEEDBACK_KEY.get(editor, editor)
                            if feedback_key not in valid_services:
                                valid_services.append(feedback_key)
                    else:
                        valid_services = ['development', 'content', 'copy', 'line', 'brand']
                    
                    normalized_feedback = {}
                    for key, value in editorial_feedback.items():
                        # Normalize 'brand-alignment' to 'brand' if present
                        if key == 'brand-alignment':
                            key = 'brand'
                        # Only include keys that are in valid_services (selected editors)
                        if key in valid_services and isinstance(value, list):
                            validated_items = []
                            for item in value:
                                if isinstance(item, dict):
                                    validated_item = {
                                        'issue': item.get('issue', ''),
                                        'fix': item.get('fix', ''),
                                        'impact': item.get('impact', ''),
                                        'rule_used': item.get('rule_used', ''),
                                        'priority': item.get('priority', 'Enhancement'),
                                        'approved': item.get('approved', None)
                                    }
                                    if validated_item['priority'] not in ['Critical', 'Important', 'Enhancement']:
                                        validated_item['priority'] = 'Enhancement'
                                    validated_items.append(validated_item)
                            # Always add to normalized_feedback (even if empty array, to ensure structure)
                            normalized_feedback[key] = validated_items
                        # If key not in valid_services, skip it (filter out unselected editors)
                    
                    # Ensure all selected editors have keys (even if empty)
                    for editor in selected_editors:
                        feedback_key = EDITOR_TO_FEEDBACK_KEY.get(editor, editor)
                        if feedback_key not in normalized_feedback:
                            normalized_feedback[feedback_key] = []
                    
                    editorial_feedback = normalized_feedback
                
                # Check if paragraph is unchanged (original == edited) for auto-approval
                is_identical = validate_string_equality(original, edited)
                
                paragraph_edits.append({
                    'index': index,
                    'original': original,
                    'edited': edited,
                    'tags': tags,
                    'editorial_feedback': editorial_feedback,
                    'autoApproved': is_identical,  # Auto-approve unchanged paragraphs (original == edited)
                    'approved': True if is_identical else None  # Auto-approve if unchanged
                })
                
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse JSON for paragraph {paragraph_num}: {e}")
                logger.debug(f"JSON content was: {json_content[:500]}")
                logger.debug(f"Cleaned JSON was: {cleaned_json[:500] if 'cleaned_json' in locals() else 'N/A'}")
                continue
            except Exception as e:
                logger.warning(f"Error processing paragraph {paragraph_num}: {e}")
                continue
        
        paragraph_edits.sort(key=lambda x: x['index'])
        return paragraph_edits

        
    def _merge_paragraph_edits(self, existing_edits: list[dict], new_edits: list[dict], editor_type: str) -> list[dict]:
        """Merge paragraph edits from new editor with existing edits"""
        if not existing_edits:
            return new_edits
        
        if not new_edits:
            return existing_edits
        
        # Map editor type to feedback key using constant
        current_editor_feedback_key = EDITOR_TO_FEEDBACK_KEY.get(editor_type, editor_type)
        
        # Create a map of existing edits by index
        edit_map = {edit['index']: edit for edit in existing_edits}
        
        # Merge new edits into existing
        for new_edit in new_edits:
            index = new_edit.get('index', 0)
            if index in edit_map:
                # Merge editorial_feedback - only add feedback from current editor
                existing_feedback = edit_map[index].get('editorial_feedback', {})
                new_feedback = new_edit.get('editorial_feedback', {})
                
                # Add new editor's feedback to existing (only for current editor's key)
                if current_editor_feedback_key in new_feedback:
                    existing_feedback[current_editor_feedback_key] = new_feedback[current_editor_feedback_key]
                
                # Note: We don't filter here because we'll filter at the end to ensure only selected editors
                
                # Update edited text from new editor
                edit_map[index]['edited'] = new_edit.get('edited', edit_map[index]['edited'])
                
                # Merge tags
                existing_tags = set(edit_map[index].get('tags', []))
                new_tags = set(new_edit.get('tags', []))
                edit_map[index]['tags'] = list(existing_tags | new_tags)
            else:
                # New paragraph edit
                edit_map[index] = new_edit
        
        return sorted(edit_map.values(), key=lambda x: x.get('index', 0))


    
    def _combine_feedback(self, feedback_list: list[str]) -> str:
        """Combine feedback from all editors into a single comprehensive feedback section"""
        if not feedback_list:
            return ""
        
        valid_feedbacks = [fb for fb in feedback_list if fb and fb.strip()]
        
        if not valid_feedbacks:
            return ""
        
        if len(valid_feedbacks) == 1:
            return valid_feedbacks[0]
        
        combined = "=== FEEDBACK ===\n\n"
        critical_issues = []
        important_improvements = []
        enhancements = []
        positive_elements = []
        
        for feedback in valid_feedbacks:
            critical_match = re.search(r'###\s*Critical\s*Issues?\s*([\s\S]*?)(?=###|$)', feedback, re.IGNORECASE)
            if critical_match:
                critical_issues.append(critical_match.group(1).strip())
            
            important_match = re.search(r'###\s*Important\s*Improvements?\s*([\s\S]*?)(?=###|$)', feedback, re.IGNORECASE)
            if important_match:
                important_improvements.append(important_match.group(1).strip())
            
            enhancement_match = re.search(r'###\s*Enhancements?\s*([\s\S]*?)(?=###|$)', feedback, re.IGNORECASE)
            if enhancement_match:
                enhancements.append(enhancement_match.group(1).strip())
            
            positive_match = re.search(r'###\s*Positive\s*Elements?\s*([\s\S]*?)(?=###|$)', feedback, re.IGNORECASE)
            if positive_match:
                positive_elements.append(positive_match.group(1).strip())
        
        if critical_issues:
            combined += "### Critical Issues\n\n"
            combined += "\n\n".join(critical_issues) + "\n\n"
        
        if important_improvements:
            combined += "### Important Improvements\n\n"
            combined += "\n\n".join(important_improvements) + "\n\n"
        
        if enhancements:
            combined += "### Enhancements\n\n"
            combined += "\n\n".join(enhancements) + "\n\n"
        
        if positive_elements:
            combined += "### Positive Elements\n\n"
            combined += "\n\n".join(positive_elements) + "\n\n"
        
        if not (critical_issues or important_improvements or enhancements or positive_elements):
            combined += "\n\n".join(valid_feedbacks)
        
        return combined.strip()
    
    def _split_into_paragraphs(self, content: str) -> list[str]:
        """Split content into paragraphs (matches frontend splitIntoParagraphs() in paragraph-edit.utils.ts)"""
        if not content or not content.strip():
            return []
        
        paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
        
        if not paragraphs:
            paragraphs = [content.strip()] if content.strip() else []
        
        return paragraphs
    
    def _is_title_or_heading(self, text: str) -> bool:
        """Detect if a paragraph is likely a title or heading"""
        if not text or not text.strip():
            return False
        
        # Strip markdown formatting for comparison
        normalized = text.strip()
        # Remove markdown bold **
        normalized = re.sub(r'\*\*([^*]+)\*\*', r'\1', normalized)
        # Remove markdown headers #
        normalized = re.sub(r'#+\s*', '', normalized)
        normalized = normalized.strip()
        
        # Title/heading characteristics:
        # 1. Short length (typically < 100 characters, but allow up to 150 for longer titles)
        # 2. Single line (no newlines)
        # 3. Often starts with capital letter
        # 4. Usually doesn't end with period
        # 5. Typically doesn't contain multiple sentences
        
        if len(normalized) > 150:
            return False
        
        if '\n' in normalized:
            return False
        
        # Check if it looks like a title (no period at end, or very short)
        if len(normalized) < 20:
            return True
        
        # If it ends with period and has multiple sentences, likely not a title
        if normalized.endswith('.') and normalized.count('.') > 1:
            return False
        
        # If it's short and doesn't end with period, likely a title
        if len(normalized) < 100 and not normalized.endswith('.'):
            return True
        
        # If it's very short (< 50 chars), likely a title regardless
        if len(normalized) < 50:
            return True
        
        return False
    
    def _normalize_text_for_comparison(self, text: str) -> str:
        """Normalize text for duplicate detection (strip markdown, case-insensitive)"""
        if not text:
            return ''
        normalized = text.strip()
        # Strip markdown formatting
        normalized = re.sub(r'\*\*([^*]+)\*\*', r'\1', normalized)
        normalized = re.sub(r'#+\s*', '', normalized)
        normalized = re.sub(r'\s+', ' ', normalized)
        return normalized.lower()
    
    def _remove_duplicate_titles(self, paragraphs: list[str]) -> list[str]:
        """Remove duplicate titles/headings from paragraph list, keeping only the first occurrence"""
        if not paragraphs:
            return paragraphs
        
        result = []
        seen_titles = set()
        
        for i, para in enumerate(paragraphs):
            normalized_para = self._normalize_text_for_comparison(para)
            
            # Check if this paragraph is a title/heading
            if self._is_title_or_heading(para):
                # If we've seen this title before, skip it (duplicate)
                if normalized_para in seen_titles:
                    continue
                # Mark this title as seen
                seen_titles.add(normalized_para)
            
            result.append(para)
        
        return result
    
    def _build_revised_article_from_paragraphs(self, paragraph_edits: list[dict]) -> str:
        """Build revised article by combining edited paragraphs from paragraph_edits"""
        if not paragraph_edits:
            return ""
        
        sorted_edits = sorted(paragraph_edits, key=lambda x: x.get('index', 0))
        edited_paragraphs = [edit.get('edited', '') for edit in sorted_edits if edit.get('edited')]
        return '\n\n'.join(edited_paragraphs)


    
    def _create_paragraph_edits_from_comparison(
        self, 
        original_paragraphs: list[str], 
        edited_paragraphs: list[str],
        editor_types: list[str]
    ) -> list[dict]:
        """Create paragraph edits by comparing original and edited paragraphs (matches frontend createParagraphEditsFromComparison() in paragraph-edit.utils.ts)"""
        paragraph_edits = []
        max_len = max(len(original_paragraphs), len(edited_paragraphs))
        
        for i in range(max_len):
            original = original_paragraphs[i] if i < len(original_paragraphs) else ""
            edited = edited_paragraphs[i] if i < len(edited_paragraphs) else ""
            paragraph_changed = original != edited

            is_identical = validate_string_equality(original, edited)
            
            tags = []
            for editor_type in editor_types:
                editor_name = EDITOR_NAMES.get(editor_type, editor_type)
                if paragraph_changed:
                    tags.append(f"{editor_name} (Editorial rule)")
                else:
                    tags.append(f"{editor_name} (Reviewed)")
            
            paragraph_edits.append({
                'index': i,
                'original': original,
                'edited': edited,
                'tags': tags,
                'autoApproved': is_identical,
                'approved': True if is_identical else None
            })
        
        return paragraph_edits
    
    
    def _yield_sse_event(self, event_type: str, data: dict) -> str:
        """Format and yield an SSE event"""
        event_data = {"type": event_type, **data}
        return f"data: {json.dumps(event_data)}\n\n"
    
    async def edit_content(
        self,
        content: str,
        editor_types: Sequence[str] | None = None,
        temperature: float = 0.0,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        max_tokens: int = 32000
    ):
        """Edit content based on specified editor types with sequential processing"""
        # Normalize content (matches frontend normalizeContent() in edit-content.utils.ts)
        if not content:
            normalized_content = ''
        else:
            normalized_content = content.strip()
            normalized_content = normalized_content.replace('\r\n', '\n').replace('\r', '\n')
            normalized_content = '\n'.join(line.rstrip() for line in normalized_content.split('\n'))
        
        # Detect if this is an improvement request
        is_improvement = self._is_improvement_request(normalized_content)
        
        # Normalize editor order (matches frontend normalizeEditorOrder() in edit-content.utils.ts)
        if editor_types:
            editor_types = list(editor_types)
            if 'brand-alignment' not in editor_types:
                editor_types.append('brand-alignment')
            valid_editors = [e for e in EDITOR_ORDER if e in editor_types]
        else:
            valid_editors = EDITOR_ORDER.copy()
        
        if 'brand-alignment' in valid_editors:
            valid_editors.remove('brand-alignment')
            valid_editors.append('brand-alignment')
        
        logger.info(f"[Edit Content] Content length: {len(normalized_content)}, "
                   f"Editor order: {valid_editors}, Temperature: {temperature}, "
                   f"Is improvement: {is_improvement}")
        
        try:
            current_content = normalized_content
            all_paragraph_edits = []
            combined_feedback = ""
            
            # Process each editor sequentially
            for editor_index, editor_type in enumerate(valid_editors):
                editor_name = EDITOR_NAMES.get(editor_type, editor_type)
                
                yield self._yield_sse_event('editor_progress', {
                    'editor': editor_type,
                    'current': editor_index + 1,
                    'total': len(valid_editors),
                    'message': f'Processing with {editor_name} ({editor_index + 1}/{len(valid_editors)})...'
                })
                
                # Build system prompt for THIS editor only
                system_prompt = build_editor_system_prompt(
                    [editor_type],  # Only current editor
                    is_improvement=is_improvement,
                    editor_index=editor_index,
                    selected_editors=valid_editors  # Pass all selected editors for JSON structure
                )
                
                # Always send the original content to each editor (not revised from previous)
                user_message = self._build_user_message(normalized_content, is_improvement)
                
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ]
                
                full_response = ""
                async for chunk in self.stream_response(
                    messages,
                    temperature=temperature,
                    top_p=top_p,
                    frequency_penalty=frequency_penalty,
                    presence_penalty=presence_penalty,
                    max_tokens=max_tokens
                ):
                    if chunk.startswith('data: '):
                        try:
                            data_str = chunk[6:].strip()
                            if not data_str:
                                continue
                            data = json.loads(data_str)
                            
                            if data.get('type') == 'content' and 'content' in data:
                                content_chunk = data['content']
                                full_response += content_chunk
                                yield self._yield_sse_event('editor_content', {
                                    'editor': editor_type,
                                    'content': content_chunk
                                })
                            elif data.get('type') == 'done':
                                pass
                            elif 'error' in data:
                                raise Exception(data['error'])
                        except json.JSONDecodeError as e:
                            logger.warning(f"Failed to parse SSE chunk as JSON: {e}")
                            full_response += chunk
                    else:
                        full_response += chunk
                
                # Check if editor processed successfully
                if not full_response or not full_response.strip():
                    logger.warning(f"Empty response from {editor_name}, marking as error")
                    yield self._yield_sse_event('editor_error', {
                        'editor': editor_type,
                        'error': f'{editor_name} returned empty response',
                        'will_continue': True  # Continue with next editor
                    })
                    continue
                
                # Extract feedback and paragraph edits from this editor's response
                editor_feedback = self._extract_feedback(full_response)
                if editor_feedback:
                    if combined_feedback:
                        combined_feedback += "\n\n"
                    combined_feedback += f"### {editor_name}\n\n{editor_feedback}"
                
                editor_paragraph_edits = self._extract_paragraph_edits(full_response, valid_editors)
                
                # Merge paragraph edits from this editor with previous editors
                all_paragraph_edits = self._merge_paragraph_edits(all_paragraph_edits, editor_paragraph_edits, editor_type)
                
                # Send editor_complete event (DO NOT update current_content - keep original for next editor)
                if editor_paragraph_edits:
                    yield self._yield_sse_event('editor_complete', {
                        'editor': editor_type,
                        'revised_content': self._build_revised_article_from_paragraphs(editor_paragraph_edits),
                        'paragraph_edits': editor_paragraph_edits,
                        'feedback': editor_feedback
                    })
                else:
                    logger.warning(f"Failed to extract paragraph edits from {editor_name}")
                    if full_response and full_response.strip():
                        yield self._yield_sse_event('editor_complete', {
                            'editor': editor_type,
                            'revised_content': normalized_content,  # Return original if extraction failed
                            'paragraph_edits': [],
                            'feedback': editor_feedback
                        })
            
            # Build final revised article from all paragraph edits
            if all_paragraph_edits:
                final_revised = self._build_revised_article_from_paragraphs(all_paragraph_edits)
            else:
                logger.warning("Failed to extract paragraph edits, using original content")
                final_revised = normalized_content
                # Try to create paragraph edits from comparison as fallback
                original_paragraphs = self._split_into_paragraphs(normalized_content)
                final_paragraphs = self._split_into_paragraphs(final_revised)
                all_paragraph_edits = self._create_paragraph_edits_from_comparison(
                    original_paragraphs,
                    final_paragraphs,
                    valid_editors
                )
            
            # Ensure only selected editors are in editorial_feedback structure
            # Filter out any unselected editor keys and ensure all selected editors have keys
            for paragraph_edit in all_paragraph_edits:
                existing_feedback = paragraph_edit.get('editorial_feedback', {})
                
                # Create new feedback dict with only selected editors
                filtered_feedback = {}
                
                # Add all selected editors to feedback (with empty arrays if missing)
                for editor_type in valid_editors:
                    # Map editor type to feedback key using constant
                    feedback_key = EDITOR_TO_FEEDBACK_KEY.get(editor_type, editor_type)
                    # Keep existing feedback if present, otherwise use empty array
                    filtered_feedback[feedback_key] = existing_feedback.get(feedback_key, [])
                
                # Remove any keys that aren't in selected editors
                paragraph_edit['editorial_feedback'] = filtered_feedback
            
            yield self._yield_sse_event('final_complete', {
                'combined_feedback': combined_feedback,
                'final_revised': final_revised,
                'paragraph_edits': all_paragraph_edits,
                'original_content': normalized_content
            })
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error processing content: {error_msg}", exc_info=True)
            
            yield self._yield_sse_event('editor_error', {
                'editor': 'all',
                'error': error_msg,
                'will_continue': False
            })
            
            # Return original content on error
            yield self._yield_sse_event('final_complete', {
                'combined_feedback': f"⚠️ Error processing content: {error_msg}",
                'final_revised': normalized_content,
                'paragraph_edits': [],
                'original_content': normalized_content
            })
    
    async def generate_final_article(
        self,
        original_content: str,
        paragraph_edits: list[dict],
        decisions: list[dict]
    ) -> str:
        """Generate final article using approved edits and original text for declined paragraphs.
        
        Combines auto-approved and user-approved paragraphs in the correct order by index.
        Ensures all paragraphs from original content are included.
        """
        decision_map = {d['index']: d['approved'] for d in decisions}
        original_paragraphs = self._split_into_paragraphs(original_content)
        
        # Create a map of paragraph_edits by index for quick lookup
        paragraph_edits_map = {edit.get('index', 0): edit for edit in paragraph_edits}
        
        # Determine the maximum index to process (from original content or paragraph_edits)
        max_index = max(
            len(original_paragraphs) - 1 if original_paragraphs else -1,
            max([edit.get('index', 0) for edit in paragraph_edits], default=-1)
        )
        
        # Process ALL paragraphs from original content in order (by index)
        final_paragraphs = []
        for index in range(max_index + 1):
            # Check if there's a paragraph_edit for this index
            if index in paragraph_edits_map:
                paragraph_edit = paragraph_edits_map[index]
                approved = decision_map.get(index, None)
                auto_approved = paragraph_edit.get('autoApproved', False)
                
                # Use edited version if explicitly approved OR auto-approved
                if approved is True or auto_approved:
                    final_paragraphs.append(paragraph_edit.get('edited', ''))
                else:
                    # Use original version for declined or pending edits
                    original_para = paragraph_edit.get('original', '')
                    if not original_para and index < len(original_paragraphs):
                        original_para = original_paragraphs[index]
                    final_paragraphs.append(original_para)
            else:
                # No paragraph_edit for this index - use original paragraph
                if index < len(original_paragraphs):
                    final_paragraphs.append(original_paragraphs[index])
        
        # Remove duplicate titles/headings (e.g., if title appears multiple times)
        final_paragraphs = self._remove_duplicate_titles(final_paragraphs)
        
        return '\n\n'.join(final_paragraphs)
    
    async def combine_approved_fixes(
        self,
        original_content: str,
        paragraph_edits: list[dict],
        temperature: float = 0.0,
        max_tokens: int = 32000
    ):
        """
        Combine approved fixes from paragraph edits and apply them using LLM.
        Streams the result in real-time.
        """
        # Filter approved fixes
        approved_fixes = []
        for edit in paragraph_edits:
            index = edit.get('index', 0)
            feedback = edit.get('editorial_feedback', {})
            
            # Collect all approved fixes for this paragraph
            # Check all possible editor types
            for editor_type in ['development', 'content', 'copy', 'line', 'brand-alignment']:
                # Map editor type to feedback key using constant
                feedback_key = EDITOR_TO_FEEDBACK_KEY.get(editor_type, editor_type)
                service_feedback = feedback.get(feedback_key, [])
                
                if not isinstance(service_feedback, list):
                    continue
                
                for item in service_feedback:
                    if isinstance(item, dict) and item.get('approved') is True:  # Only approved fixes
                        approved_fixes.append({
                            'paragraph_index': index,
                            'service': feedback_key,
                            'issue': item.get('issue', ''),
                            'fix': item.get('fix', ''),
                            'rule_used': item.get('rule_used', ''),
                            'priority': item.get('priority', '')
                        })
        
        if not approved_fixes:
            yield self._yield_sse_event('combine_error', {
                'error': 'No approved fixes to combine'
            })
            return
        
        # Build prompt for combining fixes
        fixes_text = "\n\n".join([
            f"Paragraph {fix['paragraph_index'] + 1} - {fix['service']}:\n"
            f"Issue: {fix['issue']}\n"
            f"Fix: {fix['fix']}\n"
            f"Rule: {fix['rule_used']}"
            for fix in approved_fixes
        ])
        
        system_prompt = f"""You are a content editor combining approved editorial fixes.

Your task is to apply the following approved fixes to the original content while preserving all other content exactly as it is.

APPROVED FIXES TO APPLY:
{fixes_text}

INSTRUCTIONS:
1. Apply ONLY the approved fixes listed above
2. Preserve all other content exactly as it appears in the original
3. Do not make any additional changes beyond the approved fixes
4. Maintain the exact structure and formatting of the original document
5. Output the complete revised document with all approved fixes applied

Output format:
=== REVISED CONTENT ===
[Complete revised document with approved fixes applied]
"""
        
        user_message = f"""Please apply the following approved fixes to this content:

ORIGINAL CONTENT:
{original_content}

APPROVED FIXES:
{fixes_text}

Apply only these fixes and preserve everything else exactly as it is."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        # Stream the response
        full_response = ""
        async for chunk in self.stream_response(
            messages,
            temperature=temperature,
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0,
            max_tokens=max_tokens
        ):
            if chunk.startswith('data: '):
                try:
                    data_str = chunk[6:].strip()
                    if not data_str:
                        continue
                    data = json.loads(data_str)
                    
                    if data.get('type') == 'content' and 'content' in data:
                        content_chunk = data['content']
                        full_response += content_chunk
                        yield self._yield_sse_event('combine_content', {
                            'content': content_chunk
                        })
                    elif data.get('type') == 'done':
                        # Extract revised content
                        revised_match = re.search(r'===\s*REVISED\s*CONTENT\s*===\s*([\s\S]*)', full_response, re.IGNORECASE)
                        if revised_match:
                            revised_content = revised_match.group(1).strip()
                        else:
                            revised_content = full_response.strip()
                        
                        yield self._yield_sse_event('combine_complete', {
                            'revised_content': revised_content,
                            'fixes_applied': len(approved_fixes)
                        })
                    elif 'error' in data:
                        raise Exception(data['error'])
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse SSE chunk as JSON: {e}")
                    full_response += chunk
            else:
                full_response += chunk
        
        # Final extraction if not done yet
        if full_response:
            revised_match = re.search(r'===\s*REVISED\s*CONTENT\s*===\s*([\s\S]*)', full_response, re.IGNORECASE)
            if revised_match:
                revised_content = revised_match.group(1).strip()
            else:
                revised_content = full_response.strip()
            
            yield self._yield_sse_event('combine_complete', {
                'revised_content': revised_content,
                'fixes_applied': len(approved_fixes)
            })
    
    async def combine_approved_fixes_from_selected_services(
        self,
        original_content: str,
        paragraph_edits: list[dict],
        selected_services: List[str],  # e.g., ['development', 'content']
        temperature: float = 0.0,
        max_tokens: int = 32000
    ):
        """
        Combine approved fixes from paragraph edits for selected services only.
        Filters approved fixes by selected services and applies them using LLM.
        Streams the result in real-time.
        
        Args:
            original_content: Original content text
            paragraph_edits: List of paragraph edits with editorial_feedback
            selected_services: List of service types to include (e.g., ['development', 'content'])
            temperature: LLM temperature
            max_tokens: Maximum tokens for LLM response
        """
        if not selected_services:
            yield self._yield_sse_event('combine_error', {
                'error': 'No services selected. Please select at least one service.'
            })
            return
        
        # Validate and normalize selected services
        valid_editor_types = ['development', 'content', 'copy', 'line', 'brand-alignment']
        normalized_services = []
        for service in selected_services:
            normalized = service.lower().strip()
            if normalized in valid_editor_types:
                normalized_services.append(normalized)
            elif normalized == 'brand':
                # Map 'brand' input to 'brand-alignment' editor type
                normalized_services.append('brand-alignment')
        
        if not normalized_services:
            yield self._yield_sse_event('combine_error', {
                'error': f'Invalid service types: {selected_services}. Valid services: development, content, copy, line, brand-alignment'
            })
            return
        
        # Filter approved fixes from selected services only
        approved_fixes = []
        for edit in paragraph_edits:
            index = edit.get('index', 0)
            feedback = edit.get('editorial_feedback', {})
            
            # Process each selected service
            for service in normalized_services:
                # Map editor type to feedback key using constant
                feedback_key = EDITOR_TO_FEEDBACK_KEY.get(service, service)
                
                # Get feedback for this service
                service_feedback = feedback.get(feedback_key, [])
                
                if not isinstance(service_feedback, list):
                    continue
                
                for item in service_feedback:
                    if isinstance(item, dict) and item.get('approved') is True:
                        approved_fixes.append({
                            'paragraph_index': index,
                            'service': feedback_key,  # Use 'brand' for consistency
                            'service_display_name': EDITOR_NAMES.get(service, service),
                            'issue': item.get('issue', ''),
                            'fix': item.get('fix', ''),
                            'rule_used': item.get('rule_used', ''),
                            'priority': item.get('priority', ''),
                            'impact': item.get('impact', '')
                        })
        
        if not approved_fixes:
            yield self._yield_sse_event('combine_error', {
                'error': f'No approved fixes found for selected services: {selected_services}'
            })
            return
        
        logger.info(f"[Combine Selected Services] Combining {len(approved_fixes)} approved fixes from services: {normalized_services}")
        
        # Build prompt for combining fixes
        fixes_text = "\n\n".join([
            f"Paragraph {fix['paragraph_index'] + 1} - {fix['service_display_name']}:\n"
            f"Issue: {fix['issue']}\n"
            f"Fix: {fix['fix']}\n"
            f"Rule: {fix['rule_used']}\n"
            f"Impact: {fix['impact']}\n"
            f"Priority: {fix['priority']}"
            for fix in approved_fixes
        ])
        
        # Build editor-specific system prompt using the same function as edit_content
        # This ensures editor-specific rules (Development, Content, Copy, Line, Brand) are included
        editor_system_prompt = build_editor_system_prompt(
            normalized_services,  # e.g., ['development', 'content', 'brand-alignment']
            is_improvement=False,
            editor_index=0,
            selected_editors=normalized_services
        )
        
        # Combine editor prompts with fixes-specific instructions
        system_prompt = f"""{editor_system_prompt}

---

# TASK: APPLY APPROVED FIXES FROM SELECTED SERVICES

SELECTED SERVICES: {', '.join([EDITOR_NAMES.get(s, s) for s in normalized_services])}

APPROVED FIXES TO APPLY:
{fixes_text}

CRITICAL INSTRUCTIONS FOR APPLYING FIXES:
1. Apply ONLY the approved fixes listed above from the selected services
2. Use the editor guidelines above for {', '.join([EDITOR_NAMES.get(s, s) for s in normalized_services])} to ensure fixes are applied correctly
3. Preserve all other content exactly as it appears in the original
4. Do not make any additional changes beyond the approved fixes
5. Maintain the exact structure and formatting of the original document
6. If multiple fixes apply to the same paragraph, combine them intelligently following the editor guidelines
7. Ensure each fix aligns with the specific editor's rules and guidelines shown above
8. Output the complete revised document with all approved fixes applied

Output format:
=== REVISED CONTENT ===
[Complete revised document with approved fixes applied]
"""
        
        user_message = f"""Please apply the following approved fixes from selected services to this content:

ORIGINAL CONTENT:
{original_content}

SELECTED SERVICES: {', '.join([EDITOR_NAMES.get(s, s) for s in normalized_services])}

APPROVED FIXES:
{fixes_text}

Apply only these fixes and preserve everything else exactly as it is."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        # Stream the response
        full_response = ""
        async for chunk in self.stream_response(
            messages,
            temperature=temperature,
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0,
            max_tokens=max_tokens
        ):
            if chunk.startswith('data: '):
                try:
                    data_str = chunk[6:].strip()
                    if not data_str:
                        continue
                    data = json.loads(data_str)
                    
                    if data.get('type') == 'content' and 'content' in data:
                        content_chunk = data['content']
                        full_response += content_chunk
                        yield self._yield_sse_event('combine_content', {
                            'content': content_chunk,
                            'selected_services': normalized_services
                        })
                    elif data.get('type') == 'done':
                        # Extract revised content
                        revised_match = re.search(r'===\s*REVISED\s*CONTENT\s*===\s*([\s\S]*)', full_response, re.IGNORECASE)
                        if revised_match:
                            revised_content = revised_match.group(1).strip()
                        else:
                            revised_content = full_response.strip()
                        
                        yield self._yield_sse_event('combine_complete', {
                            'revised_content': revised_content,
                            'fixes_applied': len(approved_fixes),
                            'selected_services': normalized_services
                        })
                    elif 'error' in data:
                        raise Exception(data['error'])
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse SSE chunk as JSON: {e}")
                    full_response += chunk
            else:
                full_response += chunk
        
        # Final extraction if not done yet
        if full_response:
            revised_match = re.search(r'===\s*REVISED\s*CONTENT\s*===\s*([\s\S]*)', full_response, re.IGNORECASE)
            if revised_match:
                revised_content = revised_match.group(1).strip()
            else:
                revised_content = full_response.strip()
            
            yield self._yield_sse_event('combine_complete', {
                'revised_content': revised_content,
                'fixes_applied': len(approved_fixes),
                'selected_services': normalized_services
            })
    
    async def execute(self, *args, **kwargs):
        return await self.edit_content(*args, **kwargs)

