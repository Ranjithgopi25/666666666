from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.tts_service import TTSService
from typing import AsyncGenerator, Optional, List, Dict
import logging
from app.features.thought_leadership.prompts.prompt_common import ANTI_FABRICATION_RULES
import json
import re

logger = logging.getLogger(__name__)

class PodcastService(BaseTLStreamingService):
    """Service for podcast generation workflow"""
    
    def __init__(self, llm_service):
        super().__init__(llm_service)
        self.tts_service = TTSService()

    def sanitize_for_tts(self, text: str, preserve_speaker_colons: bool = False) -> str:
        """
        Azure TTS-safe sanitization.
        Replaces colons that cause sentence skipping.
        If preserve_speaker_colons is True, preserves colons at the start of lines
        (used for dialogue speaker labels).
        """
        text = re.sub(r'[—]', '', text)
        
        if preserve_speaker_colons:
            # For dialogue: preserve colons at start of lines (speaker labels)
            # Replace colons that are NOT at the start of a line
            lines = text.split('\n')
            sanitized_lines = []
            for line in lines:
                # Check if line starts with a speaker label pattern (Name: or **Name:** or [Name]:)
                if re.match(r'^(?:\*\*)?(?:\[)?[^:\]]+(?:\])?(?:\*\*)?:\s*', line):
                    # This is a speaker label line - preserve the colon, sanitize the rest
                    parts = re.split(r'^((?:\*\*)?(?:\[)?[^:\]]+(?:\])?(?:\*\*)?:\s*)', line, maxsplit=1)
                    if len(parts) >= 3:
                        speaker_label = parts[1]
                        dialogue_text = parts[2]
                        # Sanitize only the dialogue text part
                        dialogue_text = re.sub(r':(\s|\n)', r'.\1', dialogue_text)
                        sanitized_lines.append(speaker_label + dialogue_text)
                    else:
                        sanitized_lines.append(line)
                else:
                    # Regular line - sanitize all colons
                    sanitized_line = re.sub(r':(\s|\n)', r'.\1', line)
                    sanitized_lines.append(sanitized_line)
            text = '\n'.join(sanitized_lines)
        else:
            # For monologue: replace all colons
            text = re.sub(r':(\s|\n)', r'.\1', text)
        
        text = re.sub(r'[#!*]', '', text)
        return text
    
    async def generate_podcast(
        self, 
        topic: str, 
        style: str, 
        duration: str, 
        context: str,
        references: Optional[List[Dict]] = None
    ) -> AsyncGenerator[str, None]:
        """Generate podcast script with dialogue or monologue style"""
        
        system_prompt = self._get_podcast_system_prompt(style, duration)
        
        user_message = f"Create a {style} podcast about: {topic}"
        if context:
            user_message += f"\n\nAdditional Context: {context}"
        
        if references:
            user_message += "\n\nReference Materials:"
            for ref in references:
                user_message += f"\n\n{ref['filename']}:\n{ref['content'][:2000]}"
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk
    
    async def generate_podcast_with_audio(
        self,
        content_text: str,
        style: Optional[str] = None,
        customization: Optional[str] = None,
        references: Optional[List[Dict]] = None,
        speaker1_name: Optional[str] = None,
        speaker1_voice: Optional[str] = None,
        speaker1_accent: Optional[str] = None,
        speaker2_name: Optional[str] = None,
        speaker2_voice: Optional[str] = None,
        speaker2_accent: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """Generate podcast script and synthesize audio with custom speakers"""
        
        try:
            # Ensure style has a default
            style = style or "dialogue"
            
            # Step 1: Send progress update
            yield f"data: {json.dumps({'type': 'progress', 'message': 'Generating podcast script...'})}\n\n"
            
            # Step 2: Generate script using LLM directly (not streaming)
            system_prompt = self._get_podcast_system_prompt_with_speakers(
                style, speaker1_name, speaker2_name
            )
            
            user_message = f"Create a {style} podcast based on this content:\n\n{content_text}"
            
            if customization:
                user_message += f"\n\nCustomization: {customization}"
            
            if references:
                user_message += "\n\nReference Materials:"
                for ref in references:
                    user_message += f"\n\n{ref['filename']}:\n{ref['content'][:2000]}"
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ]
            
            # Generate script using LLMService
            script_content = await self.llm_service.chat_completion(
                messages=messages,
                temperature=0.7,
                max_tokens=30000
            )
            
            # Step 3: Send script to client
            yield f"data: {json.dumps({'type': 'script', 'content': script_content})}\n\n"
            
            # Step 4: Generate audio
            yield f"data: {json.dumps({'type': 'progress', 'message': 'Synthesizing audio with Azure AI Speech...'})}\n\n"

            # For monologue, sanitize before TTS. For dialogue, tts_service will sanitize after parsing
            if style == "monologue":
                script_content = self.sanitize_for_tts(script_content)
            
            audio_base64 = self.tts_service.generate_podcast_audio(
                script=script_content,
                style=style,
                speaker1_voice=speaker1_voice,
                speaker1_accent=speaker1_accent,
                speaker2_voice=speaker2_voice,
                speaker2_accent=speaker2_accent,
                speaker1_name=speaker1_name,
                speaker2_name=speaker2_name
            )
            
            # Step 5: Send audio to client
            yield f"data: {json.dumps({'type': 'complete', 'audio': audio_base64})}\n\n"
            
        except Exception as e:
            logger.error(f"Error in podcast generation: {e}", exc_info=True)
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
    
    def _get_podcast_system_prompt(self, style: str, duration: str) -> str:
        """Get system prompt for podcast generation"""
        duration_guide = {
            "very short": "2-3 minutes (200-300 words)",
            "short": "5-7 minutes (1000-1200 words)",
            "medium": "10-15 minutes (2000-3000 words)",
            "long": "20-30 minutes (4000-6000 words)"
        }
#         ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
# - Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
# - Do NOT mention any report, survey, whitepaper, or study unless it exists.
# - If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
# - Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
# - **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

        if style == "dialogue":
            return f"""You are an expert podcast scriptwriter for PwC thought leadership content.

Create an engaging dialogue-format podcast script with two hosts discussing the topic.
Target duration: {duration_guide.get(duration, 'very short')}

Format:
- Host 1: [Name] - Sets up topics, asks insightful questions
- Host 2: [Name] - Provides expert analysis and insights

Guidelines:
- Natural, conversational tone with authentic exchanges
- Include PwC consulting perspectives and frameworks
- Add strategic insights and real-world examples
- Use rhetorical questions and engaging transitions
- Include brief pauses [PAUSE] for emphasis
- End with actionable takeaways
- Do not use Em dashes (—) in the script content.
{ANTI_FABRICATION_RULES}

Structure:
1. Opening hook and topic introduction
2. Main discussion with 3-4 key points
3. Practical implications and recommendations
4. Closing summary and call-to-action"""
        else:
            return f"""You are an expert podcast scriptwriter for PwC thought leadership content.

Create an engaging monologue-format podcast script with a single expert host.
Target duration: {duration_guide.get(duration, 'very short')}

Format:
- Single narrator presenting insights directly to the audience
- Professional yet conversational tone

Guidelines:
- Clear narrative arc with engaging storytelling
- Include PwC consulting perspectives and frameworks
- Provide strategic insights with real-world examples
- Use rhetorical questions to engage listeners
- Include brief pauses [PAUSE] for emphasis
- Vary pacing to maintain interest
- Do not use Em dashes (—) in the script content.
{ANTI_FABRICATION_RULES}

Structure:
1. Compelling opening hook
2. Problem/opportunity statement
3. Analysis with 3-4 key insights
4. Practical recommendations
5. Memorable closing and call-to-action"""
    
    def _get_podcast_system_prompt_with_speakers(
        self, 
        style: str, 
        speaker1_name: Optional[str] = None,
        speaker2_name: Optional[str] = None
    ) -> str:
        """Get system prompt with specific speaker names for podcast generation"""
        
        name1 = speaker1_name or "Host 1"
        name2 = speaker2_name or "Host 2"
        
#         ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
# - Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
# - Do NOT mention any report, survey, whitepaper, or study unless it exists.
# - If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
# - Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
# - **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

        if style == "dialogue":
            return f"""You are an expert podcast scriptwriter for PwC thought leadership content.

Create an engaging dialogue-format podcast script with two hosts discussing the topic.

Format Guidelines:
- Use exactly this format for speaker labels: "{name1}: [their dialogue]" and "{name2}: [their dialogue]"
- {name1} - Sets up topics, asks insightful questions, guides the conversation
- {name2} - Provides expert analysis, insights, and answers

Content Guidelines:
- Natural, conversational tone with authentic exchanges
- Include PwC consulting perspectives and frameworks
- Add strategic insights and real-world examples
- Use rhetorical questions and engaging transitions
- End with actionable takeaways
- Do not use Em dashes (—) in the script content.
{ANTI_FABRICATION_RULES}

Structure:
1. Opening hook and topic introduction
2. Main discussion with 3-4 key points
3. Practical implications and recommendations
4. Closing summary and call-to-action

IMPORTANT: Label each speaker's dialogue clearly with "{name1}:" or "{name2}:" at the start of each line."""
        else:
            return f"""You are an expert podcast scriptwriter for PwC thought leadership content.

Create an engaging monologue-format podcast script with a single expert host named {name1}.

Format:
- Single narrator ({name1}) presenting insights directly to the audience
- Professional yet conversational tone

Guidelines:
- Clear narrative arc with engaging storytelling
- Include PwC consulting perspectives and frameworks
- Provide strategic insights with real-world examples
- Use rhetorical questions to engage listeners
- Vary pacing to maintain interest
- Do not use Em dashes (—) in the script content.
{ANTI_FABRICATION_RULES}

Structure:
1. Compelling opening hook
2. Problem/opportunity statement
3. Analysis with 3-4 key insights
4. Practical recommendations
5. Memorable closing and call-to-action"""
    
    async def execute(self, *args, **kwargs):
        """Execute podcast generation"""
        # Return async generator directly without awaiting
        async for chunk in self.generate_podcast(*args, **kwargs):
            yield chunk
