import base64
import io
import logging
import os
import re
import shutil
import warnings
from pathlib import Path
from app.core.config import get_settings
from typing import List, Optional, Tuple

import azure.cognitiveservices.speech as speechsdk
from pydub import AudioSegment

# Suppress pydub's ffmpeg warning - we'll configure it ourselves
warnings.filterwarnings('ignore', message='.*ffmpeg.*', category=RuntimeWarning)

logger = logging.getLogger(__name__)


def _configure_ffmpeg():
    """Configure pydub to use ffmpeg if available"""
    # Check PATH first
    ffmpeg_path = shutil.which('ffmpeg')
    if ffmpeg_path:
        return ffmpeg_path
    
    # Check common Unix paths
    unix_paths = [
        '/opt/homebrew/bin/ffmpeg',
        '/usr/local/bin/ffmpeg',
        '/usr/bin/ffmpeg'
    ]
    for path in unix_paths:
        if os.path.exists(path):
            return path
    
    # Check Windows common paths
    if os.name == 'nt':  # Windows
        common_windows_paths = [
            r'C:\ffmpeg\bin\ffmpeg.exe',
            r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
            r'C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe',
            r'C:\tools\ffmpeg\bin\ffmpeg.exe',
            r'C:\Users\sguturu002\PwC_EDGE\MCX-stable-release-0.1.0\MCX-stable-release-0.1.0\backend\ffmpeg\bin\ffmpeg.exe'
        ]
        for path in common_windows_paths:
            if os.path.exists(path):
                return path
    
    return None


_ffmpeg_path = _configure_ffmpeg()

if _ffmpeg_path:
    AudioSegment.converter = _ffmpeg_path
    # NEW: Add the ffmpeg folder to PATH so pydub can also find ffprobe
    os.environ["PATH"] += os.pathsep + os.path.dirname(_ffmpeg_path)
    logger.info(f"ffmpeg found and configured: {_ffmpeg_path}")
else:
    logger.warning("ffmpeg not found. Audio processing may fail. Please install ffmpeg and ensure it's in your PATH.")


class TTSService:
    """Service for Text-to-Speech audio synthesis using Azure AI Speech"""
    
    VOICE_MAPPING = {
        ('Male', 'American'): 'en-US-GuyNeural',
        ('Male', 'British'): 'en-GB-RyanNeural',
        ('Male', 'Australian'): 'en-AU-WilliamNeural',
        ('Male', 'Canadian'): 'en-CA-LiamNeural',
        ('Male', 'Indian'): 'en-IN-PrabhatNeural',
        ('Female', 'American'): 'en-US-JennyNeural',
        ('Female', 'British'): 'en-GB-LibbyNeural',
        ('Female', 'Australian'): 'en-AU-NatashaNeural',
        ('Female', 'Canadian'): 'en-CA-ClaraNeural',
        ('Female', 'Indian'): 'en-IN-NeerjaNeural',
    }
    
    def __init__(self):
        """Initialize Azure Speech configuration"""
        settings = get_settings()
        self.speech_key = settings.AZURE_SPEECH_KEY
        self.speech_endpoint = settings.AZURE_SPEECH_ENDPOINT
        
        if not self.speech_key:
            raise RuntimeError("Azure Speech key is not configured. Set AZURE_SPEECH_KEY.")
        if not self.speech_endpoint:
            raise RuntimeError("Azure Speech endpoint is not configured. Set AZURE_SPEECH_ENDPOINT.")
    
    def _create_speech_config(self, voice_id: str) -> speechsdk.SpeechConfig:
        """Create a speech config for a specific voice"""
        speech_config = speechsdk.SpeechConfig(
            subscription=self.speech_key,
            endpoint=self.speech_endpoint
        )
        speech_config.speech_synthesis_voice_name = voice_id
        speech_config.set_speech_synthesis_output_format(
            speechsdk.SpeechSynthesisOutputFormat.Audio24Khz160KBitRateMonoMp3
        )
        # Store log file in the same directory as this script
        # script_dir = os.path.dirname(os.path.abspath(__file__))
        # log_file_path = os.path.join(script_dir, "azure_endpoint_speech_log.txt")
        # speech_config.set_property(speechsdk.PropertyId.Speech_LogFilename, log_file_path)
        return speech_config
    
    def get_voice_id(self, gender: str, accent: str) -> str:
        """Map gender and accent to Azure voice ID"""
        key = (gender, accent)
        voice = self.VOICE_MAPPING.get(key)  # type: ignore
        if not voice:
            logger.warning(f"No voice found for {gender}/{accent}, using default Azure voice")
            return 'en-US-GuyNeural' if gender == 'Male' else 'en-US-JennyNeural'
        return voice
    
    def parse_dialogue_script(self, script: str) -> List[Tuple[str, str]]:
        """
        Parse a dialogue script into (speaker_name, text) tuples
        Supports formats like:
        - Speaker Name: Text here
        - **Speaker Name:** Text here
        - [Speaker Name]: Text here
        """
        segments = []
        
        # Split by lines and process each
        lines = script.split('\n')
        current_speaker = None
        current_text = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Match speaker patterns: "Name:" or "**Name:**" or "[Name]:"
            speaker_match = re.match(r'^(?:\*\*)?(?:\[)?([^:\]]+)(?:\])?(?:\*\*)?:\s*(.*)$', line)
            
            if speaker_match:
                # Save previous speaker's text if any
                if current_speaker and current_text:
                    segments.append((current_speaker, ' '.join(current_text)))
                    current_text = []
                
                # Start new speaker
                current_speaker = speaker_match.group(1).strip()
                text_part = speaker_match.group(2).strip()
                if text_part:
                    current_text.append(text_part)
            elif current_speaker:
                # Continue current speaker's text
                current_text.append(line)
        
        # Add final speaker's text
        if current_speaker and current_text:
            segments.append((current_speaker, ' '.join(current_text)))
        
        return segments
    
    def synthesize_speech(self, text: str, voice_id: str) -> bytes:
        """Synthesize speech using Azure Speech Services"""
        try:
            max_chars = 3000
            audio_segments = []
            chunks = [text[i:i + max_chars] for i in range(0, len(text), max_chars)]
            print(chunks)

            counter = 0
            app_root = Path(__file__).parent.parent.parent.parent
            data_dir = app_root / "data"
            
            # Ensure data directory exists
            data_dir.mkdir(parents=True, exist_ok=True)
            
            for chunk in chunks:
                print(type(chunk),chunk)
                speech_config = self._create_speech_config(voice_id)
                # Capture audio in memory without routing to default speakers
                counter = counter + 1
                output_file = os.path.join(data_dir, f'output_temp_{counter}.mp3')
                 
                print(output_file)
                audio_config = speechsdk.audio.AudioOutputConfig(filename=output_file)
                # audio_config = speechsdk.audio.AudioOutputConfig(filename=f'data/output_temp_{counter}.mp3')
                # audio_config = speechsdk.audio.AudioOutputConfig(filename='C:\Users\sguturu002\projects\MCX\BSC-MCX-backend\app\data')
                
                synthesizer = speechsdk.SpeechSynthesizer(
                    speech_config=speech_config,
                    audio_config=audio_config
                )

                result = synthesizer.speak_text_async(chunk).get()
                
                if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                    audio_segments.append(result.audio_data)
                elif result.reason == speechsdk.ResultReason.Canceled:
                    cancellation = result.cancellation_details
                    error_details = getattr(cancellation, "error_details", "") or ""
                    raise RuntimeError(
                        f"Azure Speech synthesis canceled: {cancellation.reason}. {error_details}"
                    )
                else:
                    raise RuntimeError(f"Azure Speech synthesis failed with reason {result.reason}")
            
            if not audio_segments:
                raise RuntimeError("Azure Speech returned no audio data.")
            
            if len(audio_segments) > 1:
                if not _ffmpeg_path:
                    raise RuntimeError(
                        "ffmpeg is required for combining multiple audio chunks but was not found. "
                        "Please install ffmpeg and ensure it's in your PATH. "
                        "Download from https://ffmpeg.org/download.html"
                    )
                combined = AudioSegment.empty()
                for data in audio_segments:
                    audio_segment = AudioSegment.from_file(io.BytesIO(data), format='mp3')
                    combined += audio_segment
                
                output_buffer = io.BytesIO()
                combined.export(output_buffer, format='mp3')
                return output_buffer.getvalue()
            
            return audio_segments[0]
        except Exception as e:
            logger.error(f"Error synthesizing speech with Azure Speech: {e}")
            raise
    
    def generate_podcast_audio(
        self,
        script: str,
        style: str,
        speaker1_voice: Optional[str] = None,
        speaker1_accent: Optional[str] = None,
        speaker2_voice: Optional[str] = None,
        speaker2_accent: Optional[str] = None,
        speaker1_name: Optional[str] = None,
        speaker2_name: Optional[str] = None
    ) -> str:
        """
        Generate podcast audio from script
        Returns base64-encoded MP3 audio
        """
        try:
            if style == 'monologue':
                # Single speaker
                voice_id = self.get_voice_id(
                    speaker1_voice or 'Male',
                    speaker1_accent or 'American'
                )
                logger.info(f"Generating monologue with voice: {voice_id}")
                
                # Clean script for monologue (remove any speaker labels)
                clean_script = re.sub(r'^(?:\*\*)?(?:\[)?[^:\]]+(?:\])?(?:\*\*)?:\s*', '', script, flags=re.MULTILINE)
                
                audio_data = self.synthesize_speech(clean_script, voice_id)
                return base64.b64encode(audio_data).decode('utf-8')
                
            else:  # dialogue
                # Parse script into speaker segments
                segments = self.parse_dialogue_script(script)
                logger.info(f"Parsed {len(segments)} dialogue segments")
                
                if not segments:
                    raise ValueError("Could not parse dialogue script")
                
                # Map speaker names to voice IDs
                voice1_id = self.get_voice_id(
                    speaker1_voice or 'Male',
                    speaker1_accent or 'American'
                )
                voice2_id = self.get_voice_id(
                    speaker2_voice or 'Female',
                    speaker2_accent or 'American'
                )
                
                logger.info(f"Speaker 1 ({speaker1_name}): {voice1_id}, Speaker 2 ({speaker2_name}): {voice2_id}")
                
                # Check if ffmpeg is available for combining audio segments
                if not _ffmpeg_path:
                    raise RuntimeError(
                        "ffmpeg is required for combining dialogue audio segments but was not found. "
                        "Please install ffmpeg and ensure it's in your PATH. "
                        "Download from https://ffmpeg.org/download.html"
                    )
                
                # Generate audio for each segment
                combined_audio = AudioSegment.empty()
                
                for speaker_name, text in segments:
                    # Determine which voice to use based on speaker name
                    if speaker1_name and speaker1_name.lower() in speaker_name.lower():
                        voice_id = voice1_id
                    elif speaker2_name and speaker2_name.lower() in speaker_name.lower():
                        voice_id = voice2_id
                    else:
                        # Default: alternate or use first speaker's voice
                        voice_id = voice1_id
                    
                    logger.info(f"Synthesizing: {speaker_name[:30]}... with {voice_id}")
                    
                    # Synthesize this segment
                    audio_data = self.synthesize_speech(text, voice_id)
                    audio_segment = AudioSegment.from_mp3(io.BytesIO(audio_data))
                    
                    # Add slight pause between speakers (0.5 seconds)
                    combined_audio += audio_segment + AudioSegment.silent(duration=500)
                
                # Export final combined audio
                output_buffer = io.BytesIO()
                combined_audio.export(output_buffer, format='mp3')
                audio_bytes = output_buffer.getvalue()
                
                return base64.b64encode(audio_bytes).decode('utf-8')
                
        except Exception as e:
            logger.error(f"Error generating podcast audio: {e}")
            raise
