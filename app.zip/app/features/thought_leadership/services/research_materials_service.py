from app.infrastructure.llm.base_services import BaseTLStreamingService
from typing import AsyncGenerator, Optional, List, Dict
import logging

logger = logging.getLogger(__name__)

class ResearchMaterialsService(BaseTLStreamingService):
    """Service for research with materials (NotebookLM-style synthesis)"""
    
    async def research_with_materials(
        self, 
        query: str, 
        context: str,
        urls: Optional[List[str]] = None,
        materials: Optional[List[Dict]] = None
    ) -> AsyncGenerator[str, None]:
        """Research synthesis from uploaded materials and URLs"""
        
        system_prompt = self._get_research_system_prompt()
        
        user_message = f"Research Query: {query}"
        
        if context:
            user_message += f"\n\nContext: {context}"
        
        if materials:
            user_message += "\n\n=== SOURCE MATERIALS ===\n"
            for i, mat in enumerate(materials, 1):
                user_message += f"\n[Source {i}: {mat['filename']}]\n{mat['content'][:4000]}\n"
        
        if urls:
            user_message += "\n\n=== URLS TO REFERENCE ===\n"
            for url in urls:
                user_message += f"- {url}\n"
            user_message += "\n(Note: Please reference these URLs in your synthesis)"
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk
    
    def _get_research_system_prompt(self) -> str:
        """Get system prompt for research synthesis"""
        return """You are an expert research analyst for PwC, specializing in synthesizing insights from multiple sources.

Your task is to analyze the provided materials and create a comprehensive research synthesis.

Guidelines:
- Analyze all provided source materials thoroughly
- Identify key themes, patterns, and insights across sources
- Synthesize findings into a coherent narrative
- Include specific citations referencing sources (e.g., [Source 1], [Source 2])
- Highlight consensus and contradictions across sources
- Provide strategic insights relevant to business and consulting
- Include actionable recommendations based on the research

Structure:
1. **Executive Summary**: Key findings at a glance
2. **Key Themes**: Major patterns and insights across sources
3. **Detailed Analysis**: Deep dive into important topics with citations
4. **Synthesis**: How the sources relate and what they collectively reveal
5. **Strategic Implications**: What this means for business/consulting
6. **Recommendations**: Actionable next steps based on research

Use clear headings, bullet points, and citations throughout.
Maintain academic rigor while being accessible for business audiences."""
    
    async def execute(self, *args, **kwargs):
        """Execute research synthesis"""
        return await self.research_with_materials(*args, **kwargs)
