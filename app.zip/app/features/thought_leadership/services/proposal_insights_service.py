from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
import logging
import re
import json

logger = logging.getLogger(__name__)

GATHER_PROPOSAL_INPUTS_TEMPLATE_PROMPT = """
## GATHER PROPOSAL INPUTS:
Follow this structure EXACTLY. Do not rename sections. Do not reorder sections.
YYou are preparing a PwC proposal for a specific client and topic. Your objective is to gather concise, decision-ready inputs that allow a senior associate or manager to compare multiple credible ways PwC could deliver the engagement and efficiently draft a PwC-quality proposal.
 
This is an input pack, not final proposal prose. Prioritize clarity, structure, and comparability over polish.
 
Required Inputs
    - Client name
    - Industry / sub-sector
    - Proposal topic or problem statement
    - Buyer(s) and key stakeholders (if known)
    - Geography / market(s) in scope
 
Global Formatting, Readability & Evidence Rules (Mandatory)
 
Apply these rules throughout:
    1.  Optimize for comparison
        o   Assume all options will be read side-by-side.
        o   Emphasize what is different between options; avoid repeating generic context.
    2.  Lead with structure, then detail
        o   Every major section must start with a short at-a-glance summary (1–2 bullets).
    3.  Use a strict hierarchy
        o   Option header → numbered section → bolded labels → bullets
        o   Do not introduce additional heading levels.
    4.  Limit narrative prose
        o   Narrative paragraphs must be no more than 4–5 lines.
        o   Use bullets wherever possible.
    5.  Make trade-offs explicit
        o   Benefits and trade-offs must always be presented in parallel bullet lists.
    6.  Use PwC evidence intelligently
        o   When referencing PwC materials:
               Provide document title and link
               Add a one-line “why this is relevant” note
               Do not summarize full documents
    7.  Flag assumptions clearly
        o   Separate facts, assumptions, and illustrative examples.
       
A. Common Client Context (Applies to All Options)
Purpose: Establish shared understanding without repeating it in each option.
At-a-glance
•   Who the client is and what matters most right now
•   Why this topic is strategically important
Provide once:
•   Client background (industry, scale, geography, business model)
•   Current-state challenges and pain points
•   Strategic drivers and success criteria (client language where possible)
•   Known constraints and dependencies
•   Non-negotiables (e.g., privacy, CX standards, compliance)

B. Proposal Structure & Pattern Guidance (NEW)
Purpose: Give junior staff a clear blueprint for how the final proposal should be organized.
Provide:
•   Recommended proposal section outline, for example:
1.  Executive Summary
2.  Client Context & Objectives
3.  Our Understanding of Scope & Requirements
4.  Proposed Solution & Approach
5.  Deliverables, Outcomes & Value
6.  Project Plan, Timeline & Governance
7.  Team & Credentials
8.  Commercials, Assumptions & Risks
9.  Why PwC / Differentiators
•   Notes on:
o   Which sections are most important for this client/topic
o   Which sections can be lighter or optional

C. Relevant PwC Precedent & Reference Materials (MI&I-Integrated)
Purpose: Help staff pattern the proposal after proven PwC examples.
1. Sample Reference Proposals (NEW)
Provide up to three:
•   Proposal title + link
•   LOS, industry, and topic
•   One-line note on why this proposal is a good pattern (e.g., similar scope, client type, delivery model)
Do not summarize the proposal — focus on why it is structurally or conceptually useful.

2. Similar Approaches / Background Materials (NEW)
Provide up to three:
•   Approach, methodology, or whitepaper title + link
•   One-line note on what this helps the reader understand (e.g., delivery model, analytics approach, operating model)
These are intended for background reading, not proposal copy.

3. Standard PwC Methodologies & Frameworks
Provide:
•   Top 2–3 relevant PwC methodologies, frameworks, or accelerators
o   Name + link
o   One-line relevance note

D. Proposal Options Overview (At-a-Glance)
Purpose: Allow leadership to quickly understand how the options differ.
For each option, provide:
•   Option name
•   Core objective
•   Primary differentiator (speed, depth, risk, cost, scalability)
•   Best-fit scenario

E. Option-Level Detail
(Repeat Sections 1–6 for each option.)

1. Executive Summary Inputs
Option snapshot (max 3 lines)
•   What this option is
•   What problem it primarily solves
•   When it is the right choice
Provide:
•   Client objectives addressed
•   PwC approach (short narrative, max 5 lines)
•   Key benefits
•   Explicit trade-offs (what the client gives up)
•   High-level scope boundaries (in / out)
•   Indicative timeline
•   Indicative commercial construct or relative cost ($ / $$ / $$$)
•   Why PwC for this option (2–3 bullets)

2. Scope & Requirements
Provide:
•   Scope summary (size, complexity, disruption)
•   In-scope vs. out-of-scope activities
•   Systems, data, and geographies
•   Client responsibilities and effort required
•   Key assumptions

3. Solution & Delivery Approach
Provide:
•   Delivery phases and sequencing
•   Key PwC activities and deliverables
•   PwC methodologies / tools used (name + link + relevance)
•   Change management and training approach

4. Deliverables, Outcomes & Value
Provide:
•   Major deliverables
•   Expected outcomes
•   KPIs and metrics (directional)
•   Value realization profile

5. Timeline, Team & Governance
Provide:
•   Duration and milestones
•   PwC team structure and seniority mix
•   Client roles and time commitments
•   Governance model and decision points
•   Illustrative precedent patterns (optional)

6. Commercials & Risk Profile
Provide:
•   Pricing model
•   Relative cost and effort
•   Key risks and mitigations
•   Overall risk rating

F. Comparative Summary & Recommendation
Provide:
•   Side-by-side comparison table
•   Recommended option and rationale
•   When alternative options may be preferable

G. Relevant PwC Credentials
Provide:
•   Top 2–4 relevant credentials
o   Title + link
o   One-line “why relevant” note
•   Option-specific credentials where applicable

Output Requirements
•   Clear headings, bolded labels, concise bullets
•   Minimal prose, maximum structure
•   Links over summaries
•   Optimized for executive scanning and junior execution
"""

_PROPOSAL_INSIGHTS_FORMAT_CONFIG = {
    "tone_default": "Professional, strategic, and commercially focused",
    "tolerance": 2,
}

class ProposalInsightsService(BaseTLStreamingService):
    """Service for Proposal InsightsS generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize Proposal Insights Service
        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    def _build_prompt(
        self,
        clientname: str,
        topic: str,
        audience_tone: Optional[str],
        word_limit: int,
        outline_doc: str = "",
        supporting_doc: str = "",
        langgraph_context:str = "",
        citations_text: str = "",
        web_content: str = ""
    ) -> str:       
        # Build format-specific opening based on content type
        context_sections = ""
        if outline_doc:
            context_sections += f"\n\n### OUTLINE\n{outline_doc}"
        if supporting_doc:
            context_sections += f"\n\n### SUPPORTING CONTEXT\n{supporting_doc}"
        if web_content:
            context_sections += (
                "\n\n### ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)\n"
                f"{web_content}"
            )
        audience_tone = audience_tone or _PROPOSAL_INSIGHTS_FORMAT_CONFIG["tone_default"]
        task_desc = f"""**Task:** Gather and structure proposal development inputs for **{clientname}** related to **"{topic}"**.
        The output will be used internally to support proposal creation, shaping, and acceleration.
        This is a REPORT GENERATION task requiring comprehensive, detailed analysis.
        Requirements:
        - Each section must contain substantial analysis with a paragraph-length explanation
        - Every bullet point in the template requires few lines of explanation
        - Use specific data, examples, and context from all provided sources

        The document is intended for stakeholders with a {audience_tone} orientation and should provide a clear, structured view of the industry's economics, competitive dynamics, risks, and strategic opportunities.
        Treat this as a general proposal insights.
              
        """

        # Build prompt template
        prompt = f"""
        {task_desc}

        While creating this document follow these instructions: {GATHER_PROPOSAL_INPUTS_TEMPLATE_PROMPT}
        - Every metric includes: value + trend + context + implication
        - Every news item includes: what happened + why it matters + strategic impact
        - Every competitive point includes: who + how + evidence + impact on {clientname}
        - Multi-paragraph development of each template bullet point
        ---
        Instrucntions for Final Report Generation:
        - You are generating a FINAL, EXECUTIVE-READY Industry Insights report.
        - Do NOT explain the task, prompt, or missing inputs.
        - Do NOT ask clarifying questions.
        - If information is missing, make reasonable industry-standard assumptions and proceed.
        - Never describe this output as a template, intake document, or prompt.
        - Response should be in Markdown with proper alignment and heading and subheading defined
        - Always Use Client name, topic when generating output (avoid using placeholders such as Client, Topic) instead fill with actual values      

        ## Writing Style & Quality Standards 
        - **Active voice preferred**
        - **Clear, direct language**
        - **Minimal jargon** (define when used)
        - **Maintain focus** on topic, client name and audience
        - **Source transparency**: Every data point must trace back to a named source
        ---

        ---

        Here is data received in external research/tools
        There are 3 parts to it:
         1. Outline
         2. SUPPORTING CONTEXT
         3. ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)
         
         {context_sections}

        ---

        Agent Data: Data which was retrieved from our internal agent system:
        Agent Data: {langgraph_context}       

        -----
        ## Instructions for use of Agent Data:
        - Every factual claim in Agent Data MUST appear in your report with full context
        - For each data point: explain what it means, why it matters, and implications
        - Example: Don't write "Gross Profit: 2024 $80.880B" 
        Instead: "{clientname} gross profit reached $80.880B in 2024, representing a 2.2% increase from 2023's $79.169B. This upward trajectory suggests improving operational efficiency despite competitive pricing pressures in the wireless market, though margin analysis requires revenue data unavailable in this dataset."
        - Integrate financial metrics into narrative analysis, not just lists
        - Connect news items to strategic implications (don't just report headlines)
        - If conflicting information exists, prioritize the most recent and relevant data.
        

        ## Citations & References Section:
        - This section must contain ONLY the sources provided below
        - ALWAYS include all the citation links provided in the SUPPORTING CONTEXT under different categories
        - ALWAYS PROVIDE ALL THE CITATIONS MENTIONED IN AGENT DATA UNDER **Sources** OR ANY URL MENTIONED IN AGENT DATA.
        - Clearly distinguish between:
        • Connected/Internal Sources  
        • External Web Sources (side note: this data will have external websites links)
        - Do NOT merge these into a single undifferentiated list
        - If no sources are provided, OMIT the Citations & References section entirely
        - Do NOT explain why the section is omitted
        """
        
        return prompt

    async def proposal_insights_prompt(self, user_prompt: str, clientname: str, topic: str, audience_tone: Optional[str], word_limit: int, outline_doc: str = "",
    supporting_doc: str = "",
    agent_research_context: str ='',
    use_uploaded: bool = False,
    use_factiva: bool = True,
    use_external: bool = True) -> AsyncGenerator[str, None]:
        effective_supporting_doc = supporting_doc if use_uploaded else ""
        system_prompt = self._build_prompt(
            clientname=clientname,
            topic=topic,
            audience_tone=audience_tone,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=effective_supporting_doc,
            langgraph_context=agent_research_context,
            citations_text="",
            web_content=""
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        logger.info(f" [Proposal Insights] Starting meeting content generation - target: {word_limit} words (±2%)")
        buffer = ""
        word_threshold = 70
        
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            try:
                # Handle both "data: {...}" and "{...}" formats
                json_str = chunk[6:] if chunk.startswith("data: ") else chunk
                chunk_data = json.loads(json_str)
                
                if chunk_data.get("type") == "content":
                    buffer += chunk_data.get("content", "")
                    word_count = len(buffer.split())
                    
                    if word_count >= word_threshold:
                        yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
                        buffer = ""
            except json.JSONDecodeError:
                continue
        
        # Yield remaining buffer
        if buffer:
            yield f"data: {json.dumps({'type': 'content', 'content': buffer})}\n\n"
            
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
    
    async def execute(self, *args, **kwargs):
        """Execute draft content generation"""
        async for chunk in self.proposal_insights_prompt(*args, **kwargs):
            yield chunk
      
    async def _build_unified_citations(self, topic: str,clientname: str, max_web_results: int = 5, fetch_content: bool = True) -> tuple[str, str]:
        all_citations = []
        citation_number = 1
        web_content = ""        
        # Add web search sources
        logger.info(f"[CITATIONS] Performing web search for topic: {topic} (fetch_content={fetch_content})")
        
        search_query = " ".join(filter(None, [clientname, topic]))

        logger.info(f"[CITATIONS] search_query=" + (search_query or "<empty>"))
        
        
        web_search_data = await self.web_search_service.search_and_format(
            search_query, 
            max_results=max_web_results,
            fetch_content=fetch_content
        )
        
        if web_search_data['count'] > 0:
            logger.info(f"[CITATIONS] Adding {web_search_data['count']} web search sources to unified citations list (starting from #{citation_number})")
            
            # Parse web search citations and renumber them
            web_citations_raw = web_search_data['formatted_citations'].strip().split('\n')
            for web_citation in web_citations_raw:
                if web_citation.strip():
                    # Remove old numbering (e.g., "1. Title..." becomes "Title...")
                    citation_text = web_citation.strip()
                    if citation_text[0].isdigit() and '. ' in citation_text:
                        citation_text = citation_text.split('. ', 1)[1]
                    
                    # Add new unified numbering
                    all_citations.append(f"{citation_number}. {citation_text}")
                    citation_number += 1
            
            # Get web content
            web_content = web_search_data.get('web_content', '')
            if web_content:
                logger.info(f"[CITATIONS] Retrieved web content: {(web_content)} characters")
        else:
            logger.warning(f"[CITATIONS] No web search results found for topic: {topic} and clientname: {clientname}")
        
        unified_citations = '\n'.join(all_citations)
        total_sources = citation_number - 1
        logger.info(f"[CITATIONS] Unified citations built: {total_sources} total sources (web content: {len(web_content)} chars)")
        logger.info(f"[CITATIONS] Unified Citations Text:\n{unified_citations}")
        return unified_citations, web_content    
