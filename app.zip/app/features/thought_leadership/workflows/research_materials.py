from fastapi import APIRouter, Form, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from app.features.thought_leadership.services.research_materials_service import ResearchMaterialsService
from app.core.deps import get_tl_service
from typing import Optional, List
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def research_materials_workflow(
    query: str = Form(...),
    context: str = Form(""),
    urls: Optional[str] = Form(None),
    materials: Optional[List[UploadFile]] = File(None),
    service: ResearchMaterialsService = Depends(get_tl_service(ResearchMaterialsService))
):
    """Research with Materials workflow: NotebookLM-style multi-document synthesis"""
    try:
        logger.info(f"[Research Materials] Query: {query}")
        
        materials_content = None
        if materials:
            materials_content = []
            for mat in materials:
                content = await mat.read()
                materials_content.append({
                    'filename': mat.filename,
                    'content': content.decode('utf-8', errors='ignore')
                })
        
        url_list = None
        if urls:
            url_list = [u.strip() for u in urls.split(',') if u.strip()]
        
        return StreamingResponse(
            service.research_with_materials(query, context, url_list, materials_content),
            media_type="text/event-stream"
        )
    except Exception as e:
        logger.error(f"[Research Materials] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
