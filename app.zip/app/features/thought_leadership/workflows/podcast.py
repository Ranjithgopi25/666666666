from fastapi import APIRouter, Form, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from app.features.thought_leadership.services.podcast_service import PodcastService
from app.core.deps import get_tl_service
from typing import Optional, List
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def generate_podcast_workflow(
    content_text: Optional[str] = Form(None),
    podcast_style: str = Form("dialogue"),
    customization: Optional[str] = Form(None),
    speaker1_name: Optional[str] = Form(None),
    speaker1_voice: Optional[str] = Form(None),
    speaker1_accent: Optional[str] = Form(None),
    speaker2_name: Optional[str] = Form(None),
    speaker2_voice: Optional[str] = Form(None),
    speaker2_accent: Optional[str] = Form(None),
    files: Optional[List[UploadFile]] = File(None),
    service: PodcastService = Depends(get_tl_service(PodcastService))
):
    """Generate Podcast workflow: Create podcast scripts with dialogue or monologue and synthesize audio"""
    try:
        logger.info(f"[Podcast] Style: {podcast_style}, Speaker1: {speaker1_name} ({speaker1_voice}/{speaker1_accent})")
        if podcast_style == 'dialogue':
            logger.info(f"[Podcast] Speaker2: {speaker2_name} ({speaker2_voice}/{speaker2_accent})")
        
        ref_content = None
        if files:
            ref_content = []
            for ref_file in files:
                content = await ref_file.read()
                ref_content.append({
                    'filename': ref_file.filename,
                    'content': content.decode('utf-8', errors='ignore')
                })
        
        return StreamingResponse(
            service.generate_podcast_with_audio(
                content_text=content_text or "",
                style=podcast_style,
                customization=customization,
                references=ref_content,
                speaker1_name=speaker1_name,
                speaker1_voice=speaker1_voice,
                speaker1_accent=speaker1_accent,
                speaker2_name=speaker2_name,
                speaker2_voice=speaker2_voice,
                speaker2_accent=speaker2_accent
            ),
            media_type="text/event-stream"
        )
    except Exception as e:
        logger.error(f"[Podcast] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
