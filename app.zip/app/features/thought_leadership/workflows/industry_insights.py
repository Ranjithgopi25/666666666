from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.industry_insights_service import IndustryInsightsService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.deps import get_tl_service, get_settings

from app.core.config import Settings, config

import logging
import re
from docx import Document
from docx.shared import Pt


router = APIRouter()
logger = logging.getLogger(__name__)

class IndustryInsightsRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    content_type: Optional[str] = None
    word_limit: Optional[int] = None
    audience_tone: Optional[str] = None
    clientname: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_research: Optional[bool] = False
    services: Optional[Dict[str, Any]] = None
    

def extract_research_info(content: str) -> dict:
    """Extract research-related information from content."""
    research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)    
    research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
    research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
    additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
    return {
        'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,

        'topics': research_topics.group(1).strip() if research_topics else None,

        'sources': research_sources.group(1).strip() if research_sources else None,

        'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
    }

@router.post("")
async def industry_insights_workflow(
    request: IndustryInsightsRequest,
    service: IndustryInsightsService = Depends(get_tl_service(IndustryInsightsService)),
    settings: Settings = Depends(get_settings)
):
    try:
        user_prompt = ""
        if request.messages:
            user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[industry Insights]  User prompt length: {len(user_prompt)}")
        logger.debug(f"[industry Insights] Full user prompt:\n{user_prompt}")
        # Initialize variables
        clientname = (request.clientname or "").strip()
        services = request.model_dump().get("services")
        logger.debug(
            f"[DEBUG] IndustryInsightsRequest fields: {request.model_fields.keys()}"
        )

        if not clientname and services and isinstance(services, dict):
            draft = services.get("draft", {})
            if isinstance(draft, dict):
                clientname = (draft.get("client") or "").strip()

            draft = request.services.get("draft", {})
            if isinstance(draft, dict):
                clientname = (draft.get("client") or "").strip()

        original_clientname = clientname
        content_type = "Generate Industry Insights"
        audience_tone = apply_audience_tone_defaults(content_type, request.audience_tone)
        # Use request-provided word limit or the centralized default from settings
        word_limit_int = request.word_limit or settings.TL_WORD_LIMIT_DEFAULT
        supporting_doc = request.supporting_doc or ''
        outline_doc = request.outline_doc or ''
        
        # Extract research information
        research_info = extract_research_info(user_prompt)
        enhanced_user_prompt = user_prompt
        langgraph_context = ""
        # Log both the original field value and the inferred value so it's clear why
        # clientname was empty in earlier logs.
        logger.info(
            f"[PARSE] resolved_clientname='{clientname}', "
            f"source={'services.draft.client' if request.services else 'request.clientname'}, "
            f"Word Limit='{word_limit_int}', Audience='{audience_tone}'"
        )
        # Handle Multi-Source LangGraph Agent
        if True:
            try:
                logger.info(f"[industry Insights] Initializing LangGraph Agent for multi-source query")
                # Create LangGraph agent instance
                langgraph_agent = create_data_source_agent(
                    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                    api_key=config.AZURE_OPENAI_API_KEY,
                    api_version=config.AZURE_OPENAI_API_VERSION,
                    deployment_name=config.AZURE_OPENAI_DEPLOYMENT
                )
                if not clientname:
                    for line in user_prompt.splitlines():
                        ln = line.strip()
                        if not clientname and (ln.lower().startswith("client:") or ln.lower().startswith("client name:") or ln.lower().startswith("clientname:")):
                            clientname = ln.split(":", 1)[1].strip()
                # Build the query message for the agent (include client name)
                search_query = f"{clientname}".strip()
                additional_guidelines = research_info.get('additional_guidelines') or ''
                # LLM is more likely to invoke the CapitalIQ tools.
                agent_messages = [
                            {
                                "role": "user",
                                "content": f"""
                        You are a PwC MI&I research agent preparing comprehensive intelligence for an INDUSTRY INSIGHTS REPORT.

                        **RESEARCH CONTEXT:**
                        - Industry/Sector: {search_query}
                        
                        - Time Horizon: Current state + 3-5 year outlook

                        **YOUR MISSION:**
                        Gather exhaustive, structured intelligence to support an executive-ready industry insights report.
                        The final output will follow a strict template requiring specific data across 9 core sections.
                        This is NOT a summary exercise - executives need sufficient depth to understand industry economics and dynamics without prior context.

                        ========================
                        REQUIRED RESEARCH AREAS
                        ========================

                        You MUST retrieve data for ALL sections below. Use ALL relevant tools exhaustively.
                        Prioritize RECENT data (2024-2025) but include historical context where it illuminates trends.

                        **1. EXECUTIVE OVERVIEW (MANDATORY)**
                        Required data points:
                        - Industry definition (1-line, clear scope)
                        - Current market size ($ revenue and/or units) - break down by non-overlapping categories if applicable
                        - 3-5 year growth outlook (CAGR, forecasts)
                        - Key growth drivers shaping the outlook
                        - Profit pools (where value is actually captured in the value chain)
                        - Top 3-5 emerging trends (with timeframes)

                        Tools to use: Connected Source, Tavily, Factiva, CapitalIQ (for public company aggregates)

                        **2. INDUSTRY STRUCTURE & ECONOMICS (MANDATORY)**
                        Required:
                        - Complete value chain mapping (from raw inputs to end customer)
                        - Role definition for each value chain segment
                        - Revenue structures (who makes what margin where)
                        - Major cost drivers (materials, labor, R&D, capex, regulation, software, etc.) - explain WHY each matters
                        - Capital intensity by segment
                        - Return profiles (ROIC, ROE ranges) by player type
                        - How cost drivers are changing over time

                        Tools to use: Connected Source (PRIMARY for industry structure), CapitalIQ (for financial benchmarks), Tavily

                        **3. COMPETITIVE LANDSCAPE (MANDATORY)**
                        Required:
                        - Top 10-15 global players with market shares (name them explicitly)
                        - Top regional players (by geography)
                        - Strategic archetypes/groupings (e.g., "incumbent integrators", "pure-play specialists", "tech disruptors")
                        - Sources of competitive differentiation (scale, technology, brand, cost, vertical integration, etc.)
                        - New entrants in last 24 months
                        - Substitute threats
                        - Major M&A activity (last 12-18 months) with deal rationale

                        Tools to use: CapitalIQ (company data, M&A), Factiva (competitive moves, M&A announcements), Tavily

                        **4. MARKET DYNAMICS & GROWTH DRIVERS (MANDATORY)**
                        Required:
                        - Demand drivers (explain how each affects volumes, pricing, or mix)
                        - Supply-side shifts (capacity additions, consolidation, technology adoption)
                        - Geography-specific growth pockets (explain WHY certain regions grow faster)
                        - Segment-led growth areas (which product/service categories are hot)
                        - Cyclical vs. secular trends (distinguish clearly)
                        - Elasticity dynamics (price sensitivity, substitution effects)

                        Tools to use: Connected Source, Factiva, Tavily

                        **5. MAJOR PAIN POINTS (MANDATORY)**
                        Required (focus on ROOT CAUSES, not symptoms):
                        - Operational inefficiencies (explain how they manifest day-to-day)
                        - Customer complaints (recurring themes)
                        - Technology limitations (legacy systems, integration challenges, etc.)
                        - Financial/profitability pressures (margin compression drivers, cash flow issues)
                        - Talent/workforce challenges
                        - Supply chain vulnerabilities
                        - Other systemic pain points

                        Tools to use: Connected Source, Factiva, Tavily

                        **6. DISRUPTION & TECHNOLOGY IMPACT (MANDATORY)**
                        Required (separate PROVEN from EMERGING):
                        - New business models (platform plays, as-a-service, direct-to-consumer, etc.)
                        - Technologies changing economics TODAY (proven, scaled impact)
                        * Explain HOW each changes cost, revenue, or risk
                        - Emerging technologies (early stage, unproven at scale)
                        - AI use cases - proven and emerging:
                        * Operations optimization
                        * Customer experience
                        * Product development
                        * Back-office automation
                        * Predictive maintenance (if relevant)
                        - Technology adoption barriers

                        Tools to use: Connected Source (PRIMARY for tech trends), Factiva, Tavily

                        **7. STRATEGIC OPPORTUNITIES & WHITE SPACE (MANDATORY)**
                        Required:
                        - Recently announced strategic objectives by top 5 players (last 12 months)
                        - Growth vectors for incumbents (organic expansion areas)
                        - Defensive plays (where incumbents must protect)
                        - Adjacency opportunities (where companies are expanding scope)
                        - Capability gaps across value chain (what's missing and why it matters)
                        - Untapped customer segments
                        - Geographic expansion opportunities

                        Tools to use: Connected Source, Factiva, CapitalIQ, Tavily

                        **8. REGULATIONS & POLICY (MANDATORY)**
                        Required:
                        - Overall regulatory importance/impact on industry economics
                        - Current regulatory landscape by geography (US, EU, China, other key markets)
                        - How current regulations affect:
                        * Product mix
                        * Cost structures
                        * Capital allocation
                        * Go-to-market strategies
                        - Pending/proposed regulations (next 12-24 months)
                        - Expected impact of new regulations on economics
                        - ESG/sustainability mandates (if material)

                        Tools to use: Connected Source, Factiva, Tavily

                        **9. RECENT NEWS (MANDATORY)**
                        Required (with dates and named entities):
                        - Industry-wide news (last 3 months) - focus on what CHANGED
                        - Major company-specific developments (last 6 months)
                        - Earnings surprises or warnings
                        - Strategic pivots or announcements
                        - Major partnerships or alliances
                        - Technology breakthroughs
                        - Regulatory developments

                        Tools to use: Factiva (PRIMARY), Tavily

                        ========================
                        EXECUTION REQUIREMENTS
                        ========================

                        1. **Prioritize recent data:**
                        - 2024-2025 data is GOLD
                        - 2023 data is acceptable with date labels
                        - Pre-2023 data only for historical context (label clearly)

                        2. **Call tools strategically:**
                        - Connected Source FIRST for industry structure, trends, PwC perspectives
                        - CapitalIQ for company financials, market shares, M&A data
                        - Factiva for news, competitive intelligence, regulatory developments
                        - Tavily for validation, gaps, or emerging topics

                        3. **For quantitative claims:**
                        - Always cite source and date
                        - Include units ($ billions, millions of units, %, CAGR, etc.)
                        - If data is unavailable, state: "Market size data not available - requires [source]"

                        4. **For qualitative insights:**
                        - Provide specific examples (company names, product names, geographies)
                        - Explain mechanisms (HOW does this driver affect outcomes)
                        - Distinguish between correlation and causation

                        5. **If a tool returns no data:**
                        - Explicitly state: "Checked [Tool] for [specific data point] - no results"
                        - Try alternative tools before flagging as unavailable

                        6. **Do NOT:**
                        - Use vague language ("some companies", "many players")
                        - Present opinions as facts without attribution
                        - Skip sections due to data gaps - flag gaps explicitly
                        - Stop research after 2-3 tool calls

                        7. **Output structure:**
                        Organize findings under clear section headings matching the 9 research areas.
                        Use executive takeaways (1-2 sentences) at the start of each section.
                        Follow with explanatory paragraphs (not just bullets).
                        Include source citations inline.

                        ========================
                        QUALITY STANDARD
                        ========================

                        Executives reading this should be able to:
                        - Understand the industry's economics without prior deep knowledge
                        - Identify where value is made and destroyed
                        - Spot strategic opportunities and risks
                        - Make informed decisions about market entry, partnerships, or investments

                        Balance depth with clarity:
                        - Avoid industry jargon without definition
                        - Explain the "why" behind trends, not just the "what"
                        - Use examples to make abstract concepts tangible
                        - Connect insights to business implications

                        Research Query Focus: {search_query}

                        {additional_guidelines}

                        **BEGIN COMPREHENSIVE RESEARCH NOW. Use ALL applicable tools across all 9 sections.**
                        """
                            }
                        ]
                # Get response from LangGraph agent
                agent_response = await langgraph_agent.process_query(agent_messages)
                logger.info(f'this is the agent response: {agent_response}')
                if agent_response:
                    
                    langgraph_context = f"""
                    --- Multi-Source Research Intelligence Report ---

                    The following research was compiled by an AI Agent that automatically queried multiple data sources. 

                    Agent Research Output:
                    {agent_response}

                    --- End of Research Intelligence ---
                    """
 
                    logger.info("[industry Insights] LangGraph Agent context added to research")
                else:
                    logger.warning("[industry Insights] LangGraph Agent returned empty response")
                # Close agent connections
                langgraph_agent.close()
            except Exception as e:
                logger.error(f"[industry Insights] LangGraph Agent error: {e}", exc_info=True)
                # Continue without agent context - don't break the workflow
                logger.warning("[industry Insights] Continuing prep without LangGraph Agent data")
        # Apply default word limits if not provided by user
        word_limit_source = 'user' if request.word_limit else 'default'
      # Use improvement prompt if this is an improvement iteration
        final_prompt = enhanced_user_prompt
        return StreamingResponse(
            service.industry_insights_prompt(
                user_prompt=final_prompt,
                clientname=clientname,
                audience_tone=audience_tone,
                word_limit=word_limit_int,
                outline_doc=outline_doc,         
                supporting_doc=supporting_doc,
                agent_research_context = langgraph_context
            ),
            media_type="text/event-stream"
        )
    except Exception as e:
        logger.error(f"[industry Insights] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
