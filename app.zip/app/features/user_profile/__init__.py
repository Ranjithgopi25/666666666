from app.features.user_profile.router  import get_router

__all__ = ["get_router"]