from pydantic import BaseModel, Field
from typing import Optional, List


class OAuthTokenRequest(BaseModel):
    """Request model for OAuth token generation (header-based auth)."""
    authorization: str = Field(..., description="Bearer token for authorization header")


class OAuthTokenResponse(BaseModel):
    """Response model for OAuth token generation."""
    access_token: str = Field(..., description="Access token for API authentication")
    token_type: str = Field(..., description="Type of token (e.g., BearerToken)")
    issued_at: str = Field(..., description="Timestamp when token was issued")
    expires_in: str = Field(..., description="Token expiration time in seconds")
    status: str = Field(..., description="Token status (e.g., approved)")


class M365TokenBody(BaseModel):
    """Token body for M365 API authentication."""
    access_token: str = Field(..., description="Access token from OAuth")
    token_type: str = Field(..., description="Type of token (e.g., BearerToken)")
    issued_at: str = Field(..., description="Timestamp when token was issued")
    expires_in: str = Field(..., description="Token expiration time in seconds")
    status: str = Field(..., description="Token status (e.g., approved)")


class M365UserSearchRequest(BaseModel):
    """Request model for M365 user profile search."""
    count: bool = Field(True, description="Include count in response")
    queryType: str = Field("full", description="Type of query")
    search: str = Field(..., description="Search query string")
    searchMode: str = Field("all", description="Search mode")


class CostCenter(BaseModel):
    """Cost center information."""
    code: str = Field(..., description="Cost center code")
    description: str = Field(..., description="Cost center description")


class M365UserProfile(BaseModel):
    """M365 user profile data."""
    firstName: str = Field(..., description="First name")
    lastName: str = Field(..., description="Last name")
    imageURL: Optional[str] = Field(None, description="Base64 encoded profile image URL")
    userPrincipalName: str = Field(..., description="User principal name (email)")
    jobTitle: Optional[str] = Field(None, description="Job title")
    type: str = Field(..., description="User type (e.g., Employee)")
    costCenter: CostCenter = Field(..., description="Cost center information")
    globalLOS1: Optional[str] = Field(None, description="Global LOS 1")
    workCity: Optional[str] = Field(None, description="Work city")
    pwcGlobalNetworkCompetencyName: Optional[str] = Field(None, description="PWC global network competency name")
    subLos1Desc: Optional[str] = Field(None, description="Sub LOS 1 description")
    subLos2Desc: Optional[str] = Field(None, description="Sub LOS 2 description")
    subLos3Desc: Optional[str] = Field(None, description="Sub LOS 3 description")
    subLos4Desc: Optional[str] = Field(None, description="Sub LOS 4 description")
    subLos5Desc: Optional[str] = Field(None, description="Sub LOS 5 description")
    location: Optional[str] = Field(None, description="Formatted location from cost center and work city")


class M365UserSearchResponse(BaseModel):
    """Response model for M365 user profile search (single result expected)."""
    data: List[M365UserProfile] = Field(..., description="User profile data")
