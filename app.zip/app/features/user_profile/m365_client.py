import requests
import base64
from typing import Optional
from datetime import datetime, timedelta
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from app.features.user_profile.models import (
    OAuthTokenResponse,
    M365UserSearchRequest,
    M365UserSearchResponse,
    M365UserProfile
)


class M365Client:
    """Client for M365 API integration."""

    def __init__(self, oauth_url: str, m365_url: str, auth_token: str):
        """Initialize M365 client with API endpoints and credentials."""
        self.oauth_url = oauth_url
        self.m365_url = m365_url
        self.auth_token = auth_token
        self._cached_token: Optional[OAuthTokenResponse] = None
        self._token_expiry: Optional[datetime] = None

    def get_access_token(self) -> str:
        """Get OAuth access token, using cache if valid."""
        if self._cached_token and self._token_expiry and datetime.now() < self._token_expiry:
            return self._cached_token.access_token

        headers = {"Authorization": f"Basic {self.auth_token}"}
        response = requests.post(self.oauth_url, headers=headers)
        response.raise_for_status()

        token_data = response.json()
        self._cached_token = OAuthTokenResponse(**token_data)
        
        # Set expiry time (subtract 60 seconds for safety margin)
        expires_in_seconds = int(self._cached_token.expires_in) - 60
        self._token_expiry = datetime.now() + timedelta(seconds=expires_in_seconds)

        return self._cached_token.access_token

    def _is_valid_image(self, image_data: str) -> bool:
        """Check if imageURL contains valid image data."""
        if not image_data or not image_data.strip():
            return False
        try:
            decoded = base64.b64decode(image_data)
            return not decoded.startswith(b'{"error"')
        except:
            return False

    def _generate_avatar(self, first_name: str, last_name: str) -> str:
        """Generate avatar with initials."""
        initials = f"{first_name[0]}{last_name[0]}".upper()
        
        img = Image.new('RGB', (200, 200), color='#FFAA72')
        draw = ImageDraw.Draw(img)
        
        try:
            font = ImageFont.truetype("arial.ttf", 80)
        except:
            font = ImageFont.load_default(80)
        
        bbox = draw.textbbox((0, 0), initials, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (200 - text_width) / 2
        y = (170 - text_height) / 2
        
        draw.text((x, y), initials, fill='black', font=font)
        
        buffer = BytesIO()
        img.save(buffer, format='JPEG')
        img_base64 = base64.b64encode(buffer.getvalue()).decode()
        
        return f"data:image/jpeg;base64,{img_base64}"

    def get_user_profile(self, email: str) -> Optional[M365UserProfile]:
        """Fetch user profile from M365 API by email."""
        access_token = self.get_access_token()

        search_request = M365UserSearchRequest(
            search=f'userPrincipalName:"{email}"'
        )

        headers = {
            "Authorization": f"Bearer {access_token}",
            "searchType": "CPS-MS365",
            "consumerName": "Default-MS365"
        }
        response = requests.post(
            self.m365_url,
            headers=headers,
            json=search_request.model_dump()
        )
        response.raise_for_status()

        response_data = M365UserSearchResponse(**response.json())
        
        if response_data.data and len(response_data.data) > 0:
            profile = response_data.data[0]
            
            # Check if imageURL contains valid image data
            if profile.imageURL and self._is_valid_image(profile.imageURL):
                profile.imageURL = f"data:image/jpeg;base64,{profile.imageURL}"
            else:
                profile.imageURL = self._generate_avatar(profile.firstName, profile.lastName)
            
            # Set location based on cost center description
            if '|' in profile.costCenter.description:
                profile.location = profile.costCenter.description.replace('|', ' | ')
            else:
                profile.location = f"{profile.costCenter.description} | {profile.workCity or ''}"
            
            return profile
        
        return None
