from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse
import logging
from app.features.user_profile.m365_client import M365Client
from app.core.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter()

# -------------------------------------------------------------------
# CONFIG (use env vars in real usage)
# -------------------------------------------------------------------
settings = get_settings()

M365_OAUTH_URL = settings.M365_OAUTH_URL
M365_API_URL = settings.M365_API_URL
M365_AUTH_TOKEN = settings.M365_AUTH_TOKEN


#client = M365Client(M365_OAUTH_URL, M365_API_URL, M365_AUTH_TOKEN)
def get_m365_client():
    settings = get_settings()
    return M365Client(
        settings.M365_OAUTH_URL,
        settings.M365_API_URL,
        settings.M365_AUTH_TOKEN
    )
@router.get("/user/{email}")
def get_user_profile(email: str,client: M365Client = Depends(get_m365_client)):
    """Get M365 user profile by email."""
    try:
        logger.info(f"[M365Service] Fetching profile for email: {email}")
        profile = client.get_user_profile(email)
        
        if not profile:
            raise HTTPException(status_code=404, detail=f"User profile not found for email: {email}")
        
        #logger.info(f"Profile:::::{profile}")
        return JSONResponse(content=profile.dict())
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        logger.error(f"[M365Service] Error fetching user profile: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")