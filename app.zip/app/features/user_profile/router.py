from fastapi import APIRouter, Depends
from app.features.user_profile import (    
    userprofile
)


from app.services.auth_service import validate_jwt_token

def get_router() -> APIRouter:
    """Create and configure DDC router with all workflow sub-routers"""
    #router = APIRouter(prefix="/profile", tags=["Profile"], dependencies=[Depends(validate_jwt_token)])
    router = APIRouter(prefix="/profile", tags=["Profile"])

    router.include_router(userprofile.router, prefix="/details", tags=["User Profile"])
    return router
