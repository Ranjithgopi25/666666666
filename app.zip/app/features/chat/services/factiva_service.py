# import logging
# import httpx
# import re
# from typing import Dict, List, Optional, Any

# logger = logging.getLogger(__name__)


# class FactivaService:
#     """Service for fetching content from Dow Jones Factiva API."""
    
#     FACTIVA_KEYWORDS = ['wall street journal', 'wsj', 'street journal']
    
#     AUTH_URL = "https://accounts.dowjones.com/oauth2/v1/token"
#     JWT_URL = "https://accounts.dowjones.com/oauth2/v1/token"
#     CONTENT_URL = "https://api.dowjones.com/content/gen-ai/retrieve"
    
#     # Credentials
#     USERNAME = "9PRI033400-svcaccount@dowjones.com"
#     CLIENT_ID = "bbFvlCtgXICfEAky3cIihoLH2dPWhUxcjE7YRA72"
#     PASSWORD = "xFJoVBwoStvcvF47"
    
#     def __init__(self):
#         self._access_token: Optional[str] = None
#         self._id_token: Optional[str] = None
#         self._pib_token: Optional[str] = None
    
#     @classmethod
#     def contains_factiva_keywords(cls, text: str) -> bool:
#         """Check if text contains any Factiva-related keywords."""
#         text_lower = text.lower()
#         return any(keyword in text_lower for keyword in cls.FACTIVA_KEYWORDS)
    
#     @classmethod
#     def extract_query_from_messages(cls, messages: List[Dict[str, str]]) -> Optional[str]:
#         """Extract the user query from messages if it contains Factiva keywords."""
#         for msg in reversed(messages):
#             if msg.get("role") == "user":
#                 content = msg.get("content", "")
#                 if cls.contains_factiva_keywords(content):
#                     return content
#         return None
    
#     async def _get_initial_tokens(self) -> tuple[str, str]:
#         """Get initial access_token and id_token using password grant."""
#         async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
#             response = await client.post(
#                 self.AUTH_URL,
#                 data={
#                     "username": self.USERNAME,
#                     "client_id": self.CLIENT_ID,
#                     "password": self.PASSWORD,
#                     "connection": "service-account",
#                     "grant_type": "password",
#                     "scope": "openid service_account_id"
#                 },
#                 headers={"Content-Type": "application/x-www-form-urlencoded"}
#             )
#             response.raise_for_status()
#             data = response.json()
#             return data["access_token"], data["id_token"]
    
#     async def _get_pib_token(self, access_token: str, id_token: str) -> str:
#         """Exchange tokens for PIB token using JWT bearer grant."""
#         async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
#             response = await client.post(
#                 self.JWT_URL,
#                 data={
#                     "assertion": id_token,
#                     "access_token": access_token,
#                     "client_id": self.CLIENT_ID,
#                     "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
#                     "scope": "openid pib"
#                 },
#                 headers={"Content-Type": "application/x-www-form-urlencoded"}
#             )
#             response.raise_for_status()
#             data = response.json()
#             return data["access_token"]
    
#     async def authenticate(self) -> str:
#         """Perform full authentication flow and return PIB token."""
#         try:
#             logger.info("Authenticating with Factiva API...")
#             access_token, id_token = await self._get_initial_tokens()
#             self._access_token = access_token
#             self._id_token = id_token
            
#             self._pib_token = await self._get_pib_token(access_token, id_token)
#             logger.info("Factiva authentication successful")
#             return self._pib_token
#         except Exception as e:
#             logger.error(f"Factiva authentication failed: {str(e)}")
#             raise
    
#     async def fetch_content(self, query: str, response_limit: int = 10) -> Dict[str, Any]:
#         """Fetch content from Factiva API."""
#         if not self._pib_token:
#             await self.authenticate()
        
#         async with httpx.AsyncClient(timeout=60.0, verify=False) as client:
#             response = await client.post(
#                 self.CONTENT_URL,
#                 json={
#                     "data": {
#                         "attributes": {
#                             "response_limit": response_limit,
#                             "query": {
#                                 "search_filters": [
#                                     {"scope": "Language", "value": "en"}
#                                 ],
#                                 "value": query
#                             }
#                         },
#                         "id": "GenAIRetrieval",
#                         "type": "genai-content"
#                     }
#                 },
#                 headers={
#                     "Content-Type": "application/json",
#                     "Accept": "application/vnd.dowjones.genai-content.v_1.0",
#                     "Authorization": f"Bearer {self._pib_token}"
#                 }
#             )
            
#             if response.status_code == 401:
#                 # Token expired, re-authenticate
#                 logger.info("PIB token expired, re-authenticating...")
#                 await self.authenticate()
#                 response = await client.post(
#                     self.CONTENT_URL,
#                     json={
#                         "data": {
#                             "attributes": {
#                                 "response_limit": response_limit,
#                                 "query": {
#                                     "search_filters": [
#                                         {"scope": "Language", "value": "en"}
#                                     ],
#                                     "value": query
#                                 }
#                             },
#                             "id": "GenAIRetrieval",
#                             "type": "genai-content"
#                         }
#                     },
#                     headers={
#                         "Content-Type": "application/json",
#                         "Accept": "application/vnd.dowjones.genai-content.v_1.0",
#                         "Authorization": f"Bearer {self._pib_token}"
#                     }
#                 )
            
#             response.raise_for_status()
#             return response.json()
    
#     @staticmethod
#     def format_factiva_context(factiva_response: Dict[str, Any]) -> str:
#         """Format Factiva API response into context string for LLM."""
#         articles = factiva_response.get("data", [])
#         if not articles:
#             return ""
        
#         context_parts = ["### Relevant News Articles from Factiva/Dow Jones:\n"]
        
#         for i, article in enumerate(articles, 1):
#             attrs = article.get("attributes", {})
#             meta = article.get("meta", {})
            
#             headline = attrs.get("headline", {}).get("main", {}).get("text", "No headline")
#             source = meta.get("source", {}).get("name", "Unknown source")
#             pub_date = attrs.get("publication_date", "Unknown date")
#             byline = attrs.get("byline", {}).get("text", "")
#             content = attrs.get("content", [])
#             content_text = content[0].get("text", "") if content else ""
            
#             # Truncate content if too long
#             if len(content_text) > 1500:
#                 content_text = content_text[:1500] + "..."
            
#             context_parts.append(f"**Article {i}: {headline.strip()}**")
#             context_parts.append(f"Source: {source} | Date: {pub_date}")
#             if byline:
#                 context_parts.append(f"By: {byline}")
#             context_parts.append(f"\n{content_text}\n")
#             context_parts.append("---\n")
        
#         return "\n".join(context_parts)