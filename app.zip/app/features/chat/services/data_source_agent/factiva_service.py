"""
Factiva (Dow Jones) API Service.
Handles authentication and content retrieval from Factiva.
"""

import logging
import httpx
from typing import Dict, List, Optional, Any

from app.core.config import get_settings

logger = logging.getLogger(__name__)
class FactivaService:
    """Service for fetching content from Dow Jones Factiva API."""
    
    def __init__(self):
        self._access_token: Optional[str] = None
        self._id_token: Optional[str] = None
        self._pib_token: Optional[str] = None
        settings = get_settings()
        
        self.config = {
            "auth_url": settings.FACTIVA_AUTH_URL,
            "content_url": settings.FACTIVA_CONTENT_URL,
            "username": settings.FACTIVA_USERNAME,
            "client_id": settings.FACTIVA_CLIENT_ID,
            "password": settings.FACTIVA_PASSWORD
        }
    
    async def _get_initial_tokens(self) -> tuple[str, str]:
        """Get initial access_token and id_token using password grant."""
        async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
            response = await client.post(
                self.config["auth_url"],
                data={
                    "username": self.config["username"],
                    "client_id": self.config["client_id"],
                    "password": self.config["password"],
                    "connection": "service-account",
                    "grant_type": "password",
                    "scope": "openid service_account_id"
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            response.raise_for_status()
            data = response.json()
            return data["access_token"], data["id_token"]
    
    async def _get_pib_token(self, access_token: str, id_token: str) -> str:
        """Exchange tokens for PIB token using JWT bearer grant."""
        async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
            response = await client.post(
                self.config["auth_url"],
                data={
                    "assertion": id_token,
                    "access_token": access_token,
                    "client_id": self.config["client_id"],
                    "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    "scope": "openid pib"
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            response.raise_for_status()
            data = response.json()
            return data["access_token"]
    
    async def authenticate(self) -> str:
        """Perform full authentication flow and return PIB token."""
        try:
            logger.info("[Factiva] Authenticating...")
            access_token, id_token = await self._get_initial_tokens()
            self._access_token = access_token
            self._id_token = id_token
            
            self._pib_token = await self._get_pib_token(access_token, id_token)
            logger.info("[Factiva] Authentication successful")
            return self._pib_token
        except Exception as e:
            logger.error(f"[Factiva] Authentication failed: {str(e)}")
            raise
    
    async def fetch_content(self, query: str, response_limit: int = 10) -> Dict[str, Any]:
        """Fetch content from Factiva API."""
        if not self._pib_token:
            await self.authenticate()
        
        # Clean query - remove any Factiva operators the LLM might add
        import re
        clean_query = re.sub(r'\s+(AND|OR)\s+\w+\([^)]+\)', '', query)
        clean_query = re.sub(r'SORTBY\([^)]+\)', '', clean_query)
        clean_query = clean_query.strip()
        
        logger.info(f"[Factiva] Clean query: {clean_query}")
        
        request_body = {
            "data": {
                "attributes": {
                    "response_limit": response_limit,
                    "query": {
                        "search_filters": [
                            {"scope": "Language", "value": "en"}
                        ],
                        "value": clean_query  # Use cleaned query
                    }
                },
                "id": "GenAIRetrieval",
                "type": "genai-content"
            }
        }
        print("factiva request body:", request_body)
        
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/vnd.dowjones.genai-content.v_1.0",
            "Authorization": f"Bearer {self._pib_token}"
        }
        
        async with httpx.AsyncClient(timeout=60.0, verify=False) as client:
            response = await client.post(
                self.config["content_url"],
                json=request_body,
                headers=headers
            )
            
            if response.status_code == 401:
                logger.info("[Factiva] Token expired, re-authenticating...")
                await self.authenticate()
                headers["Authorization"] = f"Bearer {self._pib_token}"
                response = await client.post(
                    self.config["content_url"],
                    json=request_body,
                    headers=headers
                )
            
            response.raise_for_status()
            return response.json()
    
    @staticmethod
    def format_response(factiva_response: Dict[str, Any]) -> str:
        """Format Factiva API response into context string for LLM."""
        articles = factiva_response.get("data", [])
        if not articles:
            return "No news articles found."
        
        context_parts = ["### News Articles from Factiva/Dow Jones:\n"]
        
        for i, article in enumerate(articles[:5], 1):  # Limit to 5 articles
            attrs = article.get("attributes", {})
            meta = article.get("meta", {})
            
            headline = attrs.get("headline", {}).get("main", {}).get("text", "No headline")
            source = meta.get("source", {}).get("name", "Unknown source")
            pub_date = attrs.get("publication_date", "Unknown date")
            byline = attrs.get("byline", {}).get("text", "")
            content = attrs.get("content", [])
            content_text = content[0].get("text", "") if content else ""
            
            # Truncate content
            if len(content_text) > 1000:
                content_text = content_text[:1000] + "..."
            
            context_parts.append(f"**{headline.strip()}**")
            context_parts.append(f"Source: {source} | Date: {pub_date}")
            if byline:
                context_parts.append(f"By: {byline}")
            context_parts.append(f"{content_text}\n")
            context_parts.append("---\n")
        
        return "\n".join(context_parts)