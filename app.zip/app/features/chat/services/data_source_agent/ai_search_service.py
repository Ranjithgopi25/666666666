"""
Azure AI Search Service.
Handles retrieval from Azure Cognitive Search index.
"""

import logging
from typing import Dict, Any, List, Optional
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class AISearchService:
    """Service for fetching content from Azure AI Search."""
    
    def __init__(self, endpoint: str, index_name: str, api_key: str):
        self.endpoint = endpoint or settings.AI_SEARCH_ENDPOINT
        self.index_name = index_name or settings.AI_SEARCH_INDEX_NAME
        api_key = api_key or settings.AI_SEARCH_API_KEY
        self.client = SearchClient(
            endpoint=endpoint,
            index_name=index_name,
            credential=AzureKeyCredential(api_key)
        )
        logger.info(f"[AISearch] Initialized with index: {index_name}")
    
    async def search_documents(
        self, 
        query: str, 
        top: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Search documents in Azure AI Search.
        
        Args:
            query: Search query string
            top: Number of results to return
            
        Returns:
            List of search results with chunks
        """
        try:
            logger.info(f"[AISearch] Searching for: {query}")
            
            results = self.client.search(
                search_text=query,
                include_total_count=True,
                top=top
            )
            
            documents = []
            for result in results:
                chunk = result.get('chunk', '')
                if chunk:
                    documents.append({
                        'chunk': chunk,
                        'score': result.get('@search.score', 0)
                    })
            
            logger.info(f"[AISearch] Found {len(documents)} results")
            return documents
            
        except Exception as e:
            logger.error(f"[AISearch] Search error: {e}")
            raise
    
    @staticmethod
    def format_response(search_results: List[Dict[str, Any]]) -> str:
        """Format AI Search results for LLM context."""
        if not search_results:
            return "No relevant documents found in internal knowledge base."
        
        context_parts = ["### Internal Knowledge Base Results:\n"]
        
        for i, doc in enumerate(search_results, 1):
            chunk = doc.get('chunk', '')
            score = doc.get('score', 0)
            
            context_parts.append(f"**Document {i}** (Relevance: {score:.2f})")
            context_parts.append(f"{chunk}\n")
            context_parts.append("---\n")
        
        return "\n".join(context_parts)