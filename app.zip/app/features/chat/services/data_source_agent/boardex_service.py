"""
BoardEx Database Service.
Handles Databricks connections and queries for executive/advisor data.
"""

import logging
from typing import Optional, List, Dict, Any
from concurrent.futures import ThreadPoolExecutor
import asyncio

# from .config import DATABRICKS_CONFIG, SCHEMA_REGISTRY
    

logger = logging.getLogger(__name__)

# Handle missing config gracefully
try:
    from .config import SCHEMA_REGISTRY
    from app.core.config import get_settings
    
    settings = get_settings()
    # Use settings from config instead of hardcoded values
    DATABRICKS_CONFIG = {
        "host": settings.DATABRICKS_HOST,
        "http_path": settings.DATABRICKS_HTTP_PATH,
        "access_token": settings.DATABRICKS_TOKEN,
        "catalog": settings.DATABRICKS_CATALOG or "thirdpartydata_dev",
        "schema": settings.DATABRICKS_SCHEMA or "boardex"
    }
except ImportError:
    from app.core.config import get_settings
    settings = get_settings()
    DATABRICKS_CONFIG = {
        "host": settings.DATABRICKS_HOST,
        "http_path": settings.DATABRICKS_HTTP_PATH,
        "access_token": settings.DATABRICKS_TOKEN,
        "catalog": settings.DATABRICKS_CATALOG or "thirdpartydata_dev",
        "schema": settings.DATABRICKS_SCHEMA or "boardex"
    }
    SCHEMA_REGISTRY = {}
# Import databricks-sql-connector
try:
    from databricks import sql as databricks_sql
    DATABRICKS_AVAILABLE = True
except ImportError:
    DATABRICKS_AVAILABLE = False
    logger.warning("[BoardEx] databricks-sql-connector not installed")


class BoardExService:
    """Service for querying BoardEx Databricks database."""
    
    # Table configurations
    ADVISORS_TABLE = "company_profile_advisors"
    ACHIEVEMENTS_TABLE = "director_profile_achievements"
    
    # Available columns for each table
    ADVISOR_COLUMNS = [
        "BoardID", "BoardName", "ClientCompanyID", "AdvisorName",
        "AdvTypeDesc", "OrgVisible", "Last_Refreshed_Date", "SrcName"
    ]
    
    ACHIEVEMENT_COLUMNS = [
        "PrimaryKeyID", "RowType", "DirectorID", "DirectorName",
        "ClientDirectorID", "CompanyID", "CompanyName", "ClientCompanyID",
        "AchievementDate", "AchievementDateFlag", "AchievementDateDisplay",
        "Achievement", "Last_Refreshed_Date", "SrcName"
    ]
    
    def __init__(self):
        self.config = DATABRICKS_CONFIG
        self.schema = SCHEMA_REGISTRY.get("boardex", {})
        self._connection = None
        self._executor = ThreadPoolExecutor(max_workers=2)
    
    def _get_full_table_name(self, table: str) -> str:
        """Get fully qualified table name."""
        from app.core.config import get_settings
        settings = get_settings()
        catalog = self.config.get("catalog") or settings.DATABRICKS_CATALOG or "thirdpartydata_dev"
        schema = self.config.get("schema") or settings.DATABRICKS_SCHEMA or "boardex"
        return f"{catalog}.{schema}.{table}"
    
    def _connect_sync(self) -> bool:
        """Synchronous connection (runs in thread pool)."""
        if not DATABRICKS_AVAILABLE:
            logger.error("[BoardEx] databricks-sql-connector not available")
            return False
        
        try:
            if self._connection:
                return True
            
            self._connection = databricks_sql.connect(
                server_hostname=DATABRICKS_CONFIG.get("host") or DATABRICKS_CONFIG.get("server_hostname"),
                http_path=DATABRICKS_CONFIG["http_path"],
                access_token=DATABRICKS_CONFIG["access_token"]
            )
            logger.info("[BoardEx] Connected to Databricks")
            return True
        except Exception as e:
            logger.error(f"[BoardEx] Connection failed: {e}")
            return False
    
    async def connect(self) -> bool:
        """Async connection wrapper."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self._executor, self._connect_sync)
    
    def _execute_query_sync(self, query: str) -> List[Dict[str, Any]]:
        """Execute query synchronously."""
        if not self._connection:
            raise Exception("Not connected to database")
        
        cursor = self._connection.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))
        
        cursor.close()
        return results
    
    async def execute_query(self, query: str) -> List[Dict[str, Any]]:
        """Execute raw query asynchronously."""
        await self.connect()
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor,
            self._execute_query_sync,
            query
        )
    
    async def execute_flexible_advisor_query(
        self,
        board_name: Optional[str] = None,
        advisor_name: Optional[str] = None,
        advisor_type: Optional[str] = None,
        custom_where_clause: Optional[str] = None,
        select_columns: Optional[List[str]] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Execute a flexible query on the advisors table.
        
        Args:
            board_name: Filter by company/board name (LIKE match)
            advisor_name: Filter by advisor name (LIKE match)
            advisor_type: Filter by advisor type ('Auditors', 'Corporate Advisors', etc.)
            custom_where_clause: Additional WHERE conditions
            select_columns: Columns to select (None = default columns)
            limit: Max rows to return
        """
        await self.connect()
        
        table_name = self._get_full_table_name(self.ADVISORS_TABLE)
        
        # Build SELECT clause
        if select_columns:
            valid_cols = [c for c in select_columns if c in self.ADVISOR_COLUMNS]
            if not valid_cols:
                valid_cols = ["BoardName", "AdvisorName", "AdvTypeDesc"]
            columns_str = ", ".join(valid_cols)
        else:
            columns_str = "BoardName, AdvisorName, AdvTypeDesc, OrgVisible"
        
        # Build WHERE clause
        conditions = ["OrgVisible = 'Yes'"]
        
        if board_name:
            safe_name = board_name.replace("'", "''")
            conditions.append(f"LOWER(BoardName) LIKE LOWER('%{safe_name}%')")
        
        if advisor_name:
            safe_advisor = advisor_name.replace("'", "''")
            conditions.append(f"LOWER(AdvisorName) LIKE LOWER('%{safe_advisor}%')")
        
        if advisor_type:
            safe_type = advisor_type.replace("'", "''")
            conditions.append(f"AdvTypeDesc = '{safe_type}'")
        
        if custom_where_clause:
            # Basic SQL injection prevention
            if not any(kw in custom_where_clause.upper() for kw in ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'TRUNCATE', '--', ';']):
                conditions.append(f"({custom_where_clause})")
        
        where_clause = " AND ".join(conditions)
        
        query = f"""
        SELECT DISTINCT {columns_str}
        FROM {table_name}
        WHERE {where_clause}
        ORDER BY BoardName
        LIMIT {limit}
        """
        
        logger.info(f"[BoardEx] Executing advisor query: {query[:200]}...")
        return await self.execute_query(query)
    
    async def execute_flexible_achievement_query(
        self,
        director_name: Optional[str] = None,
        company_name: Optional[str] = None,
        achievement_keyword: Optional[str] = None,
        custom_where_clause: Optional[str] = None,
        select_columns: Optional[List[str]] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Execute a flexible query on the achievements table.
        
        Args:
            director_name: Filter by director name (LIKE match)
            company_name: Filter by company name (LIKE match)
            achievement_keyword: Filter achievements containing this keyword
            custom_where_clause: Additional WHERE conditions
            select_columns: Columns to select (None = default columns)
            limit: Max rows to return
        """
        await self.connect()
        
        table_name = self._get_full_table_name(self.ACHIEVEMENTS_TABLE)
        
        # Build SELECT clause
        if select_columns:
            valid_cols = [c for c in select_columns if c in self.ACHIEVEMENT_COLUMNS]
            if not valid_cols:
                valid_cols = ["DirectorName", "CompanyName", "Achievement", "AchievementDateDisplay"]
            columns_str = ", ".join(valid_cols)
        else:
            columns_str = "DirectorName, CompanyName, Achievement, AchievementDateDisplay, AchievementDate"
        
        # Build WHERE clause
        conditions = ["1=1"]
        
        if director_name:
            safe_name = director_name.replace("'", "''")
            conditions.append(f"LOWER(DirectorName) LIKE LOWER('%{safe_name}%')")
        
        if company_name:
            safe_company = company_name.replace("'", "''")
            conditions.append(f"LOWER(CompanyName) LIKE LOWER('%{safe_company}%')")
        
        if achievement_keyword:
            safe_keyword = achievement_keyword.replace("'", "''")
            conditions.append(f"LOWER(Achievement) LIKE LOWER('%{safe_keyword}%')")
        
        if custom_where_clause:
            if not any(kw in custom_where_clause.upper() for kw in ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'TRUNCATE', '--', ';']):
                conditions.append(f"({custom_where_clause})")
        
        where_clause = " AND ".join(conditions)
        
        query = f"""
        SELECT {columns_str}
        FROM {table_name}
        WHERE {where_clause}
        ORDER BY AchievementDate DESC
        LIMIT {limit}
        """
        
        logger.info(f"[BoardEx] Executing achievement query: {query[:200]}...")
        return await self.execute_query(query)
    
    async def get_company_advisors(
        self,
        company_name: Optional[str] = None,
        advisor_name: Optional[str] = None,
        advisor_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Convenience method for getting company advisors."""
        return await self.execute_flexible_advisor_query(
            board_name=company_name,
            advisor_name=advisor_name,
            advisor_type=advisor_type
        )
    
    async def get_director_achievements(
        self,
        director_name: Optional[str] = None,
        company_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Convenience method for getting director achievements."""
        return await self.execute_flexible_achievement_query(
            director_name=director_name,
            company_name=company_name
        )
    
    @staticmethod
    def format_response(results: List[Dict[str, Any]], is_advisor: bool = True) -> str:
        """Format query results into readable context."""
        if not results:
            return "No BoardEx data found for the specified criteria."
        
        context_parts = ["### Data from BoardEx:\n"]
        
        if is_advisor:
            # Format advisor data - group by company
            companies = {}
            for row in results:
                company = row.get("BoardName", "Unknown")
                if company not in companies:
                    companies[company] = []
                companies[company].append(row)
            
            for company, rows in list(companies.items())[:15]:
                context_parts.append(f"**{company}**")
                for row in rows:
                    advisor = row.get("AdvisorName", "")
                    adv_type = row.get("AdvTypeDesc", "")
                    context_parts.append(f"- {adv_type}: {advisor}")
                context_parts.append("")
        else:
            # Format achievement data
            for row in results[:20]:
                director = row.get("DirectorName", "Unknown")
                company = row.get("CompanyName", "")
                achievement = row.get("Achievement", "")
                date = row.get("AchievementDateDisplay", "")
                
                context_parts.append(f"**{director}**" + (f" ({company})" if company else ""))
                context_parts.append(f"- {achievement}" + (f" ({date})" if date else ""))
                context_parts.append("")
        
        return "\n".join(context_parts)
    
    def close(self):
        """Close database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None
            logger.info("[BoardEx] Connection closed")