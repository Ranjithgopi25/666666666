from pydantic import BaseModel, Field
from typing import List, Optional

class Message(BaseModel):
    role: str = Field(..., description="Message role: user, assistant, or system")
    content: str = Field(..., description="Message content")

class ChatRequest(BaseModel):
    messages: List[Message] = Field(..., description="List of conversation messages")
    stream: bool = Field(default=False, description="Whether to stream the response")
    user_id: Optional[str] = Field(None, description="Optional user ID for chat history tracking (email)")
    session_id: Optional[str] = Field(None, description="Optional session ID for chat history tracking")
    source: Optional[str] = Field(default="Chat", description="Source of conversation (DDDC, Market_Intelligence, Thought_Leadership, Export, Chat)")
    
class ChatResponse(BaseModel):
    content: str = Field(..., description="Assistant's response content")
    role: str = Field(default="assistant", description="Response role")

class IntentDetectionRequest(BaseModel):
    input: str = Field(..., description="User input to analyze for edit intent")

class IntentDetectionResponse(BaseModel):
    is_edit_intent: bool = Field(..., description="Whether the input indicates edit/improve/review intent")
    confidence: float = Field(..., description="Confidence score between 0.0 and 1.0", ge=0.0, le=1.0)
    detected_editors: List[str] = Field(default_factory=list, description="List of detected editor IDs if mentioned by user. Valid IDs: line, copy, development, content, brand-alignment")

class DraftIntentDetectionRequest(BaseModel):
    input: str = Field(..., description="User input to analyze for draft/write/create intent")

class DraftIntentDetectionResponse(BaseModel):
    is_draft_intent: bool = Field(..., description="Whether the input indicates draft/write/create intent")
    confidence: float = Field(..., description="Confidence score between 0.0 and 1.0", ge=0.0, le=1.0)
    detected_topic: Optional[str] = Field(None, description="Detected topic for the content")
    detected_content_type: List[str] = Field(default_factory=list, description="List of detected content IDs if mentioned by user. Valid IDs: Article, Blog, Executive Brief, White Paper")
    word_limit: Optional[str] = Field(None, description="Detected word limit as a string number (e.g., '2000')")
    audience_tone: Optional[str] = Field(None, description="Detected audience or tone description (e.g., 'C-suite executives', 'warm tone')")
 