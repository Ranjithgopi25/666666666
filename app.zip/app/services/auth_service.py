import httpx
import jwt
from typing import Dict
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.core.config import config

JWKS_CACHE: Dict = {}
tenant_id = config.AZURE_TENANT_ID
client_id = config.AZURE_CLIENT_ID

async def get_jwks():
    """Fetches and caches the JWKS from the Azure AD metadata endpoint."""
    if not JWKS_CACHE:
        async with httpx.AsyncClient() as client:
            try:
                # Fetch the OpenID configuration to get the JWKS URI
                oidc_config = (
                    await client.get(
                        f"https://login.microsoftonline.com/{tenant_id}/v2.0/.well-known/openid-configuration"
                    )
                ).json()
                jwks_uri = oidc_config["jwks_uri"]
                
                # Fetch the JWKS itself
                jwks = (await client.get(jwks_uri)).json()
                JWKS_CACHE.update(jwks)
                print("Successfully fetched JWKS from Azure AD.")
            except httpx.HTTPError as e:
                print(f"HTTP error fetching JWKS: {e}")
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Could not retrieve public keys.")
            except KeyError:
                print("JWKS URI not found in OIDC configuration.")
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Invalid OIDC configuration.")
    return JWKS_CACHE

def get_public_key(kid: str) -> str:
    """Finds the correct public key from the JWKS based on the token's kid."""
    for key in JWKS_CACHE.get("keys", []):
        if key["kid"] == kid:
            return jwt.algorithms.RSAAlgorithm.from_jwk(key)
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token kid.")

security = HTTPBearer()

async def validate_jwt_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Validates an MSAL-issued JWT token and returns the payload."""
    token = credentials.credentials
    try:
        # Step 1: Decode header to get the 'kid' and 'alg'
        header = jwt.get_unverified_header(token)
        kid = header.get("kid")
        alg = header.get("alg")

        if not kid or not alg:
            raise jwt.PyJWTError("Token header missing kid or alg.")

        # Step 2: Fetch JWKS and get the correct public key
        await get_jwks()
        public_key = get_public_key(kid)
        print("Public key retrieved for token validation.")

        # Step 3: Decode and validate the token with the public key
        payload = jwt.decode(
            token,
            key=public_key,
            algorithms=[alg],
            audience=client_id,
            issuer=f"https://login.microsoftonline.com/{tenant_id}/v2.0"
        )

        return payload

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token has expired.")
    except jwt.InvalidAudienceError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid audience. The token is not for this application.")
    except jwt.InvalidIssuerError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid issuer.")
    except jwt.PyJWTError as e:
        print(f"JWT validation error: {e}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f"Invalid token: {e}")