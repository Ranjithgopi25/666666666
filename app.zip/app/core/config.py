from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
import os
import logging
from dotenv import load_dotenv
from typing import Optional

logger = logging.getLogger(__name__)


def _load_secrets_from_volume(secrets_path: str) -> dict[str, str]:
    """Load secrets from files in a mounted volume directory."""
    secrets = {}
    if os.path.exists(secrets_path):
        for filename in os.listdir(secrets_path):
            file_path = os.path.join(secrets_path, filename)
            if os.path.isfile(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    secrets[filename] = f.read().strip()
    return secrets


def _initialize_config() -> None:
    """Load config with precedence: secrets volume > env vars > .env file."""
    load_dotenv()

    secrets_path = os.environ.get("SECRETS_VOLUME_PATH", "/var/app/secrets")
    if os.path.exists(secrets_path):
        logger.info(f"Loading secrets from {secrets_path}")
        secrets = _load_secrets_from_volume(secrets_path)
        for key, value in secrets.items():
            os.environ[key] = value
    else:
        logger.warning(f"Secrets path {secrets_path} does not exist, skipping volume secrets")

    logger.debug("Configuration sources loaded")


# Initialize configuration on module import
_initialize_config()


class Settings(BaseSettings):
    """Application settings loaded from environment variables and secrets volume."""

    # ===== API Configuration =====
    API_V1_PREFIX: str = "/api/v1"
    PROJECT_NAME: str = "PwC Presentation Assistant"
    VERSION: str = "1.0.0"

    # ===== LLM Configuration =====
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 30000
    # ===== Thought Leadership / TL defaults =====
    TL_WORD_LIMIT_DEFAULT: int = 10000

    # ===== App Configuration =====
    APP_ENV: str = os.getenv("APP_ENV", "")

    # ===== Azure AD =====
    AZURE_CLIENT_ID: str = os.getenv("AZURE_CLIENT_ID", "")
    AZURE_CLIENT_SECRET: str = os.getenv("AZURE_CLIENT_SECRET", "")
    AZURE_REDIRECT_URI: str = os.getenv("AZURE_REDIRECT_URI", "")
    AZURE_TENANT_ID: str = os.getenv("AZURE_TENANT_ID", "")

    # ===== Azure OpenAI Configuration =====
    AZURE_OPENAI_ENDPOINT: str = os.getenv("AI_ENDPOINT", "")
    AZURE_OPENAI_API_KEY: str = os.getenv("AI_API_KEY", "")
    AZURE_OPENAI_DEPLOYMENT: str = os.getenv("AI_MODEL", "")
    AZURE_OPENAI_API_VERSION: str = os.getenv("AZURE_OPENAI_API_VERSION", "")

    #===== MCX Database Configuration =====
    MCX_DB_DRIVER: str = os.getenv("MCX_DB_DRIVER", "")
    MCX_DB_SERVER: str = os.getenv("MCX_DB_SERVER", "")
    MCX_DB_NAME: str = os.getenv("MCX_DB_NAME", "")
    MCX_DB_USERNAME: str =  os.getenv("MCX_DB_USERNAME", "")
    MCX_DB_PASSWORD: str = os.getenv("MCX_DB_PASSWORD", "")

    @property
    def chat_db_connection_string(self) -> str:
        """Construct SQL Server connection string for chat history."""
        return (
            f"DRIVER={self.MCX_DB_DRIVER};"
            f"SERVER={self.MCX_DB_SERVER};"
            f"DATABASE={self.MCX_DB_NAME};"
            f"UID={self.MCX_DB_USERNAME};"
            f"PWD={self.MCX_DB_PASSWORD};"
            "Encrypt=yes;"
            "TrustServerCertificate=no;"
            "Connection Timeout=30;"
        )

    # ===== Azure Speech Services Configuration =====
    AZURE_SPEECH_KEY: str = os.getenv("AZURE_SPEECH_KEY", "")
    AZURE_SPEECH_ENDPOINT: str = os.getenv("AZURE_SPEECH_ENDPOINT", "")

    # ===== Factiva API Configuration =====
    FACTIVA_API_KEY: str = os.getenv("FACTIVA_API_KEY", "")
    FACTIVA_SERVICE_ACCOUNT_USERNAME: str = os.getenv("FACTIVA_SERVICE_ACCOUNT_USERNAME", "")
    FACTIVA_SERVICE_ACCOUNT_CLIENT_ID: str = os.getenv("FACTIVA_SERVICE_ACCOUNT_CLIENT_ID", "")
    FACTIVA_SERVICE_ACCOUNT_PASSWORD: str = os.getenv("FACTIVA_SERVICE_ACCOUNT_PASSWORD", "")
    FACTIVA_ENDPOINT: str = "/content/gen-ai/retrieve"
    FACTIVA_BASE_URL: str = "https://api.dowjones.com"
    FACTIVA_RESPONSE_LIMITS: dict[str, int] = {
        "article": 8,
        "blog": 5,
        "white_paper": 10,
        "executive_brief": 15,
    }
    FACTIVA_CONDUCT_RESEARCH_LIMIT: int = 5
    FACTIVA_SEARCH_FILTERS: list[str] = ["en", "de"]

    # ===== Factiva API Configuration =====
    FACTIVA_AUTH_URL: str = os.getenv("FACTIVA_AUTH_URL", "")
    FACTIVA_CONTENT_URL: str = os.getenv("FACTIVA_CONTENT_URL", "")
    FACTIVA_USERNAME: str = os.getenv("FACTIVA_USERNAME", "")
    FACTIVA_CLIENT_ID: str = os.getenv("FACTIVA_CLIENT_ID", "")
    FACTIVA_PASSWORD: str = os.getenv("FACTIVA_PASSWORD", "")

    # ===== SQL Server Configuration (CapitalIQ) =====
    SQLSERVER_SERVER: str = os.getenv("SQLSERVER_SERVER", "")
    SQLSERVER_DATABASE: str = os.getenv("SQLSERVER_DATABASE", "")
    SQLSERVER_USERNAME: str = os.getenv("SQLSERVER_USERNAME", "")
    SQLSERVER_PASSWORD: str = os.getenv("SQLSERVER_PASSWORD", "")
    
    # ===== Databricks Configuration (BoardEx) =====
    DATABRICKS_HOST: str = os.getenv("DATABRICKS_HOST", "")
    DATABRICKS_HTTP_PATH: str = os.getenv("DATABRICKS_HTTP_PATH", "")
    DATABRICKS_TOKEN: str = os.getenv("DATABRICKS_TOKEN", "")
    DATABRICKS_CATALOG: str = os.getenv("DATABRICKS_CATALOG", "")
    DATABRICKS_SCHEMA: str = os.getenv("DATABRICKS_SCHEMA", "")

    # ===== PlusDocs Configuration =====
    PLUSDOCS_API_TOKEN: str = os.getenv("PLUSDOCS_API_TOKEN", "")
    PLUSDOCS_TEMPLATE_ID: str = os.getenv("PLUSDOCS_TEMPLATE_ID", "")
    PLUSDOCS_POLL_INTERVAL: int = 5
    PLUSDOCS_MAX_ATTEMPTS: int = 60
    PLUSDOC_BASE_URL: str = os.getenv("PLUSDOC_BASE_URL","")

    # ===== Azure AI Search Configuration =====
    AI_SEARCH_ENDPOINT: str = os.getenv("AI_SEARCH_ENDPOINT", "")
    AI_SEARCH_INDEX_NAME: str = os.getenv("AI_SEARCH_INDEX_NAME", "")
    AI_SEARCH_API_KEY: str = os.getenv("AI_SEARCH_API_KEY", "")

    # =================CONNNECTED SOURCE======================
    CONNECTED_SOURCE_API_URL: str=os.getenv("CONNECTED_SOURCE_API_URL", "")
    PASSAGE_RETRIEVAL_API_URL: str=os.getenv("PASSAGE_RETRIEVAL_API_URL","")
    PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY: str=os.getenv("PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY","")
    PASSAGE_RETRIEVAL_SC_APIKEY: str =os.getenv("PASSAGE_RETRIEVAL_SC_APIKEY","")

    BENCHMARKING_BASE_URL: str = os.getenv("BENCHMARKING_BASE_URL", "")
    BENCHMARKING_SUBSCRIPTION_KEY: str = os.getenv("BENCHMARKING_SUBSCRIPTION_KEY", "")
    BENCHMARKING_PASSWORD: str = os.getenv("BENCHMARKING_PASSWORD", "")
    BENCHMARKING_USERNAME: str = os.getenv("BENCHMARKING_USERNAME", "")


    # =================TAVILY_API_KEY======================
    TAVILY_API_KEY: str = os.getenv("TAVILY_API_KEY", "")
    
    # =================SSL Configuration======================
    SSL_CHECK_HOSTNAME: bool = os.getenv("SSL_CHECK_HOSTNAME", "false").lower() == "true"


    # ===== Connectivity Check Configuration =====
    # These will be set per environment via environment variables
    SHAREPOINT_SITE_URL: str = os.getenv("SHAREPOINT_SITE_URL", "")
    CDO_DB_SERVER: str = os.getenv("CDO_DB_SERVER", "")
    CDO_DB_NAME: str = os.getenv("CDO_DB_NAME", "")
    CDO_DB_USERNAME: str = os.getenv("CDO_DB_USERNAME", "")
    AZURE_BLOB_CLIENT_ID: str = os.getenv("AZURE_BLOB_CLIENT_ID", "")
    AZURE_BLOB_CLIENT_SECRET: str = os.getenv("AZURE_BLOB_CLIENT_SECRET", "")
    AZURE_BLOB_ACCOUNT_NAME: str = os.getenv("AZURE_BLOB_ACCOUNT_NAME", "")
    AZURE_BLOB_CONNECTION_STRING: str = os.getenv("AZURE_BLOB_CONNECTION_STRING", "")
    
    # Shared configuration
    SHAREPOINT_TENANT_ID: str = os.getenv("SHAREPOINT_TENANT_ID", "")
    SHAREPOINT_CLIENT_ID: str = os.getenv("SHAREPOINT_CLIENT_ID", "")
    SHAREPOINT_CLIENT_SECRET: str = os.getenv("SHAREPOINT_CLIENT_SECRET", "")
    AZURE_BLOB_TENANT_ID: str = os.getenv("AZURE_BLOB_TENANT_ID", "")
    CSS_CLIENT_ID: str = os.getenv("CSS_CLIENT_ID", "")
    CSS_CLIENT_SECRET: str = os.getenv("CSS_CLIENT_SECRET", "")
    CSS_SCOPE: str = os.getenv("CSS_SCOPE", "")
    CSS_API_ENDPOINT: str = os.getenv("CSS_API_ENDPOINT", "")
    CDO_DB_DRIVER: str = os.getenv("CDO_DB_DRIVER", "")

    #======= Phoenix APIs =======
    TOKEN_URL_PHOENIX: str = os.getenv("TOKEN_URL_PHOENIX","")
    BASIC_AUTH_PHOENIX: str = os.getenv("BASIC_AUTH_PHOENIX","")
    CREATE_REQUEST_URL_PHOENIX: str = os.getenv("CREATE_REQUEST_URL_PHOENIX","")
    GET_CONFIG_DDC_URL_PHOENIX: str = os.getenv("GET_CONFIG_DDC_URL_PHOENIX","")
    GET_CONFIG_TL_URL_PHOENIX: str = os.getenv("GET_CONFIG_TL_URL_PHOENIX","")
    REQUEST_TIMEOUT_PHOENIX: int = 60

    #======= Redis Configuration =======
    REDIS_HOST: str = os.getenv("REDIS_HOST", "")
    REDIS_PORT: int = int(os.getenv("REDIS_PORT", "6379") or "6379")
    REDIS_PASSWORD: str = os.getenv("REDIS_PASSWORD", "")
    REDIS_SSL: bool = os.getenv("REDIS_SSL", "false").lower() == "true"

    #======= M365 User Auth =======
    M365_OAUTH_URL: str = os.getenv("M365_OAUTH_URL", "")
    M365_API_URL: str = os.getenv("M365_API_URL", "")
    M365_AUTH_TOKEN: str = os.getenv("M365_AUTH_TOKEN", "")


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


def get_config() -> dict:
    """Get connectivity check configuration from environment variables."""
    settings = get_settings()
    
    return {
        "sql": {
            "driver": settings.MCX_DB_DRIVER,
            "server": settings.MCX_DB_SERVER,
            "database": settings.MCX_DB_NAME,
            "username": settings.MCX_DB_USERNAME,
            "password": settings.MCX_DB_PASSWORD,
        },
        "azure_search": {
            "endpoint": settings.AI_SEARCH_ENDPOINT,
            "index": settings.AI_SEARCH_INDEX_NAME,
            "api_key": settings.AI_SEARCH_API_KEY,
        },
        "sharepoint": {
            "tenant_id": settings.SHAREPOINT_TENANT_ID,
            "client_id": settings.SHAREPOINT_CLIENT_ID,
            "client_secret": settings.SHAREPOINT_CLIENT_SECRET,
            "site_url": settings.SHAREPOINT_SITE_URL,
        },
        "speech": {
            "subscription_key": settings.AZURE_SPEECH_KEY,
            "endpoint": settings.AZURE_SPEECH_ENDPOINT,
        },
        "cdo_database": {
            "driver": settings.CDO_DB_DRIVER,
            "server": settings.CDO_DB_SERVER,
            "database": settings.CDO_DB_NAME,
            "username": settings.CDO_DB_USERNAME,
            "password": settings.SQLSERVER_PASSWORD.replace("k", "$(").replace("m","{"),
        },
        "cdo_databricks": {
            "host": settings.DATABRICKS_HOST,
            "http_path": settings.DATABRICKS_HTTP_PATH,
            "access_token": settings.DATABRICKS_TOKEN,
            "catalog": settings.DATABRICKS_CATALOG,
            "schema": settings.DATABRICKS_SCHEMA,
        },
        "tavily": {
            "api_key": settings.TAVILY_API_KEY,
        },
        "azure_blob": {
            "tenant_id": settings.AZURE_BLOB_TENANT_ID,
            "client_id": settings.AZURE_BLOB_CLIENT_ID,
            "client_secret": settings.AZURE_BLOB_CLIENT_SECRET,
            "account_name": settings.AZURE_BLOB_ACCOUNT_NAME,
            "connection_string": settings.AZURE_BLOB_CONNECTION_STRING,
        },
        "css": {
            "tenant_id": settings.AZURE_BLOB_TENANT_ID,
            "client_id": settings.CSS_CLIENT_ID,
            "client_secret": settings.CSS_CLIENT_SECRET,
            "scope": settings.CSS_SCOPE,
            "auth_url": f"https://login.microsoftonline.com/{settings.AZURE_BLOB_TENANT_ID}/oauth2/v2.0/token",
            "api_endpoint": settings.CSS_API_ENDPOINT,
        },
        "openai": {
            "endpoint": settings.AZURE_OPENAI_ENDPOINT,
            "api_key": settings.AZURE_OPENAI_API_KEY,
            "deployment": settings.AZURE_OPENAI_DEPLOYMENT,
            "api_version": settings.AZURE_OPENAI_API_VERSION,
        },
        "factiva": {
            "auth_url": settings.FACTIVA_AUTH_URL,
            "content_url": settings.FACTIVA_CONTENT_URL,
            "username": settings.FACTIVA_USERNAME,
            "client_id": settings.FACTIVA_CLIENT_ID,
            "password": settings.FACTIVA_PASSWORD,
        },
        "connected_source": {
            "api_url": settings.PASSAGE_RETRIEVAL_API_URL,
            "subscription_key": settings.PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY,
            "sc_apikey": settings.PASSAGE_RETRIEVAL_SC_APIKEY,  
        },
        "redis": {
            "host": settings.REDIS_HOST,
            "port": settings.REDIS_PORT,
            "password": settings.REDIS_PASSWORD,
            "ssl": settings.REDIS_SSL,
        },
        "plusdocs": {
            "api_token": settings.PLUSDOCS_API_TOKEN,
            "template_id": settings.PLUSDOCS_TEMPLATE_ID,
            "base_url": settings.PLUSDOC_BASE_URL or "https://api.plusdocs.com/r/v0",
        },
        "phoenix": {
            "oauth_url": settings.TOKEN_URL_PHOENIX,
            "basic_auth": settings.BASIC_AUTH_PHOENIX,
            "ifs_config_url": settings.GET_CONFIG_TL_URL_PHOENIX,
            "ifs_create_request_url": settings.CREATE_REQUEST_URL_PHOENIX,
        },
    }

# Alias for backward compatibility
get_connectivity_config = get_config
    
config = Settings()
