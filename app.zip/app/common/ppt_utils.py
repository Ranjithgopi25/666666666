from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
import io
import logging
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

PWC_ORANGE = RGBColor(208, 74, 2)
PWC_BLACK = RGBColor(0, 0, 0)

def load_presentation(ppt_bytes: bytes) -> Presentation:
    """Load a PowerPoint presentation from bytes"""
    return Presentation(io.BytesIO(ppt_bytes))

def save_presentation(prs: Presentation) -> bytes:
    """Save a PowerPoint presentation to bytes"""
    output = io.BytesIO()
    prs.save(output)
    output.seek(0)
    return output.getvalue()

def extract_text_from_ppt(prs: Presentation) -> str:
    """Extract all text from a PowerPoint presentation"""
    text_content = []
    for slide_num, slide in enumerate(prs.slides, 1):
        slide_text = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text:
                slide_text.append(shape.text)
        if slide_text:
            text_content.append(f"Slide {slide_num}:\n" + "\n".join(slide_text))
    return "\n\n".join(text_content)

def apply_pwc_branding(shape, is_title: bool = False):
    """Apply PwC branding to a shape"""
    if hasattr(shape, "text_frame"):
        for paragraph in shape.text_frame.paragraphs:
            for run in paragraph.runs:
                run.font.name = "Arial"
                if is_title:
                    run.font.size = Pt(28)
                    run.font.bold = True
                    run.font.color.rgb = PWC_ORANGE
                else:
                    run.font.size = Pt(18)
                    run.font.color.rgb = PWC_BLACK

def create_blank_presentation() -> Presentation:
    """Create a new blank PowerPoint presentation"""
    return Presentation()

def add_title_slide(prs: Presentation, title: str, subtitle: str = "") -> None:
    """Add a title slide to presentation"""
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    
    title_shape = slide.shapes.title
    subtitle_shape = slide.placeholders[1]
    
    title_shape.text = title
    if subtitle:
        subtitle_shape.text = subtitle
    
    apply_pwc_branding(title_shape, is_title=True)

def add_content_slide(prs: Presentation, title: str, content: List[str]) -> None:
    """Add a content slide with bullet points"""
    bullet_slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(bullet_slide_layout)
    
    title_shape = slide.shapes.title
    body_shape = slide.placeholders[1]
    
    title_shape.text = title
    apply_pwc_branding(title_shape, is_title=True)
    
    text_frame = body_shape.text_frame
    text_frame.clear()
    
    for bullet_point in content:
        p = text_frame.add_paragraph()
        p.text = bullet_point
        p.level = 0
        apply_pwc_branding(body_shape)

def validate_ppt_structure(prs: Presentation) -> Dict:
    """Validate PowerPoint presentation structure"""
    return {
        "slide_count": len(prs.slides),
        "has_content": len(prs.slides) > 0,
        "slide_dimensions": {
            "width": prs.slide_width,
            "height": prs.slide_height
        }
    }

def sanitize_presentation(
    ppt_bytes: bytes,
    tier: int = 1,
    page_range: Optional[str] = None,
    custom_replacements: Optional[Dict[str, str]] = None
) -> bytes:
    """Sanitize PowerPoint presentation based on tier level"""
    prs = load_presentation(ppt_bytes)
    
    if tier >= 1:
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text:
                    text = shape.text
                    text = text.replace("Client Name", "Client X")
                    text = text.replace("Confidential", "[Sanitized]")
                    shape.text = text
    
    if tier >= 2 and custom_replacements:
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text:
                    text = shape.text
                    for find_text, replace_text in custom_replacements.items():
                        text = text.replace(find_text, replace_text)
                    shape.text = text
    
    return save_presentation(prs)
