import httpx
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import ipaddress
import socket
import logging
from typing import Optional, List, Tuple

logger = logging.getLogger(__name__)

TIMEOUT_SECONDS = 10
MAX_CONTENT_LENGTH = 1_000_000

def is_safe_url(url: str) -> bool:
    """Validate URL for security (prevent SSRF attacks)"""
    try:
        parsed = urlparse(url)
        
        if parsed.scheme not in ['http', 'https']:
            return False
        
        hostname = parsed.hostname
        if not hostname:
            return False
        
        try:
            ip = socket.gethostbyname(hostname)
            ip_obj = ipaddress.ip_address(ip)
            
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local:
                logger.warning(f"Blocked private/loopback IP: {ip}")
                return False
        except Exception:
            pass
        
        return True
    except Exception as e:
        logger.error(f"URL validation error: {e}")
        return False

async def fetch_url_content(url: str) -> Optional[str]:
    """Fetch and extract text content from URL with proper headers"""
    if not is_safe_url(url):
        raise ValueError(f"Unsafe URL detected: {url}")
    
    # Headers to mimic a real browser and avoid 401 errors
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
        'DNT': '1',
        'Referer': 'https://www.google.com/'
    }
    
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT_SECONDS, headers=headers, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()
            
            content_length = len(response.content)
            if content_length > MAX_CONTENT_LENGTH:
                raise ValueError(f"Content too large: {content_length} bytes")
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove unwanted elements
            for tag in soup(['script', 'style', 'nav', 'footer', 'header', 'aside', 'iframe', 'noscript']):
                tag.decompose()
            
            # Try to extract main content (article, main, or body)
            main_content = soup.find('article') or soup.find('main') or soup.find('body')
            if main_content:
                text = main_content.get_text(separator='\n', strip=True)
            else:
                text = soup.get_text(separator='\n', strip=True)
            
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            return '\n'.join(lines)
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error fetching URL {url}: {e.response.status_code} - {e.response.reason_phrase}")
        raise
    except Exception as e:
        logger.error(f"Error fetching URL {url}: {e}")
        raise

def extract_links_from_html(html_content: str, base_url: str, max_links: int = 10) -> List[str]:
    """Extract relevant links from HTML content"""
    from urllib.parse import urljoin, urlparse
    
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        links = []
        seen = set()
        
        # Find all anchor tags with href
        for a_tag in soup.find_all('a', href=True):
            href = a_tag.get('href', '')
            if not href:
                continue
            
            # Convert relative URLs to absolute
            absolute_url = urljoin(base_url, href)
            
            # Parse to validate
            parsed = urlparse(absolute_url)
            if not parsed.scheme or not parsed.netloc:
                continue
            
            # Only include http/https links
            if parsed.scheme not in ['http', 'https']:
                continue
            
            # Skip anchors, javascript, mailto, etc.
            if href.startswith('#') or href.startswith('javascript:') or href.startswith('mailto:'):
                continue
            
            # Skip if already seen
            if absolute_url in seen:
                continue
            
            # Skip if it's the same page
            base_parsed = urlparse(base_url)
            if parsed.netloc == base_parsed.netloc and parsed.path == base_parsed.path:
                continue
            
            # Get link text for relevance check
            link_text = a_tag.get_text(strip=True).lower()
            
            # Prioritize links with meaningful text (not just "click here", "read more", etc.)
            skip_words = ['click here', 'read more', 'here', 'link', 'more', 'next', 'previous', 'back']
            if link_text and len(link_text) > 5 and not any(skip in link_text for skip in skip_words):
                links.append(absolute_url)
                seen.add(absolute_url)
                
                if len(links) >= max_links:
                    break
        
        return links
    except Exception as e:
        logger.error(f"Error extracting links from HTML: {e}")
        return []

async def fetch_url_with_links(url: str) -> Tuple[Optional[str], List[str], Optional[str]]:
    """Fetch URL content and extract relevant links from it. Returns (content, links, title)"""
    if not is_safe_url(url):
        raise ValueError(f"Unsafe URL detected: {url}")
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
        'DNT': '1',
        'Referer': 'https://www.google.com/'
    }
    
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT_SECONDS, headers=headers, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()
            
            content_length = len(response.content)
            if content_length > MAX_CONTENT_LENGTH:
                raise ValueError(f"Content too large: {content_length} bytes")
            
            html_content = response.text
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Extract title from HTML
            title = None
            title_tag = soup.find('title')
            if title_tag:
                title = title_tag.get_text(strip=True)
            else:
                # Try meta og:title
                og_title = soup.find('meta', property='og:title')
                if og_title:
                    title = og_title.get('content', '').strip()
                else:
                    # Try h1
                    h1_tag = soup.find('h1')
                    if h1_tag:
                        title = h1_tag.get_text(strip=True)
            
            # Remove unwanted elements
            for tag in soup(['script', 'style', 'nav', 'footer', 'header', 'aside', 'iframe', 'noscript']):
                tag.decompose()
            
            # Try to extract main content
            main_content = soup.find('article') or soup.find('main') or soup.find('body')
            if main_content:
                text = main_content.get_text(separator='\n', strip=True)
            else:
                text = soup.get_text(separator='\n', strip=True)
            
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            content = '\n'.join(lines)
            
            # Extract links from the original HTML
            links = extract_links_from_html(html_content, url, max_links=10)
            
            return content, links, title
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error fetching URL {url}: {e.response.status_code} - {e.response.reason_phrase}")
        raise
    except Exception as e:
        logger.error(f"Error fetching URL {url}: {e}")
        raise
