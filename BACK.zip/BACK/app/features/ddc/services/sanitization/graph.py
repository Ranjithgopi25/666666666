import os
import re
import json
import logging
import base64
import hashlib
import tempfile
from io import BytesIO
from langgraph.graph import StateGraph, END
from collections import defaultdict
from typing import List, Dict, TypedDict, Optional
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage
from pydantic import BaseModel
from .prompt import prompt, MASK_PERSON_PROMPT, MASK_COMPETITOR_PROMPT,MASK_LOCATION_PROMPT,MASK_BU_PROMPT,MASK_CLIENT_DATA_PROMPT
import time
import functools
from datetime import datetime
from app.core.config import get_settings

def timed_node(node_name: str):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(state):
            start = time.perf_counter()
            start_ts = datetime.utcnow().isoformat()

            result = func(state)

            duration = time.perf_counter() - start
            end_ts = datetime.utcnow().isoformat()

            stats = state["sanitizer"].sanitization_stats
            stats[f"{node_name}_start_ts"] = start_ts
            stats[f"{node_name}_end_ts"] = end_ts
            stats[f"{node_name}_duration_sec"] = round(duration, 4)

            logger.info(
                f"[NODE] {node_name} | "
                f"start={start_ts} | "
                f"end={end_ts} | "
                f"duration={duration:.4f}s"
            )

            return result
        return wrapper
    return decorator
def normalize_client_identifiers(raw) -> dict:
    """
    Accepts:
      - "Spire"
      - "Spire, Infosys, TCS"
      - {"client_names": [...]}

    Returns:
      {"client_names": [..]}  (always)
    """
    if raw is None:
        return {}

    # Case 1: already correct
    if isinstance(raw, dict):
        names = raw.get("client_names", [])
        return {
            "client_names": [
                n.strip()
                for n in names
                if isinstance(n, str) and n.strip()
            ]
        }

    # Case 2: comma-separated string
    if isinstance(raw, str):
        parts = [
            p.strip()
            for p in raw.split(",")
            if p.strip()
        ]
        return {"client_names": parts} if parts else {}

    # Anything else → ignore
    return {}

# =========================================================
# LLMs - Using config values

settings = get_settings()

TEXT_LLM = AzureChatOpenAI(
    azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
    api_key=settings.AZURE_OPENAI_API_KEY,
    azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    temperature=0,
)

VISION_LLM = AzureChatOpenAI(
    azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
    api_key=settings.AZURE_OPENAI_API_KEY,
    azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    temperature=0,
)

# ====================================================


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class ClientCompetitorDetails(BaseModel):
    client_names: Optional[List[str]] = None
    competitor_names: Optional[List[str]] = None

# ---------------------------
# TypedDict for LangGraph state
# ---------------------------
class PPTGraphState(TypedDict, total=False):
    input_path: str
    output_path: str
    prs: Presentation
    blocks: List[Dict]
    options: Dict[str, bool]
    sanitizer: "PPTSanitizer"
    # client_identifiers: Optional[Dict[str, str]] 
    client_identifiers: Optional[Dict[str, List[str]]]# NEW: optional hints
    # additional_guidelines: Optional[str]
    slides_map: Dict[str, Optional[List[int]]]
    stats: Dict[str, int]  

    progress_current: int
    progress_total: int
    extracted_entities: ClientCompetitorDetails 

# ---------------------------
# Pydantic models for structured LLM output
# ---------------------------
class SanitizedBlock(BaseModel):
    slide_index: int
    shape_id: int
    paragraph_index: int
    text: str
    row_index: Optional[int] = None
    col_index: Optional[int] = None
    type: Optional[str] = None
    numeric_masks: Optional[int] = 0
class SanitizedResponse(BaseModel):
    blocks: List[SanitizedBlock]

class LogoDetectionResult(BaseModel):
    is_logo: bool

# ---------------------------
# Main Sanitizer class
# ---------------------------
class PPTSanitizer:
    LOGO_CACHE: Dict[str, bool] = {}
    SUPPORTED_MIME_TYPES = {"image/png", "image/jpeg", "image/jpg", "image/webp"}

    def __init__(self, text_llm, vision_llm, options: dict | None = None,):
        self.text_llm = text_llm
        self.vision_llm = vision_llm
        self.options = options or {}

        self.sanitization_stats = defaultdict(int)

    # ---------------------------
    # TEXT BLOCK HELPERS

    def extract_text_blocks(self, pptx_path: str) -> List[Dict]:
        prs = Presentation(pptx_path)
        blocks: List[Dict] = []

        for slide_idx, slide in enumerate(prs.slides):
            for shape in slide.shapes:

                # --------------------------------------------------
                # 1️⃣ NORMAL TEXT SHAPES
                # --------------------------------------------------
                if shape.has_text_frame:
                    for para_idx, para in enumerate(shape.text_frame.paragraphs):
                        # Collect all <a:t> text nodes (works for normal text + <a:fld>)
                        texts = []
                        for el in para._p.iter():
                            if el.tag.endswith("}t") or el.tag.endswith("t"):
                                if el.text:
                                    texts.append(el.text)

                        text = "".join(texts).strip()
                        if not text:
                            continue  # skip empty paragraphs

                        blocks.append({
                            "slide_index": slide_idx,
                            "shape_id": shape.shape_id,
                            "paragraph_index": para_idx,
                            "text": text,
                            "type": "text"
                        })


                # --------------------------------------------------
                # 2️⃣ TABLES
                # --------------------------------------------------
                elif shape.has_table:
                    table = shape.table

                    for row_idx, row in enumerate(table.rows):
                        for col_idx, cell in enumerate(row.cells):
                            tf = cell.text_frame
                            for para_idx, para in enumerate(tf.paragraphs):
                                text = para.text.strip()
                                if not text:
                                    continue

                                blocks.append({
                                    "slide_index": slide_idx,
                                    "shape_id": shape.shape_id,
                                    "row_index": row_idx,
                                    "col_index": col_idx,
                                    "paragraph_index": para_idx,
                                    "text": text,
                                    "type": "table"
                                })
        # print(blocks)
        return blocks

    def force_mask_known_clients(
        self,
        blocks: List[Dict],
        known_clients: List[str],
        slides: Optional[List[int]] = None,
        token: str = "[CLIENT]"
    ) -> List[Dict]:
        """
        Deterministically masks known client names (UI-provided)(client_identifiers).
        BEFORE any LLM logic. Highest priority.
        """

        if not known_clients:
            return blocks

        escaped = [re.escape(name) for name in known_clients if name]
        if not escaped:
            return blocks

        pattern = re.compile(
            r"\b(" + "|".join(escaped) + r")\b",
            flags=re.IGNORECASE
        )

        updated = []
        for b in blocks:
            # slide scoping (respects your slides_map)
            if slides is not None and b.get("slide_index") not in slides:
                updated.append(b)
                continue

            text = b.get("text", "")
            if not text:
                updated.append(b)
                continue

            new_text, count = pattern.subn(token, text)
            if count > 0:
                b = dict(b)
                b["text"] = new_text
                self.sanitization_stats["client_name_replacements"] += count

            updated.append(b)

        return updated


    def extract_client_and_competitors_llm(
        self,
        blocks: List[Dict]
    ) -> ClientCompetitorDetails:
        """
        Extract client names and competitor names from PPT text blocks.
        READ-ONLY operation (no mutation).
        """

        payload = [
            {
                "slide_index": b["slide_index"],
                "text": b["text"]
            }
            for b in blocks
            if b.get("text")
        ]     
        structured_llm = self.text_llm.with_structured_output(
            schema=ClientCompetitorDetails
        )

        return structured_llm.invoke([
            HumanMessage(content=prompt),
            HumanMessage(content=json.dumps(payload, ensure_ascii=False))
        ])


    _XML_INVALID_CHARS = re.compile(
        r"[\x00-\x08\x0B\x0C\x0E-\x1F]"
    )


    def sanitize_for_xml(self, text: str) -> str:
        if not text:
            return ""
        return self._XML_INVALID_CHARS.sub("", text)

    def replace_text_preserve_structure(self, paragraph, new_text: str, debug: bool = False):
        """
        Node-based <a:t> replacement.
        - Preserves formatting
        - Converts <a:fld> → <a:r>
        - Replaces text per NODE (not by length)
        - First <a:t> gets full text, others cleared
        """

        new_text = self.sanitize_for_xml(new_text)
        p = paragraph._p

        # --------------------------------------------------
        # 1️⃣ Normalize <a:fld> → <a:r> (NON-RECURSIVE)
        # --------------------------------------------------
        children = list(p)

        for idx, child in enumerate(children):
            if not child.tag.endswith("}fld"):
                continue

            rpr = None
            t = None

            for el in child:
                if el.tag.endswith("}rPr"):
                    rpr = el
                elif el.tag.endswith("}t"):
                    t = el

            if t is None:
                continue

            r = p.makeelement(child.tag.replace("fld", "r"))

            if rpr is not None:
                r.append(rpr)

            r.append(t)
            p.remove(child)
            p.insert(idx, r)

        # --------------------------------------------------
        # 2️⃣ Collect DIRECT <a:t> nodes only
        # --------------------------------------------------
        text_nodes = []

        for run in p:
            for el in run:
                if el.tag.endswith("}t") and el.text is not None:
                    text_nodes.append(el)
                    if debug:
                        print(f"Collected <a:t>: '{el.text}'")

        if not text_nodes:
            return

        # --------------------------------------------------
        # 3️⃣ Node-based replacement (NO LENGTH LOGIC)
        # --------------------------------------------------
        for idx, t in enumerate(text_nodes):
            if idx == 0:
                if debug:
                    print(f"Updated first <a:t>: '{t.text}' → '{new_text}'")
                t.text = new_text
            else:
                if debug:
                    print(f"Cleared <a:t>: '{t.text}' → ''")
                t.text = ""
 
    def apply_sanitized_text(self, prs: Presentation, sanitized: List[Dict]):
        """
        Applies sanitized text to:
        - Normal text shapes
        - Table cells
        Preserves all formatting and structure.
        """
        for block in sanitized:
            slide_idx = block.get("slide_index")
            shape_id = block.get("shape_id")
            new_text = block.get("text", "")

            if slide_idx is None or shape_id is None:
                continue

            slide = prs.slides[slide_idx]

            for shape in slide.shapes:
                if shape.shape_id != shape_id:
                    continue

                if shape.has_table and ("row_index" not in block or "col_index" not in block):
                    continue

                # --------------------------------------------------
                # 1️⃣ NORMAL TEXT SHAPES
                # --------------------------------------------------
                if shape.has_text_frame:
                    para_idx = block.get("paragraph_index", 0)

                    if para_idx >= len(shape.text_frame.paragraphs):
                        continue

                    paragraph = shape.text_frame.paragraphs[para_idx]
                    self.replace_text_preserve_structure(paragraph, new_text)

                # --------------------------------------------------
                # 2️⃣ TABLE CELLS
                # --------------------------------------------------
                elif shape.has_table:
                    row_idx = block.get("row_index")
                    col_idx = block.get("col_index")
                    para_idx = block.get("paragraph_index", 0)

                    if row_idx is None or col_idx is None:
                        continue

                    table = shape.table

                    if row_idx >= len(table.rows):
                        continue
                    if col_idx >= len(table.columns):
                        continue

                    cell = table.cell(row_idx, col_idx)
                    paragraphs = cell.text_frame.paragraphs

                    if para_idx >= len(paragraphs):
                        continue

                    paragraph = paragraphs[para_idx]
                    self.replace_text_preserve_structure(paragraph, new_text)

    def merge_blocks(self, original: List[Dict], updated: List[Dict]) -> List[Dict]:
        """
        Merge updated blocks into original blocks by identity.
        Preserves all unmodified blocks and overwrites only the ones
        returned by the LLM.
        """
        index = {}

        def key(b):
            return (
                b.get("slide_index"),
                b.get("shape_id"),
                b.get("row_index"),
                b.get("col_index"),
                b.get("paragraph_index"),
            )

        for b in original:
            index[key(b)] = b

        for b in updated:
            index[key(b)] = b  # overwrite only blocks returned by LLM

        return list(index.values())



    def _filter_blocks_by_slides(self,blocks: List[Dict],slides: Optional[List[int]]):
        """
        Returns (target_blocks, untouched_blocks)
        slides: None => all blocks
        """
        # print(slides)
        if slides is None:
            return blocks, []

        target = []
        untouched = []

        for b in blocks:
            if b.get("slide_index") in slides:
                target.append(b)
            else:
                untouched.append(b)

        return target, untouched
    

    # ---------------------------
    # NOTES / COMMENTS
    # ---------------------------
    def delete_notes(self, prs: Presentation) -> int:
        removed = 0
        for slide in prs.slides:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text:
                slide.notes_slide.notes_text_frame.clear()
                removed += 1
        return removed

    def delete_comments(self, prs: Presentation) -> int:
        removed = 0
        for slide in prs.slides:
            try:
                rels_to_remove = [
                    (rId, rel)
                    for rId, rel in slide.part.rels.items()
                    if "comments" in rel.target_ref
                ]
                if rels_to_remove:
                    removed += 1

                for rId, rel in rels_to_remove:
                    comment_part = rel._target
                    slide.part.drop_rel(rId)
                    try:
                        comment_part.package.drop_part(comment_part)
                    except Exception:
                        logger.warning(f"Could not drop comment part {comment_part.partname}")
            except Exception as e:
                logger.warning(f"Failed to remove comments on slide {slide.slide_id}: {e}")
        return removed
        
    # HYPERLINK REMOVAL
    def cut_hyperlinks(self, prs: Presentation):
        removed_count = 0
        def remove_hyperlinks_from_shape(shape):
            nonlocal removed_count
            if shape.shape_type != MSO_SHAPE_TYPE.GROUP:
                if hasattr(shape, "click_action") and hasattr(shape.click_action, "hyperlink"):
                    if shape.click_action.hyperlink is not None:
                        shape.click_action.hyperlink.address = None
                        removed_count += 1

            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if hasattr(run, "hyperlink") and run.hyperlink is not None:
                            run.hyperlink.address = None
                            removed_count += 1

            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                for sub_shape in shape.shapes:
                    remove_hyperlinks_from_shape(sub_shape)

        for slide in prs.slides:
            for shape in slide.shapes:
                remove_hyperlinks_from_shape(shape)

        self.sanitization_stats["hyperlinks_removed"] = removed_count


    # ---------------------------
    # LOGO DETECTION / REMOVAL
    # ---------------------------
    def is_logo_image(self, image_bytes: bytes, mime_type: str) -> bool:
        if mime_type not in self.SUPPORTED_MIME_TYPES:
            return False

        img_hash = hashlib.sha256(image_bytes).hexdigest()
        if img_hash in self.LOGO_CACHE:
            return self.LOGO_CACHE[img_hash]

        if not mime_type.startswith("image/"):
            self.LOGO_CACHE[img_hash] = False
            return False

        b64 = base64.b64encode(image_bytes).decode("utf-8")

        prompt = """
                You are an image classifier.

                Task:
                Determine if this image is a COMPANY or BRAND LOGO.

                Rules:
                - Logos are brand marks or wordmarks
                - Photos, charts, screenshots are NOT logos
                - Return ONLY valid JSON

                Output:
                {"is_logo": true | false}
                """

        response = self.vision_llm.with_structured_output(
            schema=LogoDetectionResult
        ).invoke([
            HumanMessage(content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{mime_type};base64,{b64}"
                    }
                }
            ])
        ])

        self.LOGO_CACHE[img_hash] = response.is_logo
        return response.is_logo

    def _remove_logo_pics_from_part(self, container_element, part):
        pics = container_element.xpath(".//*[local-name()='pic']")
        removed_rids = set()

        for pic in pics:
            blips = pic.xpath(".//*[local-name()='blip']")
            if not blips:
                continue

            rId = blips[0].get(
                "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
            )
            if not rId:
                continue

            rel = part.rels.get(rId)
            if not rel:
                continue

            image_bytes = rel.target_part.blob
            mime_type = rel.target_part.content_type

            if self.is_logo_image(image_bytes, mime_type):
                parent = pic.getparent()
                if parent is not None:
                    parent.remove(pic)
                    removed_rids.add(rId)
                    self.sanitization_stats["logos_removed"] += 1

        for rId in removed_rids:
            try:
                part.drop_rel(rId)
            except KeyError:
                pass

    def remove_logo_images(self, prs: Presentation):
        # Slides
        for slide in prs.slides:
            spTree = slide._element.xpath(".//*[local-name()='spTree']")[0]
            self._remove_logo_pics_from_part(spTree, slide.part)
            slide.shapes._spTree = spTree

        # Layouts
        for layout in prs.slide_layouts:
            spTree = layout._element.xpath(".//*[local-name()='spTree']")[0]
            self._remove_logo_pics_from_part(spTree, layout.part)
            layout.shapes._spTree = spTree

        # Masters
        for master in prs.slide_masters:
            spTree = master._element.xpath(".//*[local-name()='spTree']")[0]
            self._remove_logo_pics_from_part(spTree, master.part)
            master.shapes._spTree = spTree
    
    # ---------------------------
    # LLM MASKING FUNCTIONS
    # ---------------------------

    def mask_client_name_llm(
        self,
        blocks: List[Dict],
        slides: Optional[List[int]] = None,
        known_clients: Optional[List[str]] = None
    ) -> List[Dict]:

        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)

        # Nothing to process
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(
            schema=SanitizedResponse
        )
        # OPTIONAL CONTEXT INJECTION
        # ----------------------------
        known_clients_section = ""
        if known_clients:
            known_clients_section = f"""
            KNOWN CLIENT NAMES (HIGH CONFIDENCE):
            {json.dumps(known_clients, ensure_ascii=False)}

            INSTRUCTIONS:
            - Prefer masking these exact names when they appear
            - Replace the detected client organization name with "[CLIENT]".
            - Replace detected client product names with "[PRODUCT]".
            - Do NOT invent new client names
            - Do NOT mask competitors as clients
            """   
        response = structured_llm.invoke([
            # HumanMessage(content=known_clients_section + MASK_CLIENT_PROMPT),
            HumanMessage(content=known_clients_section),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])
        TOKEN = "[CLIENT]"
        count = sum(b.text.count(TOKEN) for b in response.blocks)
        self.sanitization_stats["client_name_replacements"] += count

        return untouched_blocks + [b.model_dump() for b in response.blocks]


    def mask_person_info_llm(self, blocks: List[Dict],slides: Optional[List[int]] = None) -> List[Dict]:
        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_PERSON_PROMPT),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])

        PERSON_TOKENS = ["[PERSON]", "[EMAIL]", "[PHONE]", "[ADDRESS]", "[VENDOR]",
            "[CLIENT SLOGAN]", "[CLIENT WEBSITE]", "[NAME]", "[TITLE]",
            "[CONTACT]", "[CLIENT EMPLOYEE]", "[CLIENT FUND]", "[CLIENT TRUST]",
            "[CLIENT SYSTEM]", "[CLIENT PROJECT]", "[CLIENT DESCRIPTION]",
            "[CLIENT SUBSIDIARY]", "[CLIENT ID]", "[CLIENT LIST]",
            "[CLIENT PARENT]", "[CLIENT DEPARTMENT]"
        ]

        count = sum(
            sum(block.text.count(token) for token in PERSON_TOKENS)
            for block in response.blocks
        )

        self.sanitization_stats["person_names_removed"] += count

        return untouched_blocks + [b.model_dump() for b in response.blocks]


    def mask_competitor_product_name_llm(
        self,
        blocks: List[Dict],
        slides: Optional[List[int]] = None,
        known_competitors: Optional[List[str]] = None
    ) -> List[Dict]:

        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(
            schema=SanitizedResponse
        )

        # ----------------------------
        # 🔹 OPTIONAL CONTEXT INJECTION
        # ----------------------------
        known_competitors_section = ""
        if known_competitors:
            known_competitors_section = f"""
            KNOWN COMPETITOR / PRODUCT / AUDITOR NAMES (HIGH CONFIDENCE):
            {json.dumps(known_competitors, ensure_ascii=False)}

            INSTRUCTIONS:
            - Prefer masking these names when found
            - Replace product names belonging to these competitors with "[PRODUCT]".
            - Replace detected competitor names with "[COMPETITOR]".
            - Replace Auditor / consulting firm names (full name or abbreviation)e.g., Deloitte, Deloitte LLP, EY, Ernst & Young, KPMG, KPMG LLP, Accenture, BCG, Bain, McKinsey → [AUDITOR]
            - Do NOT mask client names as competitors
            - Do NOT invent competitors
            """

        response = structured_llm.invoke([
            HumanMessage(content=known_competitors_section + MASK_COMPETITOR_PROMPT),
            # HumanMessage(content=known_competitors_section),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])

        COMPETITOR_TOKENS = ["[COMPETITOR]", "[PRODUCT]", "[AUDITOR]"]
        count = sum(
            block.text.count(token)
            for block in response.blocks
            for token in COMPETITOR_TOKENS
        )

        self.sanitization_stats["competitor_sanitized"] += count

        return untouched_blocks + [b.model_dump() for b in response.blocks]


    def mask_client_specific_data_llm(self, blocks: List[Dict],slides: Optional[List[int]] = None) -> List[Dict]:
        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_CLIENT_DATA_PROMPT),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])

        count = sum((b.numeric_masks or 0) for b in response.blocks)
        self.sanitization_stats["numeric_data_redacted"] += count
        self.numeric_data_redacted = self.sanitization_stats["numeric_data_redacted"]
        print("Numeric Data Redacted:",self.numeric_data_redacted)
        return untouched_blocks + [b.model_dump() for b in response.blocks]


    def mask_client_location_llm(self, blocks: List[Dict],slides: Optional[List[int]] = None) -> List[Dict]:
        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_LOCATION_PROMPT),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])

        LOCATION_TOKEN = "[LOCATION]"
        count = sum(block.text.count(LOCATION_TOKEN) for block in response.blocks)
        self.sanitization_stats["locations_redacted"] += count

        return untouched_blocks + [b.model_dump() for b in response.blocks]

    def mask_client_bus_llm(self, blocks: List[Dict],slides: Optional[List[int]] = None) -> List[Dict]:
        target_blocks, untouched_blocks = self._filter_blocks_by_slides(blocks, slides)
        if not target_blocks:
            return blocks

        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        response = structured_llm.invoke([
            HumanMessage(content=MASK_BU_PROMPT),
            HumanMessage(content=json.dumps(target_blocks, ensure_ascii=False))
        ])

        BU_TOKEN = "[BU]"
        count = sum(block.text.count(BU_TOKEN) for block in response.blocks)
        self.sanitization_stats["business_units"] += count

        return untouched_blocks + [b.model_dump() for b in response.blocks]

    def correct_grammar_llm(self, blocks: List[Dict]) -> List[Dict]:
        structured_llm = self.text_llm.with_structured_output(schema=SanitizedResponse)
        
        GRAMMAR_PROMPT = "Please correct the grammar in the following text. Keep original meaning and structure."
        response = structured_llm.invoke([
            HumanMessage(content=GRAMMAR_PROMPT),
            HumanMessage(content=json.dumps(blocks, ensure_ascii=False))
        ])
        
        if not isinstance(response, SanitizedResponse):
            raise RuntimeError(f"Unexpected structured response: {type(response)}")

        self.sanitization_stats["grammar_corrected"] = len(response.blocks)
        return [block.model_dump() for block in response.blocks]


    # ---------------------------
    # MAIN SANITIZATION WORKFLOW
    # ---------------------------
    def sanitize_presentation(self, input_file, output_path=None) -> BytesIO:
        # Temp input
        if isinstance(input_file, str):
            input_path = input_file
        else:
            tmp_input = tempfile.NamedTemporaryFile(delete=False, suffix=".pptx")
            tmp_input.write(input_file.read())
            tmp_input.close()
            input_path = tmp_input.name

        # Temp output
        if output_path is None:
            tmp_output = tempfile.NamedTemporaryFile(delete=False, suffix=".pptx")
            tmp_output.close()
            output_path = tmp_output.name

        prs = Presentation(input_path)
        blocks = self.extract_text_blocks(input_path)

        # --- Apply LLM masking ---
        if self.options.get("names"):
            blocks = self.mask_client_name_llm(blocks)
        if self.options.get("personal_info"):
            blocks = self.mask_person_info_llm(blocks)
        if self.options.get("competitor"):
            blocks = self.mask_competitor_product_name_llm(blocks)
        if self.options.get("locations"):
            blocks = self.mask_client_location_llm(blocks)
        if self.options.get("business_units"):
            blocks = self.mask_client_bus_llm(blocks)
        if self.options.get("numeric_data"):
            blocks = self.mask_client_specific_data_llm(blocks)

        # --- Other sanitizations ---
        if self.options.get("logos"):
            self.remove_logo_images(prs)
        if self.options.get("metadata"):
            notes_removed = self.delete_notes(prs)
            comments_removed = self.delete_comments(prs)
            self.sanitization_stats["notes_removed"] = notes_removed
            self.sanitization_stats["comments_removed"] = comments_removed

        if self.options.get("hyperlinks"):
            self.cut_hyperlinks(prs)

        # Apply sanitized text
        self.apply_sanitized_text(prs, blocks)
        
        # Save PPT
        prs.save(output_path)

        # Read into BytesIO
        with open(output_path, "rb") as f:
            sanitized_bytes = BytesIO(f.read())
            sanitized_bytes.seek(0)

        # Cleanup temp files
        if not isinstance(input_file, str):
            os.unlink(input_path)
        if output_path and ("tmp_output" in locals()):
            os.unlink(output_path)

        return sanitized_bytes

    # Get stats
    def get_stats(self):
        return dict(self.sanitization_stats)

# ===========================
# LANGGRAPH NODES
# ===========================

@timed_node("load")
def load_node(state: PPTGraphState):

    state["client_identifiers"] = normalize_client_identifiers(
        state.get("client_identifiers")
    )

    state["sanitizer"] = PPTSanitizer(
        text_llm=TEXT_LLM,
        vision_llm=VISION_LLM,
        options=state.get("options", {})
    )

    state["sanitizer"].sanitization_stats = state["stats"]
    state["prs"] = Presentation(state["input_path"])
    state["blocks"] = state["sanitizer"].extract_text_blocks(state["input_path"])

    state["progress_current"] = 1
    state["progress_total"] = 13
    return state


@timed_node("extract_entities")
# def extract_entities_node(state: PPTGraphState):
#     sanitizer = state["sanitizer"]
#     blocks = state["blocks"]

#     # 1️⃣ Extract from PPT
#     details = sanitizer.extract_client_and_competitors_llm(blocks)
#     logger.info(
#     f"[ENTITIES][DEBUG] "
#     f"(client_identifiers){state.get('client_identifiers')}"
# )

#     # 2️⃣ Merge UI hints
#     ui_identifiers = state.get("client_identifiers") or {}

#     # # 🔒 Normalize client_identifiers
#     # if isinstance(ui_identifiers, str):
#     #     try:
#     #         ui_identifiers = json.loads(ui_identifiers)
#     #     except Exception:
#     #         logger.warning(
#     #             f"[ENTITIES] client_identifiers is string but not JSON: {ui_identifiers}"
#     #         )
#     #         ui_identifiers = {}

#     # if not isinstance(ui_identifiers, dict):
#     #     logger.warning(
#     #         f"[ENTITIES] client_identifiers has invalid type: {type(ui_identifiers)}"
#     #     )
#     #     ui_identifiers = {}

#     ui_clients = ui_identifiers.get("client_names", [])


#     merged_clients = set(details.client_names or [])
#     merged_clients.update(ui_clients)

#     state["extracted_entities"] = ClientCompetitorDetails(
#         client_names=list(merged_clients),
#         competitor_names=details.competitor_names
#     )

#     logger.info(
#         f"[ENTITIES] Clients={list(merged_clients)} | "
#         f"Competitors={details.competitor_names}"
#     )

#     state["progress_current"] += 1
#     return state

@timed_node("extract_entities")
def extract_entities_node(state: PPTGraphState):
    sanitizer = state["sanitizer"]
    blocks = state["blocks"]

    # 1️⃣ LLM extraction
    details = sanitizer.extract_client_and_competitors_llm(blocks)

    # 2️⃣ UI hints (already normalized)
    ui_clients = (
        state.get("client_identifiers", {})
        .get("client_names", [])
    )

    # 3️⃣ Merge (UI has priority)
    merged_clients = set(details.client_names or [])
    merged_clients.update(ui_clients)

    state["extracted_entities"] = ClientCompetitorDetails(
        client_names=sorted(merged_clients),
        competitor_names=details.competitor_names
    )

    logger.info(
        f"[ENTITIES] Clients={sorted(merged_clients)} | "
        f"Competitors={details.competitor_names}"
    )

    state["progress_current"] += 1
    return state

def mask_client_name_node(state: PPTGraphState):
    slides_map = state.get("slides_map", {})
    slides = slides_map.get("names")

    entities = state.get("extracted_entities")
    known_clients = entities.client_names if entities else []

    if state["options"].get("names") and known_clients:

        # 🟥 STEP 1: HARD PRIORITY MASK (deterministic)
        state["blocks"] = state["sanitizer"].force_mask_known_clients(
            state["blocks"],
            known_clients=known_clients,
            slides=slides
        )

        # 🟡 STEP 2: LLM MASK (discovery only)
        new_blocks = state["sanitizer"].mask_client_name_llm(
            state["blocks"],
            slides=slides,
            known_clients=known_clients
        )

        state["blocks"] = state["sanitizer"].merge_blocks(
            state["blocks"], new_blocks
        )

    state["progress_current"] += 1
    return state


def logos_node(state: PPTGraphState):
    if state["options"].get("logos"):
        removed = state["sanitizer"].remove_logo_images(state["prs"]) or 0
        state["stats"]["logos_removed"] += removed

    state["progress_current"] += 1     
    return state


def metadata_node(state: PPTGraphState):
    if state["options"].get("metadata"):
        notes = state["sanitizer"].delete_notes(state["prs"])
        comments = state["sanitizer"].delete_comments(state["prs"])
        state["stats"]["notes_removed"] += notes
        state["stats"]["comments_removed"] += comments

    state["progress_current"] += 1 
    return state


def hyperlinks_node(state: PPTGraphState):
    if state["options"].get("hyperlinks"):
        state["sanitizer"].cut_hyperlinks(state["prs"])
    state["progress_current"] += 1 
    return state


def mask_person_node(state: PPTGraphState):
    slides = state.get("slides_map", {}).get("personal_info") 
    if state["options"].get("personal_info"):
        # Call the LLM masking
        new_blocks = state["sanitizer"].mask_person_info_llm(state["blocks"], slides=slides)
        # Merge updated blocks with existing blocks
        state["blocks"] = state["sanitizer"].merge_blocks(state["blocks"], new_blocks)
    state["progress_current"] += 1 
    return state


def mask_competitor_node(state: PPTGraphState):
    slides = state.get("slides_map", {}).get("competitor")

    entities = state.get("extracted_entities")
    known_competitors = entities.competitor_names if entities else None

    if state["options"].get("competitor"):
        new_blocks = state["sanitizer"].mask_competitor_product_name_llm(
            state["blocks"],
            slides=slides,
            known_competitors=known_competitors   
        )

        state["blocks"] = state["sanitizer"].merge_blocks(
            state["blocks"], new_blocks
        )

    state["progress_current"] += 1
    return state

def mask_numeric_node(state: PPTGraphState):
    slides = state.get("slides_map", {}).get("numeric_data")
    if state["options"].get("numeric_data"):
        new_blocks = state["sanitizer"].mask_client_specific_data_llm(state["blocks"], slides=slides)
        state["blocks"] = state["sanitizer"].merge_blocks(state["blocks"], new_blocks)
    state["progress_current"] += 1 
    return state


def mask_location_node(state: PPTGraphState):
    slides = state.get("slides_map", {}).get("locations")

    if state["options"].get("locations"):
        new_blocks = state["sanitizer"].mask_client_location_llm(state["blocks"], slides=slides)
        state["blocks"] = state["sanitizer"].merge_blocks(state["blocks"], new_blocks)

    state["progress_current"] += 1 
    return state


def mask_bu_node(state: PPTGraphState):
    slides = state.get("slides_map", {}).get("business_units")

    if state["options"].get("business_units"):
        new_blocks = state["sanitizer"].mask_client_bus_llm(state["blocks"], slides=slides)
        state["blocks"] = state["sanitizer"].merge_blocks(state["blocks"], new_blocks)

    state["progress_current"] += 1 
    return state

def grammar_node(state: PPTGraphState):
    new_blocks = state["sanitizer"].correct_grammar_llm(state["blocks"])
    state["blocks"] = state["sanitizer"].merge_blocks(state["blocks"], new_blocks)
    state["progress_current"] += 1 
    return state


def save_node(state: PPTGraphState):
    # -- ADDED TO TRACK SLIDES PROCESSED --
    blocks = state.get("blocks", [])
    unique_slides = {
        block["slide_index"]
        for block in blocks
        if "slide_index" in block
    }
    state["stats"]["slides_processed"] = len(unique_slides)
    state["sanitizer"].apply_sanitized_text(state["prs"], state["blocks"])
    state["prs"].save(state["output_path"])
    state["progress_current"] += 1 
    return state

# LANGGRAPH DEFINITION

graph = StateGraph(PPTGraphState)

graph.add_node("load", load_node)
graph.add_node("extract_entities", extract_entities_node)
# graph.add_node("process_guidelines", process_guidelines_node)
graph.add_node("mask_client", mask_client_name_node)
graph.add_node("logos", logos_node)
graph.add_node("metadata", metadata_node)
graph.add_node("hyperlinks", hyperlinks_node)
graph.add_node("mask_person", mask_person_node)
graph.add_node("mask_competitor", mask_competitor_node)
graph.add_node("mask_numeric", mask_numeric_node)
graph.add_node("mask_location", mask_location_node)
graph.add_node("mask_bu", mask_bu_node)
graph.add_node("grammar", grammar_node)
graph.add_node("save", save_node)

graph.set_entry_point("load")

graph.add_edge("load", "extract_entities")
# graph.add_edge("extract_entities", "process_guidelines")
graph.add_edge("extract_entities", "mask_client")
# graph.add_edge("process_guidelines", "mask_client")
graph.add_edge("mask_client", "logos")
graph.add_edge("logos", "metadata")
graph.add_edge("metadata", "hyperlinks")
graph.add_edge("hyperlinks", "mask_person")
graph.add_edge("mask_person", "mask_competitor")
graph.add_edge("mask_competitor", "mask_numeric")
graph.add_edge("mask_numeric","mask_location")
graph.add_edge("mask_location", "mask_bu")
graph.add_edge("mask_bu", "grammar")
graph.add_edge("grammar", "save")
graph.add_edge("save", END)

ppt_graph = graph.compile()


