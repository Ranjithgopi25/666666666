from app.infrastructure.llm.base_services import BasePPTWorkflowService
from app.features.ddc.services import PPTSanitizer
from typing import List,Dict,Any, Optional
from io import BytesIO
import logging

logger = logging.getLogger(__name__)

def map_services_to_options(selected_services: List[str]) -> Dict[str, Any]:
    """Map frontend service IDs to PPTSanitizer options.Frontend Services:
    - convert_template: Convert to PwC template
    - crop_thumbnails: Crop identifying information from thumbnails
    - replace_client: Replace client names/logos
    - delete_notes: Delete notes/comments
    - anonymize_products: Anonymize product names
    - cut_hyperlinks: Cut hyperlinks
    - mask_leadership: Mask leadership/employee names
    - paste_as_pictures: Paste charts as pictures
    - change_competitors: Change competitor names/logos/products
    - remove_data: Remove client-specific data (financials, FTEs, metrics)
    - conceal_regions: Conceal client-identifying regions/locations
    - disguise_bus: Disguise client-identifying business units
    """
    
    options = {
        "numeric_data": False,
        "personal_info": False,
        "financial_data": False,
        "locations": False,
        "identifiers": False,
        "names": False,
        "logos": False,
        "metadata": False,  # Always remove metadata
        "llm_detection": False,
        "hyperlinks": False,
        "business_units": False,
        "embedded_objects": False,
        "competitor":False,
        "convert_charts_to_images": False,  # Convert charts/graphs to static images
    }
    
    # Map services to options
    service_mapping = {
        "replace_client": ["names", "logos"],
        "delete_notes": ["metadata"],  # Handled separately via notes removal
        # "anonymize_products": ["names"],
        "cut_hyperlinks": ["hyperlinks"],
        "mask_leadership": ["names", "personal_info"],
        "paste_as_pictures": ["convert_charts_to_images"],  # Convert charts/graphs to images
        "change_competitors": ["competitor","logo"],
        "remove_data": ["numeric_data", "financial_data", "identifiers"],  # Include names for client data
        "conceal_regions": ["locations"],
        "disguise_bus": ["business_units"],  # 👈 semantic intent
    }
    
    # Enable LLM detection if we have name-based services for better accuracy
    name_services = ["replace_client", "mask_leadership", 
                    "change_competitors", "disguise_bus"]
    if any(svc in selected_services for svc in name_services):
        options["llm_detection"] = True
    
    # Apply mappings
    for service_id in selected_services:
        if service_id in service_mapping:
            for option in service_mapping[service_id]:
                options[option] = True
    
    logger.info(f"[ServiceMapper] Mapped {len(selected_services)} services to options: {options}")
    
    return options


class SanitizationService(BasePPTWorkflowService):
    
    """Service for Presentation Sanitization workflow"""
    
    async def sanitize_presentation(
        self, 
        ppt_bytes: bytes, 
        filename: str,
        selected_services: List[str],
        client_identifiers: str,
        template: str = "core",
        template_bytes: Optional[bytes] = None,
        llm_service=None,
        additional_guidelines: Optional[str] = None
    ) -> tuple[bytes, dict]:
        """
        Sanitize PowerPoint presentation based on selected services.
        
        Returns:
            tuple: (sanitized_ppt_bytes, sanitization_plan)
        """
        logger.info(f"[Sanitization] Processing {filename} with {len(selected_services)} services")
        logger.info(f"[Sanitization] Template: {template}, Has custom template: {template_bytes is not None}")
        
        # Map frontend services to sanitizer options
        options = map_services_to_options(selected_services)
        
        # Parse client identifiers (comma-separated)
        client_names = []
        product_names = []
        business_units = []
        competitor_names = []
        
        if client_identifiers:
            identifiers = [name.strip() for name in client_identifiers.split(',') if name.strip()]

            if identifiers:
                client_names = [identifiers[0]]

            if len(identifiers) > 1:
                product_names = identifiers[1:]
                business_units = identifiers[1:]
                
        # Initialize sanitizer
        sanitizer = PPTSanitizer(
            client_names=client_names,
            product_names=product_names,
            business_units=business_units,
            competitor_names=competitor_names,
            options=options
        )
        
        # Always enable grammar/spell check during sanitization
        fix_grammar = True  # Grammar checking is now automatic for all sanitizations

        # Add additional guidelines to sanitizer if provided
        if additional_guidelines:
            logger.info(f"[Sanitization] Additional Guidelines received: {additional_guidelines}")
            sanitizer.additional_guidelines = additional_guidelines

        
        # Perform sanitization with centralized LLM service for intelligent detection
        sanitized_output = await sanitizer.sanitize_presentation(
            BytesIO(ppt_bytes),
            client_name=client_names[0] if client_names else None,
            fix_grammar=fix_grammar,  # Enable grammar check if requested
            llm_service=llm_service  # Pass centralized LLM service for detection and grammar fixing
        )
        
        # Get sanitization statistics
        stats = sanitizer.get_stats()
        
        # Build sanitization plan (line-by-line format)
        plan = self._build_sanitization_plan(selected_services, stats, template)
        
        # Read sanitized bytes
        sanitized_bytes = sanitized_output.read()
        
        logger.info(f"[Sanitization] Complete. Processed {stats['slides_processed']} slides")
        
        return sanitized_bytes, plan
    
    def _build_sanitization_plan(self, selected_services: List[str], stats: dict, template: str = "core") -> dict:
        """Build a clean line-by-line sanitization plan."""
        
        service_labels = {
            # "convert_template": "Convert to PwC Standard Template",
            # "crop_thumbnails": "Crop Identifying Information from Thumbnails",
            "replace_client": "Replace Client Names and Logos",
            "delete_notes": "Delete Notes/Comments",
            # "anonymize_products": "Anonymize Product Names",
            "cut_hyperlinks": "Cut Hyperlinks",
            "mask_leadership": "Mask Leadership/Employee Names",
            # "paste_as_pictures": "Paste Charts/Graphs as Pictures",
            "change_competitors": "Change Competitor Names/Logos",
            "remove_data": "Remove Client-specific Data",
            "conceal_regions": "Conceal Client-identifying Regions",
            "disguise_bus": "Disguise Business Units"
        }
        
        # Services not yet implemented - exclude from plan
        placeholder_services = {"convert_template", "crop_thumbnails", "paste_as_pictures"}
        
        plan_items = []
        
        for service_id in selected_services:
            # Skip placeholder services from the plan display
            if service_id in placeholder_services:
                logger.info(f"[SanitizationPlan] Skipping placeholder service: {service_id}")
                continue
                
            label = service_labels.get(service_id, service_id)
            details = self._get_service_details(service_id, stats, template)
            
            plan_items.append({
                "service_id": service_id,
                "label": label,
                "status": "completed",
                "details": details
            })
        
        return {
            "items": plan_items,
            "summary": {
                "slides_processed": stats.get("slides_processed", 0),
                "total_changes": (
                    stats.get("numeric_replacements", 0) +
                    stats.get("name_replacements", 0) +
                    stats.get("hyperlinks_removed", 0) +
                    stats.get("notes_removed", 0) +
                    stats.get("logos_removed", 0)
                )
            }
        }
    
    def _get_service_details(self, service_id: str, stats: dict, template: str = "core") -> str:
        """Get details for a specific service based on stats."""
        
        details_map = {
            "replace_client": f"{stats.get('name_replacements', 0)} references replaced, {stats.get('logos_removed', 0)} logos removed",
            "delete_notes": f"{stats.get('notes_removed', 0)} slide notes removed",
            # "anonymize_products": f"{stats.get('name_replacements', 0)} product names anonymized",
            "cut_hyperlinks": f"{stats.get('hyperlinks_removed', 0)} hyperlinks removed",
            "mask_leadership": f"{stats.get('person_names_removed', 0)} person names masked",
            "remove_data": f"{stats.get('numeric_replacements', 0)} numeric values sanitized",
            "conceal_regions": f"{stats.get('locations_redacted', 0)} locations redacted",
            "disguise_bus": f"{stats.get('business_units_disguised', 0)} business units disguised",
            "convert_template": f"Converted to {template.capitalize()} template",
            "crop_thumbnails": f"Processed {stats.get('slides_processed', 0)} slide thumbnails",
            "paste_as_pictures": f"Processed charts on {stats.get('slides_processed', 0)} slides",
            "change_competitors": f"{stats.get('name_replacements', 0)} competitor references changed"
        }
        
        return details_map.get(service_id, "Applied successfully")
    
    async def execute(self, *args, **kwargs):
        """Execute sanitization"""
        return await self.sanitize_presentation(*args, **kwargs)
