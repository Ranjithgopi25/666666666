from fastapi import APIRouter, Depends
from app.features.ddc.workflows import (
    sanitization,
    slide_creation,
    ddc_chat_agent,
    phoenix

)
from app.services.auth_service import validate_jwt_token

def get_router() -> APIRouter:
    """Create and configure DDC router with all workflow sub-routers"""
    router = APIRouter(prefix="/ddc", tags=["DDC"], dependencies=[Depends(validate_jwt_token)])
    router.include_router(sanitization.router, prefix="/sanitization", tags=["DDC - Sanitization"])
    router.include_router(slide_creation.router, prefix="/slide-creation", tags=["DDC - Slide Creation"])
    router.include_router(ddc_chat_agent.router, prefix="/ddc_chat_agent", tags=["DDC - Chat Agent"])
    router.include_router(phoenix.router, prefix="/phoenix", tags=["DDC - Phoenix request"])

    return router
