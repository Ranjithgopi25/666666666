"""
PowerPoint Generation Service.
Handles PPT creation via PlusDocs API with async polling.
"""

import logging
import asyncio
import requests
import json
from typing import Dict, Any, Optional
from app.core.config import get_settings
settings = get_settings()


logger = logging.getLogger(__name__)


class PlusDocsClient:
    """Client for interacting with PlusDocs API"""

    def __init__(self, api_token: str):
        """
        Initialize the PlusDocs client
        Args:
            api_token: Bearer token for API authentication
        """

        self.api_token = api_token
        self.api_token = api_token or settings.PLUSDOCS_API_TOKEN
        self.base_url = settings.PLUSDOC_BASE_URL
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_token}"
        }

    def create_presentation(self, prompt: str, template_id: str, isImage: bool) -> Optional[str]:
        """
        Create a new presentation
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
            isImage: Whether to generate image-based slides
        Returns:
            Presentation ID if successful, None otherwise
        """
        print('came inside the create ppt')
        url = f"{self.base_url}/presentation"
        payload = {}

        if isImage:
            payload = {
                "prompt": prompt,
                "templateId": template_id,
                "numberOfSlides": 1
            }
        else:
            payload = {
                "prompt": prompt,
                "templateId": template_id
            }
        print(f'data')
        try:
            logger.info(f"[PlusDocs] Creating presentation with prompt: '{prompt[:100]}...'")
            logger.info(f"[PlusDocs] Using template ID: {template_id}")
            
            response = requests.post(url, headers=self.headers, json=payload, timeout=30)
            response.raise_for_status()

            data = response.json()
            presentation_id = data.get('id')

            if presentation_id:
                logger.info(f"[PlusDocs] ✓ Presentation created successfully! ID: {presentation_id}")
                return presentation_id
            else:
                logger.error("[PlusDocs] ✗ No presentation ID returned in response")
                logger.error(f"[PlusDocs] Response data: {json.dumps(data, indent=2)}")
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"[PlusDocs] ✗ Error creating presentation: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"[PlusDocs] Response status: {e.response.status_code}")
                logger.error(f"[PlusDocs] Response text: {e.response.text}")
            return None

    def get_presentation_status(self, presentation_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the status of a presentation
        Args:
            presentation_id: ID of the presentation to check
        Returns:
            Presentation data if successful, None otherwise
        """
        url = f"{self.base_url}/presentation/{presentation_id}"

        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            logger.error(f"[PlusDocs] ✗ Error getting presentation status: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"[PlusDocs] Response: {e.response.text}")
            return None

    async def poll_until_complete_async(
        self,
        presentation_id: str,
        poll_interval: int = settings.PLUSDOCS_POLL_INTERVAL,
        max_attempts: int = 120
    ) -> Optional[str]:
        """
        Async poll the API until the presentation is complete
        Args:
            presentation_id: ID of the presentation to poll
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 120 = 10 minutes)
        Returns:
            Download URL if successful, None otherwise
        """
        logger.info(f"[PlusDocs] 🔄 Starting async polling for completion (checking every {poll_interval}s, max wait: {max_attempts * poll_interval}s)")
        logger.info(f"[PlusDocs] Presentation ID: {presentation_id}")

        for attempt in range(1, max_attempts + 1):
            logger.info(f"[PlusDocs] 📊 Polling attempt {attempt}/{max_attempts}...")

            # Run the blocking get_presentation_status in thread pool
            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(None, self.get_presentation_status, presentation_id)
            
            if data is None:
                logger.warning(f"[PlusDocs] ⚠️  Failed to get status on attempt {attempt}")
                await asyncio.sleep(poll_interval)
                continue

            status = data.get('status', 'unknown')
            logger.info(f"[PlusDocs] Current status: {status}")

            # Check if completed successfully
            if status == 'GENERATED' or status == 'success':
                download_url = (
                    data.get('downloadUrl')
                    or data.get('download_url')
                    or data.get('url')
                )
                if download_url:
                    logger.info(f"[PlusDocs] ✅ Presentation completed successfully!")
                    logger.info(f"[PlusDocs] Download URL: {download_url}")
                    return download_url
                else:
                    logger.error(f"[PlusDocs] ✗ Presentation status is '{status}' but no download URL found")
                    logger.error(f"[PlusDocs] Full response: {json.dumps(data, indent=2)}")
                    return None

            # Check if failed
            if status in ['failed', 'error', 'FAILED', 'ERROR']:
                logger.error(f"[PlusDocs] ❌ Presentation generation failed with status: {status}")
                logger.error(f"[PlusDocs] Response details: {json.dumps(data, indent=2)}")
                return None

            # Still processing - log progress
            elapsed_time = attempt * poll_interval
            remaining_time = (max_attempts - attempt) * poll_interval
            logger.info(f"[PlusDocs] ⏳ Still processing... (elapsed: {elapsed_time}s, remaining: {remaining_time}s)")
            
            await asyncio.sleep(poll_interval)  # Use async sleep

        # Timeout reached
        total_wait_time = max_attempts * poll_interval
        logger.error(f"[PlusDocs] ⏰ Timeout: Presentation did not complete after {max_attempts} attempts ({total_wait_time}s)")
        logger.error(f"[PlusDocs] Presentation ID: {presentation_id}")
        return None

    async def create_and_wait_async(
        self,
        prompt: str,        
        template_id: str,
        isImage: bool,
        poll_interval: int = 5,
        max_attempts: int = 120
    ) -> Optional[str]:
        """
        Create a presentation and wait for it to complete (async version)
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
            isImage: Whether to generate image-based slides
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 120 = 10 minutes)
        Returns:
            Download URL if successful, None otherwise
        """
        logger.info(f"[PlusDocs] 🚀 Starting presentation creation and polling workflow")
        
        # Run the blocking create_presentation in thread pool
        loop = asyncio.get_event_loop()
        presentation_id = await loop.run_in_executor(
            None, 
            self.create_presentation, 
            prompt, 
            template_id, 
            isImage
        )
        
        if not presentation_id:
            logger.error("[PlusDocs] ❌ Failed to create presentation, aborting workflow")
            return None

        logger.info(f"[PlusDocs] ✓ Presentation created, starting polling phase...")
        
        download_url = await self.poll_until_complete_async(
            presentation_id,
            poll_interval,
            max_attempts
        )
        
        if download_url:
            logger.info(f"[PlusDocs] 🎉 Workflow completed successfully!")
        else:
            logger.error(f"[PlusDocs] 💔 Workflow failed - no download URL obtained")
        
        return download_url


class PPTService:
    """Service for generating PowerPoint presentations via PlusDocs API."""
    
    def __init__(
        self, 
        api_token: Optional[str] = None,
        template_id: Optional[str] = None
    ):
        """
        Initialize PPT service with PlusDocs client.
        
        Args:
            api_token: PlusDocs API token
            template_id: Default template ID
        """
        # Import config here to avoid circular imports
        try:
            from .config import PLUSDOCS_CONFIG
            self.api_token = api_token or PLUSDOCS_CONFIG.get("api_token")
            self.template_id = template_id or PLUSDOCS_CONFIG.get("template_id")
        except ImportError:
            logger.warning("[PPTService] Could not import PLUSDOCS_CONFIG")
            self.api_token = api_token
            self.template_id = template_id
        
        if not self.api_token:
            logger.warning("[PPTService] No PlusDocs API token provided")
            self.client = None
        else:
            self.client = PlusDocsClient(self.api_token)
            logger.info("[PPTService] PlusDocs client initialized successfully")
    
    async def generate_presentation(
        self,
        user_query: str,
        additional_guidelines: Optional[str] = None,
        template_id: Optional[str] = None,
        is_image: bool = False
    ) -> Dict[str, Any]:
        """
        Generate a PowerPoint presentation using PlusDocs API.
        
        Args:
            user_query: The user's original request
            additional_guidelines: Enhanced/manipulated query for better results
            template_id: Template ID to use (uses default if not provided)
            is_image: Whether to generate image-based slides
            
        Returns:
            Dict with status and download_url
            
        Raises:
            Exception: If API call fails
        """
        if not self.client:
            logger.error("[PPTService] Cannot generate presentation - PlusDocs API token not configured")
            raise Exception("PlusDocs API token not configured")
        
        try:
            # Use additional_guidelines if provided, otherwise use original query
            prompt = additional_guidelines or user_query
            
            # Use provided template_id or default
            template = template_id or self.template_id
            if not template:
                logger.error("[PPTService] No template ID configured")
                raise Exception("No template ID configured")
            
            logger.info(f"[PPTService] 📝 Starting presentation generation")
            logger.info(f"[PPTService] Prompt: {prompt[:150]}{'...' if len(prompt) > 150 else ''}")
            logger.info(f"[PPTService] Template ID: {template}")
            logger.info(f"[PPTService] Image mode: {is_image}")
            
            # Call create_and_wait_async (now fully async)
            download_url = await self.client.create_and_wait_async(
                prompt=prompt,
                template_id=template,
                isImage=is_image,
                poll_interval=5,
                max_attempts=120  # 10 minutes max
            )
            
            if download_url:
                logger.info(f"[PPTService] ✅ Presentation generated successfully!")
                return {
                    "status": "success",
                    "download_url": download_url
                }
            else:
                logger.error(f"[PPTService] ❌ Presentation generation failed - no URL returned")
                return {
                    "status": "failed",
                    "download_url": None
                }
                
        except Exception as e:
            logger.error(f"[PPTService] 💥 Exception during presentation generation: {e}", exc_info=True)
            raise
    
    @staticmethod
    def format_response(result: Dict[str, Any]) -> str:
        """
        Format the API response into a user-friendly message.
        
        Args:
            result: API response dict with status and download_url
            
        Returns:
            Formatted markdown message
        """
        if result.get("status") == "success" and result.get("download_url"):
            download_url = result["download_url"]
            return f"""### 🎉 Your presentation is ready!

[**Download PowerPoint Presentation**]({download_url})

Click the link above to download your generated presentation."""
        else:
            return "❌ Failed to generate presentation. Please try again or contact support if the issue persists."