"""
CapitalIQ Database Service.
Handles SQL Server connections and queries for financial data.
"""

import logging
from typing import Optional, List, Dict, Any
from concurrent.futures import ThreadPoolExecutor
import asyncio
from app.core.config import get_settings

logger = logging.getLogger(__name__)

# Handle missing pyodbc gracefully
try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    pyodbc = None
    PYODBC_AVAILABLE = False
    logger.warning("[CapitalIQ] pyodbc not installed")

# Import config with error handling
try:
    from .config import SCHEMA_REGISTRY
except ImportError:
    SCHEMA_REGISTRY = {}
class CapitalIQService:
    """Service for querying CapitalIQ SQL Server database."""
    
    TABLE_NAME = "vw_CompanyIncomeStatementFinancials"
    
    # All available columns in the table
    AVAILABLE_COLUMNS = [
        "companyName", "CapIQ_Id", "SEC_CIK", "DUNS", 
        "periodEndDate", "filingDate", "periodTypeName", 
        "calendarYear", "dataItemId", "dataItemName", "dataItemValue"
    ]
    
    # Common data item names
    DATA_ITEMS = [
        "Net Income - (IS)",
        "Total Revenues",
        "Gross Profit",
        "Cost Of Revenues",
        "Depreciation & Amortization, Total - (IS)",
        "Unusual Items, Total"
    ]
    
    def __init__(self):
        self.settings = get_settings()
        self.schema = SCHEMA_REGISTRY.get("capitaliq", {})
        self._connection = None
        self._executor = ThreadPoolExecutor(max_workers=2)
    
    def _get_connection_string(self) -> str:
        """Build SQL Server connection string."""
        return (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={self.settings.SQLSERVER_SERVER};"
            f"DATABASE={self.settings.SQLSERVER_DATABASE};"
            f"UID={self.settings.SQLSERVER_USERNAME};"
            f"PWD={self.settings.SQLSERVER_PASSWORD};"
            f"Encrypt=yes;"
            f"TrustServerCertificate=no;"
            f"Connection Timeout=30;"
        )
    
    def _connect_sync(self) -> bool:
        """Synchronous connection (runs in thread pool)."""
        if not PYODBC_AVAILABLE:
            logger.error("[CapitalIQ] pyodbc not available")
            return False
        
        try:
            if self._connection:
                try:
                    self._connection.cursor().execute("SELECT 1")
                    return True
                except:
                    self._connection = None
            
            self._connection = pyodbc.connect(self._get_connection_string())
            logger.info("[CapitalIQ] Connected to SQL Server")
            return True
        except Exception as e:
            logger.error(f"[CapitalIQ] Connection failed: {e}")
            return False
    
    async def connect(self) -> bool:
        """Async connection wrapper."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self._executor, self._connect_sync)
    
    def _execute_query_sync(self, query: str) -> List[Dict[str, Any]]:
        """Execute query synchronously."""
        if not self._connection:
            raise Exception("Not connected to database")
        
        cursor = self._connection.cursor()
        cursor.execute(query)
        
        columns = [column[0] for column in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))
        
        cursor.close()
        return results
    
    async def execute_query(self, query: str) -> List[Dict[str, Any]]:
        """Execute raw query asynchronously."""
        await self.connect()
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor, 
            self._execute_query_sync, 
            query
        )
    
    async def execute_flexible_query(
        self,
        company_name: Optional[str] = None,
        data_item_name: Optional[str] = None,
        calendar_year: Optional[int] = None,
        period_type: Optional[str] = None,
        custom_where_clause: Optional[str] = None,
        select_columns: Optional[List[str]] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Execute a flexible query with various filter options.
        
        Args:
            company_name: Filter by company name (LIKE match)
            data_item_name: Filter by data item name (LIKE match)
            calendar_year: Filter by calendar year
            period_type: Filter by period type ('Annual' or 'Quarterly')
            custom_where_clause: Additional WHERE conditions
            select_columns: Columns to select (None = all common columns)
            limit: Max rows to return
        """
        await self.connect()
        
        # Build SELECT clause
        if select_columns:
            # Validate columns
            valid_cols = [c for c in select_columns if c in self.AVAILABLE_COLUMNS]
            if not valid_cols:
                valid_cols = self.AVAILABLE_COLUMNS[:6]  # Default subset
            columns_str = ", ".join(valid_cols)
        else:
            columns_str = "companyName, calendarYear, periodTypeName, periodEndDate, dataItemName, dataItemValue"
        
        # Build WHERE clause
        conditions = []
        
        if company_name:
            # Escape single quotes for SQL safety
            safe_name = company_name.replace("'", "''")
            conditions.append(f"companyName LIKE '%{safe_name}%'")
        
        if data_item_name:
            safe_item = data_item_name.replace("'", "''")
            conditions.append(f"dataItemName LIKE '%{safe_item}%'")
        
        if calendar_year:
            conditions.append(f"calendarYear = {calendar_year}")
        
        if period_type:
            safe_period = period_type.replace("'", "''")
            conditions.append(f"periodTypeName = '{safe_period}'")
        
        if custom_where_clause:
            # Basic SQL injection prevention
            if not any(kw in custom_where_clause.upper() for kw in ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'TRUNCATE', '--', ';']):
                conditions.append(f"({custom_where_clause})")
        
        where_clause = " AND ".join(conditions) if conditions else "1=1"
        
        query = f"""
        SELECT TOP {limit}
            {columns_str}
        FROM {self.TABLE_NAME}
        WHERE {where_clause}
        ORDER BY calendarYear DESC, periodEndDate DESC
        """
        
        logger.info(f"[CapitalIQ] Executing query: {query[:200]}...")
        return await self.execute_query(query)
    
    async def get_company_financials(
        self,
        company_name: str,
        metrics: Optional[List[str]] = None,
        year: Optional[int] = None,
        period_type: str = "Annual"
    ) -> List[Dict[str, Any]]:
        """
        Get company financial data - convenience method.
        """
        custom_where = None
        if metrics:
            metrics_str = "', '".join(m.replace("'", "''") for m in metrics)
            custom_where = f"dataItemName IN ('{metrics_str}')"
        
        return await self.execute_flexible_query(
            company_name=company_name,
            calendar_year=year,
            period_type=period_type,
            custom_where_clause=custom_where,
            limit=100
        )
    async def execute_flexible_balance_sheet_query(
        self,
        company_name: Optional[str] = None,
        data_item_name: Optional[str] = None,
        calendar_year: Optional[int] = None,
        custom_where_clause: Optional[str] = None,
        select_columns: Optional[List[str]] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Execute a flexible query on balance sheet data.
        
        Args:
            company_name: Filter by company name (LIKE match)
            data_item_name: Filter by data item name (LIKE match)
            calendar_year: Filter by calendar year
            custom_where_clause: Additional WHERE conditions
            select_columns: Columns to select (None = default subset)
            limit: Max rows to return
        """
        await self.connect()
        
        # Build SELECT clause
        if select_columns:
            valid_cols = [c for c in select_columns if c in self.AVAILABLE_COLUMNS]
            if not valid_cols:
                valid_cols = self.AVAILABLE_COLUMNS[:6]
            columns_str = ", ".join(valid_cols)
        else:
            columns_str = "companyName, calendarYear, periodTypeName, periodEndDate, dataItemName, dataItemValue"
        
        # Build WHERE clause
        conditions = []
        
        if company_name:
            safe_name = company_name.replace("'", "''")
            conditions.append(f"companyName LIKE '%{safe_name}%'")
        
        if data_item_name:
            safe_item = data_item_name.replace("'", "''")
            conditions.append(f"dataItemName LIKE '%{safe_item}%'")
        
        if calendar_year:
            conditions.append(f"calendarYear = {calendar_year}")
        
        # Balance sheet is typically Annual only
        conditions.append("periodTypeName = 'Annual'")
        
        if custom_where_clause:
            if not any(kw in custom_where_clause.upper() for kw in ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'TRUNCATE', '--', ';']):
                conditions.append(f"({custom_where_clause})")
        
        where_clause = " AND ".join(conditions) if conditions else "1=1"
        
        query = f"""
        SELECT TOP {limit}
            {columns_str}
        FROM vw_CompanyBalanceSheetFinancials
        WHERE {where_clause}
        ORDER BY calendarYear DESC, periodEndDate DESC
        """
        
        logger.info(f"[CapitalIQ] Executing balance sheet query: {query[:200]}...")
        return await self.execute_query(query)
    
    async def get_company_balance_sheet(
        self,
        company_name: str,
        metrics: Optional[List[str]] = None,
        year: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get company balance sheet data - convenience method.
        
        Args:
            company_name: Name of the company
            metrics: List of balance sheet metrics to retrieve
            year: Calendar year (optional)
        """
        custom_where = None
        if metrics:
            metrics_str = "', '".join(m.replace("'", "''") for m in metrics)
            custom_where = f"dataItemName IN ('{metrics_str}')"
        
        return await self.execute_flexible_balance_sheet_query(
            company_name=company_name,
            calendar_year=year,
            custom_where_clause=custom_where,
            limit=100
        )
    @staticmethod
    def format_response(results: List[Dict[str, Any]]) -> str:
        """Format query results into readable context."""
        if not results:
            return "No financial data found for the specified criteria."
        
        context_parts = ["### Financial Data from CapitalIQ:\n"]
        
        # Group by company
        companies = {}
        for row in results:
            company = row.get("companyName", "Unknown")
            if company not in companies:
                companies[company] = []
            companies[company].append(row)
        
        for company, rows in companies.items():
            context_parts.append(f"**{company}**\n")
            
            for row in rows[:15]:  # Limit rows per company
                year = row.get("calendarYear", "N/A")
                period = row.get("periodTypeName", "")
                metric = row.get("dataItemName", "")
                value = row.get("dataItemValue", 0)
                
                # Format large numbers
                if isinstance(value, (int, float)) and value:
                    if abs(value) >= 1000000000:
                        formatted_value = f"${value/1000000000:.2f}B"
                    elif abs(value) >= 1000000:
                        formatted_value = f"${value/1000000:.2f}M"
                    elif abs(value) >= 1000:
                        formatted_value = f"${value/1000:.2f}K"
                    else:
                        formatted_value = f"${value:,.2f}"
                else:
                    formatted_value = str(value) if value else "N/A"
                
                context_parts.append(f"- {metric} ({year} {period}): {formatted_value}")
            
            context_parts.append("")
        
        return "\n".join(context_parts)
    
    def close(self):
        """Close database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None
            logger.info("[CapitalIQ] Connection closed")