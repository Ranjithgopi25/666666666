"""
Chat History Router.
Handles chat history endpoints for retrieving session summaries, full conversations,
and managing chat sessions. Database-driven approach with lazy loading.

Combines endpoints from both v1/chat_history.py and api/routers/chat_history_router.py
"""
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import datetime
import logging

from app.services.chat_history_service import ChatHistoryService
from app.core.deps import get_chat_history_service
from .schemas import (
    CreateSessionRequest,
    AddMessageRequest,
    SessionResponse,
    SessionSummary,
    MessageResponse
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat-history", tags=["chat-history"])


# === SESSION CREATION AND LISTING ===

@router.post("/sessions", response_model=SessionResponse, status_code=201)
async def create_chat_session(
    request: CreateSessionRequest,
    user_id: str = Query(..., description="User identifier (email)"),
    session_id: str = Query(..., description="Session identifier"),
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    Create a new chat session.
    
    Args:
        request: Session creation request
        user_id: User email/identifier
        session_id: Session identifier (simple string)
        chat_service: Chat history service dependency
        
    Returns:
        Created session data
    """
    try:
        # Convert user_id email to UUID using uuid5
        user_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, user_id)
        
        result = chat_service.create_new_chat_session(
            user_id=user_uuid,
            session_id=session_id,
            source=request.source,
            initial_content=request.initial_message,
            user_email=user_id,
            title=request.title
        )
        
        return SessionResponse(**result)
        
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating chat session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create chat session: {str(e)}")


@router.get("/sessions", response_model=List[SessionSummary])
async def list_user_sessions(
    user_id: str = Query(..., description="User identifier (email)"),
    source: Optional[str] = Query(None, description="Filter by source (Chat, DDDC, Thought_Leadership, Market_Intelligence, Export)"),
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    List all chat sessions for a user.
    
    Returns list of session summaries with:
    - session_id
    - title
    - preview (first 100 chars)
    - message_count
    - source
    - created_at
    - updated_at
    
    Args:
        user_id: User email or identifier
        source: Optional source filter (Chat, DDDC, Thought_Leadership, Market_Intelligence, Export)
    
    Returns:
        List of session summaries
    """
    try:
        logger.info(f"[Chat History] Listing sessions for user email: '{user_id}'")
        
        # Pass the email directly to the service - it will look up the UUID from Users table
        all_sessions = chat_service.list_user_sessions_by_email(user_email=user_id)
        logger.info(f"[Chat History] Found {len(all_sessions)} total sessions for user {user_id}")
        
        # Apply source filter if provided
        if source:
            filtered_sessions = [s for s in all_sessions if s.get("source") == source]
            logger.info(f"[Chat History] Filtered {len(all_sessions)} sessions to {len(filtered_sessions)} for source={source}")
            return [SessionSummary(**s) for s in filtered_sessions]
        
        logger.info(f"[Chat History] Retrieved {len(all_sessions)} sessions for user {user_id}")
        return [SessionSummary(**s) for s in all_sessions]
        
    except AttributeError as e:
        logger.error(f"AttributeError - method might not exist: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Method error: {str(e)}")
    except TypeError as e:
        logger.error(f"TypeError - argument mismatch: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Type error: {str(e)}")
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}", exc_info=True)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error listing sessions: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to list sessions: {str(e)}")


# === SESSION RETRIEVAL AND CONVERSATION ===

@router.get("/sessions/{session_id}", response_model=SessionResponse)
async def get_session_conversation(
    session_id: str,
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    Get full conversation history for a session.
    
    Returns complete conversation data with all messages, metadata, and timing.
    
    Args:
        session_id: Session identifier
        chat_service: Chat history service dependency
        
    Returns:
        Complete session data with conversation messages
        
    Raises:
        404: If session not found
    """
    try:
        result = chat_service.get_session_conversation(session_id)
        
        if not result:
            logger.warning(f"[Chat History] Session {session_id} not found")
            raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
        
        logger.info(f"[Chat History] Retrieved conversation for session {session_id}")
        return SessionResponse(**result)
        
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve session: {str(e)}")


@router.get("/sessions/{session_id}/messages", response_model=List[dict])
async def get_messages_for_llm(
    session_id: str,
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    Get conversation messages formatted for LLM context.
    Returns only role and content fields suitable for passing to LLM.
    
    Args:
        session_id: Session identifier
        chat_service: Chat history service dependency
        
    Returns:
        List of messages with role and content only
    """
    try:
        messages = chat_service.format_messages_for_llm(session_id)
        return messages
        
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error retrieving messages: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve messages: {str(e)}")


# === MESSAGE MANAGEMENT ===

@router.post("/sessions/{session_id}/messages", response_model=MessageResponse)
async def add_message_to_session(
    session_id: str,
    request: AddMessageRequest,
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    Add a message to an existing session.
    
    Args:
        session_id: Session identifier
        request: Message data
        chat_service: Chat history service dependency
        
    Returns:
        Updated conversation data
    """
    try:
        result = chat_service.add_message_to_session(
            session_id=session_id,
            role=request.role,
            content=request.content
        )
        
        return MessageResponse(**result)
        
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error adding message: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to add message: {str(e)}")


# === SESSION DELETION ===

@router.delete("/sessions/{session_id}", status_code=204)
async def delete_session(
    session_id: str,
    chat_service: ChatHistoryService = Depends(get_chat_history_service)
):
    """
    Delete a chat session (soft delete).
    
    Args:
        session_id: Session identifier
        chat_service: Chat history service dependency
        
    Returns:
        No content on success
        
    Raises:
        404: If session not found
    """
    try:
        deleted = chat_service.delete_session(session_id)
        
        if not deleted:
            logger.warning(f"[Chat History] Attempted to delete non-existent session {session_id}")
            raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
        
        logger.info(f"[Chat History] Deleted session {session_id}")
        return None
        
    except ValueError as e:
        logger.error(f"Invalid request parameters: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to delete session: {str(e)}")
