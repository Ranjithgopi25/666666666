from typing import TypedDict, Annotated, Sequence, Optional, Dict, Any, Literal
from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langchain_openai import AzureChatOpenAI
from app.features.thought_leadership.agents.tools import get_all_tools
from app.features.thought_leadership.agents.prompts import get_system_prompt
import operator
import json
import logging
from app.core.config import config
from typing import List

logger = logging.getLogger(__name__)


class AgentState(TypedDict):
    """State for the TL agent"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    conversation_id: Optional[str]


class TLAgent:
    """LangGraph agent for handling Thought Leadership workflows conversationally"""
    
    def __init__(self, conduct_research_service, refine_content_service, format_translator_service):
        logger.info("[TL Agent] Initializing TLAgent")
        self.conduct_research_service = conduct_research_service
        self.refine_content_service = refine_content_service
        self.format_translator_service = format_translator_service
        
        # Store tools
        self.tools = get_all_tools()
        logger.info(f"[TL Agent] Loaded {len(self.tools)} tools: {[t.name for t in self.tools]}")
        
        # Initialize Azure OpenAI
        self.llm = AzureChatOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
            temperature=0
        ).bind_tools(self.tools)
        logger.info(f"[TL Agent] LLM initialized with deployment: {config.AZURE_OPENAI_DEPLOYMENT}")
        
        # Build graph
        self.graph = self._build_graph()
        logger.info("[TL Agent] Graph built successfully")
    
    def _call_model(self, state: AgentState) -> AgentState:
        """Call LLM with system prompt"""
        logger.info("=" * 100)
        logger.info("[TL Agent] >>> _call_model INVOKED <<<")
        logger.info(f"[TL Agent] State contains {len(state['messages'])} message(s)")
        logger.info(f"[TL Agent] Conversation ID: {state.get('conversation_id', 'None')}")
        
        # Log each message in detail
        for idx, msg in enumerate(state["messages"]):
            msg_type = type(msg).__name__
            
            if isinstance(msg, HumanMessage):
                content = msg.content[:300] if len(msg.content) > 300 else msg.content
                logger.info(f"[TL Agent] Message[{idx}] = HumanMessage")
                logger.info(f"[TL Agent]   Content: {content}...")
                
            elif isinstance(msg, AIMessage):
                content = msg.content[:300] if msg.content and len(msg.content) > 300 else msg.content
                logger.info(f"[TL Agent] Message[{idx}] = AIMessage")
                logger.info(f"[TL Agent]   Content: {content}...")
                if hasattr(msg, 'tool_calls') and msg.tool_calls:
                    logger.info(f"[TL Agent]   Tool Calls: {len(msg.tool_calls)}")
                    for tc_idx, tc in enumerate(msg.tool_calls):
                        logger.info(f"[TL Agent]     ToolCall[{tc_idx}]: {tc['name']}")
                        
            elif isinstance(msg, ToolMessage):
                logger.info(f"[TL Agent] Message[{idx}] = ToolMessage")
                try:
                    content_json = json.loads(msg.content)
                    logger.info(f"[TL Agent]   Status: {content_json.get('status', 'unknown')}")
                    if content_json.get('content'):
                        logger.info(f"[TL Agent]   Content length: {len(content_json.get('content', ''))} chars")
                except:
                    logger.info(f"[TL Agent]   Raw content: {msg.content[:200]}...")
        
        # Prepare messages for LLM
        system_prompt = get_system_prompt()
        logger.info(f"[TL Agent] System prompt length: {len(system_prompt)} chars")
        
        messages = [HumanMessage(content=system_prompt)] + state["messages"]
        logger.info(f"[TL Agent] Sending {len(messages)} message(s) to LLM")
        
        # Call LLM
        logger.info("[TL Agent] >>> Calling LLM... <<<")
        response = self.llm.invoke(messages)
        logger.info("[TL Agent] >>> LLM Response Received <<<")
        
        # Log response details
        logger.info(f"[TL Agent] Response type: {type(response).__name__}")
        
        if response.content:
            content_preview = response.content[:500] if len(response.content) > 500 else response.content
            logger.info(f"[TL Agent] Response content: {content_preview}...")
        else:
            logger.info("[TL Agent] Response has no content")
        
        if hasattr(response, 'tool_calls') and response.tool_calls:
            logger.info(f"[TL Agent] >>> LLM WANTS TO CALL {len(response.tool_calls)} TOOL(S) <<<")
            for idx, tool_call in enumerate(response.tool_calls):
                logger.info(f"[TL Agent] ToolCall[{idx}]:")
                logger.info(f"[TL Agent]   Name: {tool_call['name']}")
                logger.info(f"[TL Agent]   ID: {tool_call['id']}")
                logger.info(f"[TL Agent]   Args: {json.dumps(tool_call['args'], indent=4)}")
        else:
            logger.info("[TL Agent] >>> LLM DID NOT CALL ANY TOOLS (conversational response) <<<")
        
        logger.info("[TL Agent] >>> _call_model COMPLETED <<<")
        logger.info("=" * 100)
        
        return {"messages": [response]}
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow"""
        logger.info("[TL Agent] Building LangGraph workflow")
        workflow = StateGraph(AgentState)
        
        workflow.add_node("agent", self._call_model)
        workflow.add_node("tools", self._execute_tools)
        
        workflow.set_entry_point("agent")
        
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "tools",
                "end": END
            }
        )
        
        workflow.add_edge("tools", "agent")
        
        logger.info("[TL Agent] Graph structure: agent -> [continue: tools | end: END], tools -> agent")
        return workflow.compile()
    
    async def _execute_tools(self, state: AgentState) -> AgentState:
        """Execute tool calls with service injection"""
        logger.info("=" * 100)
        logger.info("[TL Agent] >>> _execute_tools INVOKED <<<")
        
        last_message = state["messages"][-1]
        logger.info(f"[TL Agent] Last message type: {type(last_message).__name__}")
        
        if not hasattr(last_message, 'tool_calls'):
            logger.error("[TL Agent] ERROR: Last message has no tool_calls attribute!")
            return {"messages": []}
        
        logger.info(f"[TL Agent] Processing {len(last_message.tool_calls)} tool call(s)")
        
        tool_messages = []
        
        for tc_idx, tool_call in enumerate(last_message.tool_calls):
            tool_name = tool_call["name"]
            tool_args = tool_call["args"].copy()
            
            logger.info(f"[TL Agent] >>> ToolCall[{tc_idx}]: {tool_name} <<<")
            logger.info(f"[TL Agent] Tool ID: {tool_call['id']}")
            logger.info(f"[TL Agent] Original Args:")
            for key, value in tool_args.items():
                if isinstance(value, str) and len(value) > 200:
                    logger.info(f"[TL Agent]   {key}: {value[:200]}... (truncated, total {len(value)} chars)")
                else:
                    logger.info(f"[TL Agent]   {key}: {value}")
            
            try:
                # Inject services based on tool
                if tool_name == "conduct_research_tool":
                    logger.info("[TL Agent] Injecting conduct_research_service")
                    tool_args["conduct_research_service"] = self.conduct_research_service
                    
                    # Build messages history
                    messages_history = [
                        {"role": msg.type, "content": msg.content} 
                        for msg in state["messages"] 
                        if isinstance(msg, (HumanMessage, AIMessage))
                    ]
                    tool_args["messages"] = messages_history
                    logger.info(f"[TL Agent] Injected {len(messages_history)} message(s) into tool args")
                    
                elif tool_name == "refine_content_tool":
                    logger.info("[TL Agent] Injecting refine_content_service")
                    tool_args["refine_content_service"] = self.refine_content_service
                    
                elif tool_name == "format_translator_tool":
                    logger.info("[TL Agent] Injecting format_translator_service")
                    tool_args["format_translator_service"] = self.format_translator_service
                    
                    # Log specific args for format translator
                    logger.info(f"[TL Agent] Format Translator Args:")
                    logger.info(f"[TL Agent]   source_format: {tool_args.get('source_format')}")
                    logger.info(f"[TL Agent]   target_format: {tool_args.get('target_format')}")
                    logger.info(f"[TL Agent]   customization: {tool_args.get('customization')}")
                    logger.info(f"[TL Agent]   word_limit: {tool_args.get('word_limit')}")
                    content_len = len(tool_args.get('content', ''))
                    logger.info(f"[TL Agent]   content length: {content_len} chars")
                
                # Find tool function
                tool_func = next((t for t in self.tools if t.name == tool_name), None)
                
                if not tool_func:
                    logger.error(f"[TL Agent] ERROR: Tool '{tool_name}' not found!")
                    result = {"status": "error", "message": f"Unknown tool: {tool_name}"}
                else:
                    logger.info(f"[TL Agent] >>> Invoking tool function: {tool_name} <<<")
                    result = await tool_func.ainvoke(tool_args)
                    logger.info(f"[TL Agent] >>> Tool execution completed <<<")
                    
                    # Log result
                    logger.info(f"[TL Agent] Tool Result:")
                    logger.info(f"[TL Agent]   Status: {result.get('status', 'unknown')}")
                    if result.get('status') == 'success':
                        content_length = len(result.get('content', ''))
                        logger.info(f"[TL Agent]   Content length: {content_length} chars")
                        logger.info(f"[TL Agent]   Content preview: {result.get('content', '')[:200]}...")
                    elif result.get('status') == 'error':
                        logger.error(f"[TL Agent]   Error message: {result.get('message')}")
                    
                    # Log additional result fields
                    for key, value in result.items():
                        if key not in ['status', 'content', 'message']:
                            logger.info(f"[TL Agent]   {key}: {value}")
                
                # Create tool message
                tool_message = ToolMessage(
                    content=json.dumps(result),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
                logger.info(f"[TL Agent] Created ToolMessage for tool_call_id: {tool_call['id']}")
                
            except Exception as e:
                logger.error(f"[TL Agent] !!! TOOL EXECUTION EXCEPTION !!!")
                logger.error(f"[TL Agent] Exception: {e}", exc_info=True)
                
                tool_message = ToolMessage(
                    content=json.dumps({"status": "error", "message": str(e)}),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
        
        logger.info(f"[TL Agent] Returning {len(tool_messages)} tool message(s)")
        logger.info("[TL Agent] >>> _execute_tools COMPLETED <<<")
        logger.info("=" * 100)
        
        return {"messages": tool_messages}
    
    def _should_continue(self, state: AgentState) -> Literal["continue", "end"]:
        """Decide whether to continue with tool calls or end"""
        logger.info("[TL Agent] >>> _should_continue CHECK <<<")
        
        last_message = state["messages"][-1]
        logger.info(f"[TL Agent] Last message type: {type(last_message).__name__}")
        
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            logger.info(f"[TL Agent] Decision: CONTINUE → tools (has {len(last_message.tool_calls)} tool call(s))")
            return "continue"
        
        logger.info("[TL Agent] Decision: END (no tool calls - conversational response)")
        return "end"
    
    async def process_message_sync(
        self,
        messages: List[BaseMessage],
        conversation_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process user message through the graph (non-streaming version)
        Returns dict with message
        """

        
        initial_state = {
                "messages": messages,  # CORRECT - messages is already a List[BaseMessage]
                "conversation_id": conversation_id
            }
        try:
            logger.info("[TL Agent] >>> Starting graph execution <<<")
            final_state = await self.graph.ainvoke(initial_state)
            logger.info("[TL Agent] >>> Graph execution completed <<<")
            
            logger.info(f"[TL Agent] Final state contains {len(final_state['messages'])} message(s)")
            
            # Log final state messages
            for idx, msg in enumerate(final_state["messages"]):
                logger.info(f"[TL Agent] FinalState[{idx}]: {type(msg).__name__}")
            
            # Extract AI response
            ai_messages = [msg for msg in final_state["messages"] if isinstance(msg, AIMessage)]
            logger.info(f"[TL Agent] Found {len(ai_messages)} AI message(s)")
            
            response_message = ai_messages[-1].content if ai_messages else "Processing..."
            logger.info(f"[TL Agent] Response message: {response_message[:200]}...")
            
            # Check for tool results
            tool_messages = [msg for msg in final_state["messages"] if isinstance(msg, ToolMessage)]
            logger.info(f"[TL Agent] Found {len(tool_messages)} tool message(s)")
            
            tool_results = []
            for tool_msg in tool_messages:
                try:
                    result_data = json.loads(tool_msg.content)
                    logger.info(f"[TL Agent] Tool result status: {result_data.get('status')}")
                    if result_data.get("status") == "success":
                        tool_results.append(result_data)
                except Exception as e:
                    logger.error(f"[TL Agent] Failed to parse tool message: {e}")
            
            result = {
                "message": response_message,
                "conversation_id": conversation_id
            }
            
            if tool_results:
                result["tool_results"] = tool_results
                logger.info(f"[TL Agent] Including {len(tool_results)} tool result(s) in response")
            
            logger.info("[TL Agent] ========== process_message_sync COMPLETED ==========")
            logger.info("=" * 100)
            return result
                
        except Exception as e:
            logger.error(f"[TL Agent] !!! PROCESS ERROR !!!")
            logger.error(f"[TL Agent] Exception: {e}", exc_info=True)
            return {
                "message": f"Error: {str(e)}",
                "conversation_id": conversation_id
            }
    
    async def process_message_stream(
        self,
        messages: List[BaseMessage],
        conversation_id: Optional[str] = None
    ):
        """
        Process user message through the graph with streaming
        Yields SSE formatted chunks
        """
        
        
        async def generate():
            initial_state = {
                "messages": messages,  # CORRECT - messages is already a List[BaseMessage]
                "conversation_id": conversation_id
            }
            
            try:
                logger.info("[TL Agent Stream] >>> Starting graph streaming <<<")
                
                # Stream through the graph
                event_count = 0
                async for event in self.graph.astream(initial_state):
                    event_count += 1
                    logger.info(f"[TL Agent Stream] >>> Event #{event_count} <<<")
                    logger.info(f"[TL Agent Stream] Event keys: {list(event.keys())}")
                    
                    # Check for agent node responses
                    if "agent" in event:
                        logger.info("[TL Agent Stream] Processing 'agent' event")
                        agent_message = event["agent"]["messages"][-1]
                        logger.info(f"[TL Agent Stream] Agent message type: {type(agent_message).__name__}")
                        
                        if isinstance(agent_message, AIMessage):
                            has_content = hasattr(agent_message, "content") and agent_message.content
                            has_tool_calls = hasattr(agent_message, "tool_calls") and agent_message.tool_calls
                            
                            logger.info(f"[TL Agent Stream] Has content: {has_content}")
                            logger.info(f"[TL Agent Stream] Has tool calls: {has_tool_calls}")
                            
                            if has_content and not has_tool_calls:
                                content = agent_message.content
                                logger.info(f"[TL Agent Stream] >>> Streaming conversational response ({len(content)} chars) <<<")
                                
                                # Stream character by character
                                for idx, char in enumerate(content):
                                    yield f'data: {json.dumps({"type": "content", "content": char})}\n\n'
                                    if idx % 100 == 0:
                                        logger.debug(f"[TL Agent Stream] Streamed {idx}/{len(content)} chars")
                                
                                logger.info(f"[TL Agent Stream] Finished streaming conversational response")
                            
                            elif has_tool_calls:
                                logger.info(f"[TL Agent Stream] Agent calling {len(agent_message.tool_calls)} tool(s) - waiting for tool results")
                    
                    # Handle tool execution results
                    elif "tools" in event:
                        logger.info("[TL Agent Stream] Processing 'tools' event")
                        tool_messages = event["tools"]["messages"]
                        logger.info(f"[TL Agent Stream] Received {len(tool_messages)} tool message(s)")
                        
                        for tm_idx, tool_msg in enumerate(tool_messages):
                            logger.info(f"[TL Agent Stream] Processing tool message {tm_idx}")
                            
                            if isinstance(tool_msg, ToolMessage):
                                try:
                                    result_data = json.loads(tool_msg.content)
                                    status = result_data.get('status')
                                    logger.info(f"[TL Agent Stream] Tool result status: {status}")
                                    
                                    if status == "success":
                                        content = result_data.get("content", "")
                                        logger.info(f"[TL Agent Stream] >>> Streaming tool result ({len(content)} chars) <<<")
                                        
                                        # Stream tool result character by character
                                        for idx, char in enumerate(content):
                                            yield f'data: {json.dumps({"type": "content", "content": char})}\n\n'
                                            if idx % 100 == 0:
                                                logger.debug(f"[TL Agent Stream] Streamed {idx}/{len(content)} chars")
                                        
                                        logger.info(f"[TL Agent Stream] Finished streaming tool result")
                                    else:
                                        logger.error(f"[TL Agent Stream] Tool returned error: {result_data.get('message')}")
                                        
                                except json.JSONDecodeError as e:
                                    logger.error(f"[TL Agent Stream] JSON decode error: {e}")
                                    logger.error(f"[TL Agent Stream] Raw content: {tool_msg.content[:500]}")
                
                # Send done signal
                logger.info("[TL Agent Stream] >>> Sending 'done' signal <<<")
                yield f'data: {json.dumps({"type": "done", "done": True})}\n\n'
                
                logger.info(f"[TL Agent Stream] Total events processed: {event_count}")
                logger.info("[TL Agent Stream] ========== process_message_stream COMPLETED ==========")
                logger.info("=" * 100)
                        
            except Exception as e:
                logger.error(f"[TL Agent Stream] !!! STREAMING ERROR !!!")
                logger.error(f"[TL Agent Stream] Exception: {e}", exc_info=True)
                yield f'data: {json.dumps({"type": "error", "error": str(e)})}\n\n'
        
        return generate()
# from typing import TypedDict, Annotated, Sequence, Optional, Dict, Any, Literal
# from langgraph.graph import StateGraph, END
# from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
# from langchain_openai import AzureChatOpenAI
# from app.features.thought_leadership.agents.tools import get_all_tools
# from app.features.thought_leadership.agents.prompts import get_system_prompt
# import operator
# import json
# import logging
# from app.core.config import config


# logger = logging.getLogger(__name__)


# class AgentState(TypedDict):
#     """State for the TL agent"""
#     messages: Annotated[Sequence[BaseMessage], operator.add]
#     conversation_id: Optional[str]


# class TLAgent:
#     """LangGraph agent for handling Thought Leadership workflows conversationally"""
    
#     def __init__(self, conduct_research_service, refine_content_service, format_translator_service):
#         self.conduct_research_service = conduct_research_service
#         self.refine_content_service = refine_content_service
#         self.format_translator_service = format_translator_service
        
#         # Store tools
#         self.tools = get_all_tools()
        
#         # Initialize Azure OpenAI
#         self.llm = AzureChatOpenAI(
#             azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
#             api_key=config.AZURE_OPENAI_API_KEY,
#             api_version=config.AZURE_OPENAI_API_VERSION,
#             deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
#             temperature=0
#         ).bind_tools(self.tools)
        
#         # Build graph
#         self.graph = self._build_graph()
    
#     # def _call_model(self, state: AgentState) -> AgentState:
#     #     """Call LLM with system prompt"""
#     #     system_prompt = get_system_prompt()
#     #     messages = [HumanMessage(content=system_prompt)] + state["messages"]
#     #     response = self.llm.invoke(messages)
#     #     return {"messages": [response]}
#     def _call_model(self, state: AgentState) -> AgentState:
#         """Call LLM with system prompt"""
#         system_prompt = get_system_prompt()
        
#         # Build messages with system prompt first, then conversation history
#         messages = [
#             {"role": "system", "content": system_prompt}
#         ]
        
#         # Add conversation messages
#         for msg in state["messages"]:
#             if isinstance(msg, HumanMessage):
#                 messages.append({"role": "user", "content": msg.content})
#             elif isinstance(msg, AIMessage):
#                 if hasattr(msg, 'tool_calls') and msg.tool_calls:
#                     # Skip tool call messages in history to avoid confusion
#                     continue
#                 messages.append({"role": "assistant", "content": msg.content})
#             elif isinstance(msg, ToolMessage):
#                 # Skip tool messages - they'll be handled by tool execution
#                 continue
        
#         # Convert to LangChain message format
#         lc_messages = [HumanMessage(content=system_prompt)] + state["messages"]
        
#         response = self.llm.invoke(lc_messages)
#         return {"messages": [response]}
    
#     def _build_graph(self) -> StateGraph:
#         """Build the LangGraph workflow"""
#         workflow = StateGraph(AgentState)
        
#         workflow.add_node("agent", self._call_model)
#         workflow.add_node("tools", self._execute_tools)
        
#         workflow.set_entry_point("agent")
        
#         workflow.add_conditional_edges(
#             "agent",
#             self._should_continue,
#             {
#                 "continue": "tools",
#                 "end": END
#             }
#         )
        
#         workflow.add_edge("tools", "agent")
        
#         return workflow.compile()
    
#     async def _execute_tools(self, state: AgentState) -> AgentState:
#         """Execute tool calls with service injection"""
#         last_message = state["messages"][-1]
        
#         logger.info(f'[TL Agent] Executing tools')
        
#         tool_messages = []
        
#         for tool_call in last_message.tool_calls:
#             tool_name = tool_call["name"]
#             tool_args = tool_call["args"].copy()
            
#             logger.info(f"[TL Agent] Executing tool: {tool_name}")
            
#             try:
#                 # Inject services based on tool
#                 if tool_name == "conduct_research_tool":
#                     logger.info(f"[TL Agent] Injecting conduct_research_service into tool args")
#                     tool_args["conduct_research_service"] = self.conduct_research_service
#                     tool_args["messages"] = [
#                         {"role": msg.type, "content": msg.content} 
#                         for msg in state["messages"] 
#                         if isinstance(msg, (HumanMessage, AIMessage))
#                     ]
#                 elif tool_name == "refine_content_tool":
#                     logger.info(f"[TL Agent] Injecting refine_content_service into tool args")
#                     tool_args["refine_content_service"] = self.refine_content_service
#                 elif tool_name == "format_translator_tool":
#                     logger.info(f"[TL Agent] Injecting format_translator_service into tool args")
#                     tool_args["format_translator_service"] = self.format_translator_service
                
#                 # Find and invoke tool
#                 tool_func = next((t for t in self.tools if t.name == tool_name), None)
#                 if tool_func:
#                     result = await tool_func.ainvoke(tool_args)
#                 else:
#                     result = {"error": f"Unknown tool: {tool_name}"}
                
#                 # Create tool message
#                 tool_message = ToolMessage(
#                     content=json.dumps(result),
#                     tool_call_id=tool_call["id"]
#                 )
#                 tool_messages.append(tool_message)
                
#             except Exception as e:
#                 logger.error(f"[TL Agent] Tool execution error: {e}", exc_info=True)
#                 tool_message = ToolMessage(
#                     content=json.dumps({"error": str(e)}),
#                     tool_call_id=tool_call["id"]
#                 )
#                 tool_messages.append(tool_message)
        
#         return {"messages": tool_messages}
    
#     def _should_continue(self, state: AgentState) -> Literal["continue", "end"]:
#         """Decide whether to continue with tool calls or end"""
#         last_message = state["messages"][-1]
        
#         if hasattr(last_message, "tool_calls") and last_message.tool_calls:
#             return "continue"
        
#         return "end"
    
#     async def process_message_sync(
#         self,
#         message: str,
#         conversation_id: Optional[str] = None
#     ) -> Dict[str, Any]:
#         """
#         Process user message through the graph (non-streaming version)
#         Returns dict with message
#         """
        
#         initial_state = {
#             "messages": [HumanMessage(content=message)],
#             "conversation_id": conversation_id
#         }
        
#         try:
#             final_state = await self.graph.ainvoke(initial_state)
            
#             # Extract AI response
#             ai_messages = [msg for msg in final_state["messages"] if isinstance(msg, AIMessage)]
#             response_message = ai_messages[-1].content if ai_messages else "Processing..."
            
#             # Check for tool results
#             tool_messages = [msg for msg in final_state["messages"] if isinstance(msg, ToolMessage)]
#             tool_results = []
            
#             for tool_msg in tool_messages:
#                 try:
#                     result_data = json.loads(tool_msg.content)
#                     if result_data.get("status") == "success":
#                         tool_results.append(result_data)
#                 except:
#                     pass
            
#             result = {
#                 "message": response_message,
#                 "conversation_id": conversation_id
#             }
            
#             # Include tool results if available
#             if tool_results:
#                 result["tool_results"] = tool_results
            
#             return result
                
#         except Exception as e:
#             logger.error(f"[TL Agent] Error: {e}", exc_info=True)
#             return {
#                 "message": f"Error: {str(e)}",
#                 "conversation_id": conversation_id
#             }
        
#     async def process_message_stream(
#         self,
#         message: str,
#         conversation_id: Optional[str] = None
#     ):
#         """
#         Process user message through the graph with streaming
#         Yields SSE formatted chunks
#         """
        
#         async def generate():
#             initial_state = {
#                 "messages": [HumanMessage(content=message)],
#                 "conversation_id": conversation_id
#             }
            
#             try:
#                 # Stream through the graph
#                 async for event in self.graph.astream(initial_state):
#                     # Check for agent node responses
#                     if "agent" in event:
#                         agent_message = event["agent"]["messages"][-1]
                        
#                         if isinstance(agent_message, AIMessage):
#                             # Stream content chunks
#                             if hasattr(agent_message, "content") and agent_message.content:
#                                 # If content is a string, yield it as chunks
#                                 content = agent_message.content
                                
#                                 # Split into words or use as-is
#                                 for char in content:
#                                     yield f'data: {json.dumps({"type": "content", "content": char})}\n\n'
                            
#                             # Check if tool calls are present (don't stream these)
#                             if hasattr(agent_message, "tool_calls") and agent_message.tool_calls:
#                                 continue
                    
#                     # Handle tool execution results (optional - you can include or skip)
#                     elif "tools" in event:
#                         tool_messages = event["tools"]["messages"]
#                         for tool_msg in tool_messages:
#                             if isinstance(tool_msg, ToolMessage):
#                                 try:
#                                     result_data = json.loads(tool_msg.content)
#                                     if result_data.get("status") == "success":
#                                         content = result_data.get("content", "")
#                                         # Stream tool result content
#                                         for char in content:
#                                             yield f'data: {json.dumps({"type": "content", "content": char})}\n\n'
#                                 except:
#                                     pass
                
#                 # Send done signal
#                 yield f'data: {json.dumps({"type": "done", "done": True})}\n\n'
                        
#             except Exception as e:
#                 logger.error(f"[TL Agent Stream] Error: {e}", exc_info=True)
#                 yield f'data: {json.dumps({"type": "error", "error": str(e)})}\n\n'
        
#         return generate()