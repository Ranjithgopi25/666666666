from langchain_core.tools import tool
from typing import Dict, Any, Optional, List
import json
import logging
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.config import config
logger = logging.getLogger(__name__)



@tool
async def format_translator_tool(
    content: str,
    source_format: str,
    target_format: str,
    customization: Optional[str] = None,
    word_limit: Optional[str] = None,
    format_translator_service = None
) -> Dict[str, Any]:
    """
    Translate content between different formats (Social Media Post, Webpage Ready).
    
    Use this tool when the user asks to:
    - Convert content to social media post (X.com/Twitter, LinkedIn)
    - Convert content to webpage ready format
    - Reformat existing content for different platforms
    - Transform content with specific word limits
    
    Args:
        content: The content to translate/convert
        source_format: Original format (e.g., "Article", "Document", "Email")
        target_format: Target format - MUST be either "social media post" or "webpage ready"
        customization: Platform specification for social media (e.g., "X.com", "LinkedIn")
        word_limit: Optional word limit (e.g., "200", "500")
        format_translator_service: Service instance (injected at runtime)
    
    Returns:
        Dict with translated content or error message
    """
    if not format_translator_service:
        return {"status": "error", "message": "Format translator service not available"}
    
    # Validate target format
    target_format_lower = target_format.lower()
    if target_format_lower not in ["social media post", "social media", "webpage ready"]:
        return {
            "status": "error",
            "message": f"Unsupported target format: {target_format}. Only 'social media post' and 'webpage ready' are supported."
        }
    
    try:
        logger.info(f"[Tool] Translating format: {source_format} -> {target_format}")
        if customization:
            logger.info(f"[Tool] Customization: {customization}")
        if word_limit:
            logger.info(f"[Tool] Word limit: {word_limit}")
        
        # Collect all streamed content
        translated_content = []
        async for chunk in format_translator_service.translate_format(
            content=content,
            source_format=source_format,
            target_format=target_format,
            customization=customization,
            podcast_style=None,
            speaker1_name=None,
            speaker1_voice=None,
            speaker1_accent=None,
            speaker2_name=None,
            speaker2_voice=None,
            speaker2_accent=None,
            word_limit=word_limit
        ):
            # Parse SSE chunks
            if chunk.startswith("data: "):
                try:
                    data = json.loads(chunk[6:])
                    if data.get("type") == "content":
                        translated_content.append(data.get("content", ""))
                    elif data.get("type") == "error":
                        return {
                            "status": "error",
                            "message": data.get("error", "Translation failed")
                        }
                except json.JSONDecodeError:
                    continue
        
        full_content = "".join(translated_content)
        
        return {
            "status": "success",
            "content": full_content,
            "source_format": source_format,
            "target_format": target_format,
            "word_count": len(full_content.split())
        }
        
    except Exception as e:
        logger.error(f"[Tool] Format translation error: {e}", exc_info=True)
        return {
            "status": "error",
            "message": str(e)
        }
    
@tool
async def conduct_research_tool(
    query: str,
    additional_guidelines: Optional[str] = None,
    conduct_research_service = None,
    messages: List[dict] = None
) -> Dict[str, Any]:
    """
    Conduct comprehensive research on a topic with citations and references.
    
    Use this tool when the user asks to:
    - Research a topic
    - Gather information with sources
    - Create a research article
    - Analyze a topic with citations
    
    Args:
        query: The research query/topic to investigate
        additional_guidelines: Optional instructions for research approach
        conduct_research_service: Service instance (injected at runtime)
        messages: Conversation messages (injected at runtime)
    
    Returns:
        Dict with research content or error message
    """
    if not conduct_research_service:
        return {"status": "error", "message": "Research service not available"}
    
    try:
        logger.info(f"[Tool] Conducting research on: {query}")
        
        # STEP 1: Call LangGraph Agent for multi-source data
        langgraph_context = ""
        try:
            logger.info(f"[Tool] Initializing LangGraph Agent for multi-source query")
            
            # Create LangGraph agent instance
            langgraph_agent = create_data_source_agent(
                azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            
            # Build the query message for the agent
            agent_messages = [
                {
                    "role": "user",
                    "content": f"please call all the necessary tools to provide answer to this user query: {query}"
                }
            ]
            
            logger.info(f"[Tool] Calling LangGraph Agent with query: {query}")
            
            # Get response from LangGraph agent (non-streaming for research context)
            agent_response = await langgraph_agent.process_query(agent_messages)
            
            if agent_response:
                logger.info(f"[Tool] LangGraph Agent returned {len(agent_response)} characters")
                langgraph_context = f"""

--- Research Results from Multi-Source Data Integration ---
Sources automatically queried by AI Agent:
- Factiva News (external news and media coverage)
- Internal Knowledge Base (company documents and reports)
- CapitalIQ Financials (income statements and balance sheets)
- BoardEx Intelligence (advisors and executive achievements)

{agent_response}

--- End of Research Results ---
"""
                logger.info("[Tool] LangGraph Agent context added to research")
            else:
                logger.warning("[Tool] LangGraph Agent returned empty response")
            
            # Close agent connections
            langgraph_agent.close()
            
        except Exception as e:
            logger.error(f"[Tool] LangGraph Agent error: {e}", exc_info=True)
            # Continue without agent context - don't break the workflow
            logger.warning("[Tool] Continuing research without LangGraph Agent data")
        
        # STEP 2: Collect all streamed content from ConductResearchService
        research_content = []
        async for chunk in conduct_research_service.conduct_research(
            query=query,
            sources=conduct_research_service.sources,
            messages=messages or [],
            langgraph_context=langgraph_context,  # Pass LangGraph context here
            additional_guidelines=additional_guidelines or "",
            use_factiva_research=False,
            factiva_context=""
        ):
            # Parse SSE chunks
            if chunk.startswith("data: "):
                try:
                    data = json.loads(chunk[6:])
                    if data.get("type") == "content":
                        research_content.append(data.get("content", ""))
                    elif data.get("type") == "error":
                        return {
                            "status": "error",
                            "message": data.get("error", "Research failed")
                        }
                except json.JSONDecodeError:
                    continue
        
        full_content = "".join(research_content)
        
        return {
            "status": "success",
            "content": full_content,
            "sources_count": len(conduct_research_service.sources),
            "langgraph_used": bool(langgraph_context)
        }
        
    except Exception as e:
        logger.error(f"[Tool] Research error: {e}", exc_info=True)
        return {
            "status": "error",
            "message": str(e)
        }

@tool
async def refine_content_tool(
    original_content: str,
    services: List[Dict[str, Any]],
    refine_content_service = None
) -> Dict[str, Any]:
    """
    Refine content with multiple enhancement services.
    
    Use this tool when the user asks to:
    - Expand or compress content
    - Adjust tone/audience
    - Add research to existing content
    - Edit or improve content
    - Get improvement suggestions
    
    Args:
        original_content: The content to refine
        services: List of service configurations (expand, compress, tone, research, edit, suggestions)
        refine_content_service: Service instance (injected at runtime)
    
    Returns:
        Dict with refined content or error message
    """
    if not refine_content_service:
        return {"status": "error", "message": "Refine service not available"}
    
    try:
        logger.info(f"[Tool] Refining content with {len(services)} services")
        
        # Build request data
        request_data = {
            "original_content": original_content,
            "services": services,
            "messages": []
        }
        
        # Collect all streamed content
        refined_content = []
        async for chunk in refine_content_service.refine_content(request_data):
            # Parse SSE chunks
            if chunk.startswith("data: "):
                try:
                    data = json.loads(chunk[6:])
                    if data.get("type") == "content":
                        refined_content.append(data.get("content", ""))
                    elif data.get("type") == "error":
                        return {
                            "status": "error",
                            "message": data.get("error", "Refinement failed")
                        }
                except json.JSONDecodeError:
                    continue
        
        full_content = "".join(refined_content)
        
        return {
            "status": "success",
            "content": full_content,
            "services_applied": len([s for s in services if s.get("isSelected", False)])
        }
        
    except Exception as e:
        logger.error(f"[Tool] Refinement error: {e}", exc_info=True)
        return {
            "status": "error",
            "message": str(e)
        }


def get_all_tools():
    """Return list of all available tools."""
    return [
        conduct_research_tool,
        refine_content_tool,
        format_translator_tool
    ]