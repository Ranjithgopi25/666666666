from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from typing import List, Dict, Any
from pydantic import BaseModel
from app.core.deps import get_llm_service
from app.infrastructure.llm.llm_service import LLMService
from app.features.thought_leadership.agents.tl_agent_service import TLAgent
from app.features.thought_leadership.services.conduct_research_service import ConductResearchService
from app.features.thought_leadership.services.refine_content_service import RefineContentService
import logging
from app.features.thought_leadership.services.format_translator_service import FormatTranslatorService
from fastapi.responses import StreamingResponse
from langchain_core.messages import HumanMessage, AIMessage

router = APIRouter()
logger = logging.getLogger(__name__)


class Message(BaseModel):
    role: str
    content: str


class TLChatRequest(BaseModel):
    messages: List[Message]
    stream: bool = False
    user_id: str
    session_id: str
    source: str = "Thought_Leadership"

@router.post("")
async def tl_chat_agent(
    request: TLChatRequest,
    llm_service: LLMService = Depends(get_llm_service)
):
    """TL Chat Agent: Conversational interface for Thought Leadership workflows"""
    try:
        conversation_messages = []
        
        
        # Log all messages
    
        # Extract the last user message
        user_messages = [msg for msg in request.messages if msg.role == "user"]
        logger.info(f"[TL Chat Endpoint] Found {len(user_messages)} user message(s)")
        
        if not user_messages:
            logger.error("[TL Chat Endpoint] ERROR: No user message found")
            raise HTTPException(status_code=400, detail="No user message found")
        
        for msg in request.messages:
            if msg.role == "user":
                conversation_messages.append(HumanMessage(content=msg.content))
                logger.info(f"[TL Chat Endpoint] Added HumanMessage: {msg.content[:100]}...")
            elif msg.role == "assistant":
                # Only add non-empty assistant messages
                if msg.content and msg.content.strip():
                    conversation_messages.append(AIMessage(content=msg.content))
                    logger.info(f"[TL Chat Endpoint] Added AIMessage: {msg.content[:100]}...")

        
        # Initialize services
        logger.info("[TL Chat Endpoint] Initializing services...")
        conduct_research_service = ConductResearchService(llm_service)
        refine_content_service = RefineContentService(llm_service)
        format_translator_service = FormatTranslatorService(llm_service)
        logger.info("[TL Chat Endpoint] Services initialized")
        
        # Initialize TL agent with services
        logger.info("[TL Chat Endpoint] Initializing TL Agent...")
        agent = TLAgent(conduct_research_service, refine_content_service, format_translator_service)
        logger.info("[TL Chat Endpoint] TL Agent initialized")
        
        # Check if streaming is requested
        if request.stream:
            logger.info("[TL Chat Endpoint] >>> STREAMING MODE <<<")
            generator = await agent.process_message_stream(
                messages=conversation_messages,
                conversation_id=request.session_id
            )
            logger.info("[TL Chat Endpoint] Returning StreamingResponse")
            return StreamingResponse(
                generator,
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                }
            )
        else:
            logger.info("[TL Chat Endpoint] >>> NON-STREAMING MODE <<<")
            result = await agent.process_message_sync(
                messages=conversation_messages,
                conversation_id=request.session_id
            )
            
            logger.info("[TL Chat Endpoint] Returning JSONResponse")
            logger.info(f"[TL Chat Endpoint] Response message length: {len(result.get('message', ''))} chars")
            
            return JSONResponse(
                content={
                    "message": result.get("message", ""),
                    "session_id": request.session_id,
                    "tool_results": result.get("tool_results", [])
                }
            )
        
    except Exception as e:
        logger.error(f"[TL Chat Endpoint] !!! ENDPOINT ERROR !!!")
        logger.error(f"[TL Chat Endpoint] Exception: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))