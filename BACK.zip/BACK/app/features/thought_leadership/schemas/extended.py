from pydantic import BaseModel, Field
from typing import Optional, List
from fastapi import UploadFile

class PodcastRequest(BaseModel):
    """Request for podcast generation"""
    topic: str = Field(..., description="Podcast topic")
    style: str = Field("dialogue", description="Podcast style: dialogue or monologue")
    duration: Optional[str] = Field("medium", description="Duration: short, medium, long")
    context: Optional[str] = Field(None, description="Additional context")

class DraftArticleRequest(BaseModel):
    """Request for draft article with files"""
    topic: str = Field(..., description="Article topic")
    format_type: str = Field(..., description="Format type")
    audience: str = Field("", description="Target audience (optional - defaults will be applied based on format_type)")
    context: Optional[str] = Field(None, description="Additional context")
    outline: Optional[str] = Field(None, description="Article outline")
    supporting_docs: Optional[str] = Field(None, description="Supporting documents content")

class ResearchMaterialsRequest(BaseModel):
    """Request for research with materials"""
    query: str = Field(..., description="Research query")
    materials: Optional[str] = Field(None, description="Uploaded materials content")
    urls: Optional[List[str]] = Field(None, description="URLs to research")
    context: Optional[str] = Field(None, description="Additional context")

class UpdateSectionRequest(BaseModel):
    """Request for updating a specific section of content"""
    fullArticle: str = Field(..., description="Complete article content")
    sectionIndex: int = Field(..., description="Index of section to update")
    sectionContent: str = Field(..., description="Current section content")
    userPrompt: str = Field(..., description="User instruction for updating section")
    contentType: str = Field(..., description="Type of content (article, blog, etc)")
