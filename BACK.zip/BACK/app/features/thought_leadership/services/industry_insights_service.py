from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
import logging
import re
import json
import time
logger = logging.getLogger(__name__)


INDUSTRY_INSIGHTS_TEMPLATE_PROMPT  = """## INDUSTRY INSIGHTS
Follow this structure EXACTLY. Do not rename sections. Do not reorder sections. 
Global Instructions
Purpose
Generate clear, practical industry insights to help junior staff rapidly orient themselves when staffed on a project or proposal in an industry they have not previously worked in.
The output should enable a consultant to:
•	Understand how the industry actually works
•	Grasp where value, power, and pressure sit
•	Follow senior-level conversations with confidence
•	Apply insights immediately in diagnostics, client discussions, and analyses
Optimize for clarity, intuition, and project relevance, not exhaustiveness.

Audience Assumptions
•	Smart, analytical consultants
•	New to the industry, not to consulting
•	Time-constrained; reading this alongside project ramp-up
•	Needs mental models and judgment, not encyclopedic detail
Write so the content can be skimmed in 20–30 minutes and revisited as a reference.

Global Writing Standards (Non-Negotiable)
•	Headline-driven: Every section must begin with a bolded, one-sentence takeaway.
•	Structured for scanning: Use short paragraphs, bullets, and clear visual hierarchy.
•	Compression with clarity: Bullets must be concise but self-explanatory.
•	Project relevance: Each section must signal how this insight typically shows up on real client work.
•	No teaching tone: Do not define basic consulting concepts or explain industry history.
•	Clarity over precision: Use rounded figures unless precision materially changes conclusions.
•	Judgment-oriented: Emphasize what matters, why it matters, and where trade-offs arise.

Bullet Density & Clarity Rule (New)
To avoid over-compression:
•	Any bullet that uses abstract or partner-level language (e.g., “route-to-market excellence,” “AI-led transformation,” “RGM capabilities,” “operational reliability”) must include:
o	A short clarifier (parenthetical or clause) that explains what this means in practice
o	Typically 3–7 additional words, not a full sentence
Examples (illustrative):
•	Route-to-market excellence (shelf execution, OTIF, channel coverage)
•	RGM and data capabilities (pricing, pack mix, promo ROI)
•	AI-led transformation (embedded in pricing, planning, marketing)
Bullets should answer at least one of:
•	What does this mean day-to-day?
•	Where does this show up in decisions?
•	Why does this matter economically?

Fact, Time & Citation Discipline
•	Clearly distinguish externally sourced facts/data from synthesized insights or implications.
o	Facts explain what is true
o	Insights explain why it matters on a project
•	Clearly time-stamp major data points (e.g., “as of 2024/2025,” “over the next 3–5 years”).
•	If older data is used, explicitly label it as historical context.
•	When citing industry size, growth, margins, or trends, clearly state scope (e.g., manufacturer vs. retail value) and avoid overlapping segments.
Inline citation requirement (New)
•	Place citations inline, immediately after the claim they support, not only in a references section.
•	Use citations to support:
o	Market size, growth rates, margin ranges
o	Clearly attributed external viewpoints or statistics
•	Do not cite sources to legitimize synthesized judgment or PwC experience.
o	Frame those explicitly as “PwC experience,” “observed across engagements,” etc.
Example:
Price-led growth accounted for the majority of CPG value growth in 2022–2024, with volume weak in many mature categories (Bain, 2025; PwC CPG Executive Survey).

Standard Output Structure
1. Executive Overview
•	1-line industry definition (plain English)
•	Industry size & growth
o	Current size (directional, scoped)
o	3–5 year outlook
o	Price vs. volume dynamics
•	Profit pools
o	Where economic value is actually captured
o	Who is under pressure
•	Key emerging trends
o	3–5 structural forces shaping the industry
Explicitly state what a new team member should internalize first.

2. Industry Structure & Economics
•	Headline takeaway: How the industry creates and distributes value
•	Value chain & role definitions
o	Core segments and who does what
•	Economics by segment
o	Typical revenue, margin, and return profiles
o	Capital intensity characteristics
•	Primary cost drivers
o	What actually moves margins
o	How those drivers are changing
Project relevance: where cost, margin, or capital debates typically focus.

3. Competitive Landscape
•	Major players
o	Global leaders and key regional champions
•	Competitor archetypes
o	Incumbents, specialists, insurgents, private label, platforms
•	Sources of differentiation
o	What wins today (with brief “in practice” clarifiers)
•	New entrants and substitutes
•	M&A and portfolio activity
o	What consolidation signals strategically
Project relevance: how competition shapes client behavior and strategic choices.

4. Market Dynamics & Growth Drivers
•	Demand drivers
o	How they affect volume, pricing, or mix
•	Supply-side shifts
o	Capacity, sourcing, consolidation, technology
•	Geography- or segment-led growth pockets
•	Cyclical vs. secular forces
Project relevance: where growth cases are credible vs. fragile.

5. Major Pain Points
Focus on recurring, lived issues, not abstract challenges:
•	Operational issues
•	Customer and retailer complaints
•	Technology and data limitations
•	Financial and profitability pressures
•	Talent and organizational constraints
Explain root causes and how these problems show up day-to-day.
Project relevance: what typically triggers transformation or advisory work.

6. Disruption & Technology Impact
•	New business models
o	What is gaining traction vs. over-hyped
•	Technologies changing economics
o	Explicitly state how cost, service, margin, or risk changes
•	Proven AI use cases
o	Where value is already being realized
•	Emerging AI and digital applications
•	Adoption barriers
o	Why scaling is hard in practice
Project relevance: where clients are experimenting vs. investing seriously.

7. Strategic Opportunities & White Space
•	Recently announced strategic objectives
o	Common themes across leading players
•	Growth and defense spaces
•	Adjacencies worth exploring
•	Capability gaps across the value chain
o	Clarify what is missing and why that matters
•	Untapped customer segments or geographies
Project relevance: where strategy conversations usually land.

8. Regulations & Policy
•	Overall regulatory importance
o	Why regulation matters economically
•	Current regulatory landscape
o	Focus on impact, not legal detail
•	Emerging or pending regulation
o	What could materially change economics
Project relevance: how regulation shapes cost, innovation, and go-to-market choices.

9. Recent News (last 3–6 months)
•	Industry-wide developments
•	Major company-specific events
•	Regulatory or policy updates
Each item must include timeframe + named company or regulator and clearly state what changed and why it matters.
Depth & Scope Guardrails
•	Default to directional insight.
•	Avoid multiple estimates of the same metric unless differences materially affect conclusions.
•	Include country-specific examples only when they generalize to a broader pattern.
•	Prioritize insight that helps a consultant sound credible in their first client meeting.

Final Self-Check (Mandatory)
Before finalizing, confirm that:
•	Bullets are concise but interpretable by a junior
•	Abstract concepts include brief “in-practice” clarification
•	Facts and insights are clearly distinguished
•	Citations are placed inline next to supported claims
•	No section reads like a textbook or market report
•	The content supports doing better work, not just knowing more
Revise until all conditions are met.

"""


_INDUSTRY_INSIGHTS_FORMAT_CONFIG = {
    "tone_default": "Professional, analytical, and insight-driven",
    "tolerance": 2,
}

class IndustryInsightsService(BaseTLStreamingService):
    """Service for industry InsightsS generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize industry Insights Service        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    def _build_prompt(
    self,
    clientname: str,
    audience_tone: Optional[str],
    word_limit: int,
    outline_doc: str = "",
    supporting_doc: str = "",
    langgraph_context:str = "",
    citations_text: str = "",
    web_content: str = ""
) -> str:
        # Build format-specific opening based on content type
        context_sections = ""
        if outline_doc:
            context_sections += f"\n\n### OUTLINE\n{outline_doc}"
        if supporting_doc:
            context_sections += f"\n\n### SUPPORTING CONTEXT\n{supporting_doc}"
        if web_content:
            context_sections += (
                "\n\n### ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)\n"
                f"{web_content}"
            )
        
        audience_tone = audience_tone or _INDUSTRY_INSIGHTS_FORMAT_CONFIG["tone_default"]
        
        # logger.info(f'here is my langgraph_context {langgraph_context} ')
        task_desc = f"""**Task:** Generate a comprehensive & detailed , industry-wide Industry Insights report for {clientname}.
        This is a REPORT GENERATION task requiring comprehensive, detailed analysis.
        Requirements:
        - Each section must contain substantial analysis with a paragraph-length explanation
        - Every bullet point in the template requires few lines of explanation
        - Use specific data, examples, and context from all provided sources

        The document is intended for stakeholders with a {audience_tone} orientation and should provide a clear, structured view of the industry's economics, competitive dynamics, risks, and strategic opportunities.
        Treat this as a general industry outlook.
        """
        
        prompt = f"""
        {task_desc}

        While creating this document follow these instructions: {INDUSTRY_INSIGHTS_TEMPLATE_PROMPT}
        - Every metric includes: value + trend + context + implication
        - Every news item includes: what happened + why it matters + strategic impact
        - Every competitive point includes: who + how + evidence + impact on Verizon
        - Multi-paragraph development of each template bullet point
        ---
        
        Instrucntions for Final Report Generation:
        - You are generating a FINAL, EXECUTIVE-READY Industry Insights report.
        - Do NOT explain the task, prompt, or missing inputs.
        - Do NOT ask clarifying questions.
        - If information is missing, make reasonable industry-standard assumptions and proceed.
        - Never describe this output as a template, intake document, or prompt.
        - Response should be in Markdown with proper alignment and heading and subheading defined
        - Always Use Client name, topic when generating output (avoid using placeholders such as Client, Topic) instead fill with actual values

        ## Writing Style & Quality Standards
        - **Active voice preferred**
        - **Clear, direct language**
        - **Minimal jargon** (define when used)
        - **Maintain focus** on client name
        - **Source transparency**: Every data point must trace back to a named source
        ---

        Here is data received in external research/tools
        There are 3 parts to it:
         1. Outline
         2. SUPPORTING CONTEXT
         3. ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)
         
         {context_sections}

        ---

        Agent Data: Data which was retrieved from our internal agent system:
        Agent Data: {langgraph_context}

        -----
        ## Instructions for use of Agent Data:
        - Every factual claim in Agent Data MUST appear in your report with full context
        - For each data point: explain what it means, why it matters, and implications
        - Example: Don't write "Gross Profit: 2024 $80.880B" 
        Instead: "Verizon's gross profit reached $80.880B in 2024, representing a 2.2% increase from 2023's $79.169B. This upward trajectory suggests improving operational efficiency despite competitive pricing pressures in the wireless market, though margin analysis requires revenue data unavailable in this dataset."
        - Integrate financial metrics into narrative analysis, not just lists
        - Connect news items to strategic implications (don't just report headlines)
        - If conflicting information exists, prioritize the most recent and relevant data.
        

        ## Citations & References Section:
        - This section must contain ONLY the sources provided below
        - ALWAYS include all the citation links provided in the SUPPORTING CONTEXT under different categories
        - ALWAYS PROVIDE ALL THE CITATIONS MENTIONED IN AGENT DATA UNDER **Sources** OR ANY URL MENTIONED IN AGENT DATA.
        - Clearly distinguish between:
        • Connected/Internal Sources  
        • External Web Sources (side note: this data will have external websites links)
        - Do NOT merge these into a single undifferentiated list
        - If no sources are provided, OMIT the Citations & References section entirely
        - Do NOT explain why the section is omitted
        """

        return prompt
    
    async def industry_insights_prompt(self, user_prompt: str, clientname: str,audience_tone: Optional[str], word_limit: int, outline_doc: str = "",supporting_doc: str = "", agent_research_context: str ='',use_uploaded: bool = False,use_factiva: bool = True,use_external: bool = True) -> AsyncGenerator[str, None]:
        # Build unified citations + web content from multiple sources without overwriting
        effective_supporting_doc = supporting_doc if use_uploaded else ""
        system_prompt = self._build_prompt(
            clientname=clientname,
            audience_tone=audience_tone,
            word_limit=word_limit,
            outline_doc=outline_doc,
            supporting_doc=effective_supporting_doc,
            langgraph_context=agent_research_context,
            citations_text="",
            web_content=""
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            yield chunk
        
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"    
    
    async def execute(self, *args, **kwargs):
        """Execute draft content generation"""
        async for chunk in self.industry_insights_prompt(*args, **kwargs):
            yield chunk
    async def _build_unified_citations(self, clientname: str, max_web_results: int = 5, fetch_content: bool = True) -> tuple[str, str]:
        all_citations = []
        citation_number = 1
        web_content = ""
        # Add web search sources
        logger.info(f"[CITATIONS] Performing web search for: {clientname} (fetch_content={fetch_content})")
        # Log the exact search query used for web search (helps debug empty queries)
        search_query = clientname.strip() if clientname else ""
        logger.info(f"[CITATIONS] search_query=" + (search_query or "<empty>"))
        
        web_search_data = await self.web_search_service.search_and_format(
            search_query,
            max_results=max_web_results,
            fetch_content=fetch_content
        )        
        if web_search_data['count'] > 0:
            logger.info(f"[CITATIONS] Adding {web_search_data['count']} web search sources to unified citations list (starting from #{citation_number})")
            web_citations_raw = web_search_data['formatted_citations'].strip().split('\n')
            for web_citation in web_citations_raw:
                if web_citation.strip():
                    citation_text = web_citation.strip()
                    if citation_text[0].isdigit() and '. ' in citation_text:
                        citation_text = citation_text.split('. ', 1)[1]
                    all_citations.append(f"{citation_number}. {citation_text}")
                    citation_number += 1
            web_content = web_search_data.get('web_content', '')
            if web_content:
                logger.info(f"[CITATIONS] Retrieved web content: {(web_content)} characters")
        else:
            logger.warning(f"[CITATIONS] No web search results found for topic: {clientname}")
        unified_citations = '\n'.join(all_citations)
        total_sources = citation_number - 1
        logger.info(f"[CITATIONS] Unified citations built: {total_sources} total sources (web content: {len(web_content)} chars)")
        logger.info(f"[CITATIONS] Unified Citations Text:\n{unified_citations}")
        return unified_citations, web_content
    