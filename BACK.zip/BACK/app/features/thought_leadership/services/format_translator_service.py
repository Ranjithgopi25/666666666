from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.podcast_service import PodcastService
from typing import Optional
import logging
import requests
import time
import json
import sys
from typing import Optional, Dict, Any
from app.core.config import get_settings

logger = logging.getLogger(__name__)

class FormatTranslatorService(BaseTLStreamingService):
    """Service for Format Translator workflow"""
    
    def __init__(self, llm_service):
        super().__init__(llm_service)
        self.podcast_service = PodcastService(llm_service)
    
    async def translate_format(
        self, 
        content: str, 
        source_format: str, 
        target_format: str,
        customization: Optional[str] = None,
        podcast_style: Optional[str] = None,
        speaker1_name: Optional[str] = None,
        speaker1_voice: Optional[str] = None,
        speaker1_accent: Optional[str] = None,
        speaker2_name: Optional[str] = None,
        speaker2_voice: Optional[str] = None,
        speaker2_accent: Optional[str] = None,
        word_limit: Optional[str] = None
    ):
        """Translate content between formats"""
        platform_specific_instructions = ""
        webarticle_specific_instructions = ""
        ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
- Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
- Do NOT mention any report, survey, whitepaper, or study unless it exists.
- If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
- Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
- **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

        # If translating to podcast, use the podcast service with audio generation
        if target_format.lower() == "webpage ready":
                print("Webpage Ready....")
                webarticle_specific_instructions = f"""
                You are a professional content writer.

                Create a polished, well-structured webpage article of 800-1000 words based ONLY on the uploaded document content provided below. The output MUST be clean HTML.

                STRICT RULES:
                - Use ONLY the content inside <document>…</document>.
                - Do NOT add information that is not present in the uploaded document.
                - No external sources, no hallucinations, no invented quotes, no added data.
                - Do NOT include citations or references.
                - Do NOT mention that this came from an uploaded document.
                - Output MUST be valid HTML (<html>, <head>, <body>, <h1>, <h2>, <p>, <ul>, <li>, etc.)
                {ANTI_FABRICATION_RULES}
                
                - No placeholders, no fake URLs, no meta tags unless present in the document.
                - You must NOT add transitions, new narrative flow, elaborations, or stylistic flourishes.
                - You must NOT introduce new explanations to “smooth” the text.
                - Every paragraph MUST correspond directly to content found in the uploaded document.
                - No creative rewriting. Only restructuring + reformatting allowed.
                - No new adjectives, examples, metaphors, or expansions.
                - If a detail does not explicitly appear in the document, you MUST NOT include it.
                - Do NOT add literary transitions (“however”, “in essence”, “in reality”, “ultimately”, etc.) unless they appear in the document.
                - Do NOT add stylistic storytelling or marketing tone.
                - Preserve the tone of the original document exactly.
                - Restrict yourself to extracting, restructuring, and lightly editing for clarity only.
                - No creative rephrasing. No added dramatic language.
                - Make sure the spacing should be 1px in between headings and paragraphs.
                - Make sure there is no gap at the start of output response.
                - Output RAW HTML ONLY. Do NOT wrap HTML tags inside <p> tags. Do NOT escape or stringify HTML.
                - Do NOT use Markdown. Do NOT format HTML as text. HTML tags must render as real elements.
                - Include exactly ONE <html>, ONE <head>, and ONE <body>. Never nest or repeat them.
                - If you output <html>, <head>, <body>, <style>, <h1>, <h2>, <p>, or <ul>, they must appear as real HTML tags, never inside another tag.
                - Apply ALL styling using inline `style` attributes on HTML elements. Do NOT use a <style> block.
                - REQUIRED INLINE STYLES (PALETTE COMPLIANT):
                    - <body style="font-family:Arial,Helvetica,sans-serif; line-height:1.6; max-width:900px; margin:0 auto; padding:24px; background-color:#FFFFFF; color:#295477;">
                    - <h1 style="font-size:32px; color:#D04A02; margin-bottom:1px;">
                    - <h2 style="font-size:22px; color:#4577C9; margin-bottom:1px;">
                    - <h3 style="font-size:18px; color:#299D8F; margin-bottom:1px;">
                    - <p style="font-size:15px; margin-top:0; margin-bottom:1px; color:#295477;">
                    - <ul style="padding-left:20px; margin-top:0; margin-bottom:1px; color:#295477;">

                - Never output <style>, <meta>, or CSS blocks. Inline styles ONLY.
                - ALLOWED COLOR PALETTE (USE ONLY THESE HEX CODES):
                    Primary: #D04A02, #EB8C00, #FFB600, #7D7D7D, #DEDEDE, #295477, #299D8F
                    Secondary: #4577C9, #00C6F7, #3DD5B0, #D93954, #657DFF, #E72B33
                    Neutral (from palette only): #FFFFFF, #F2F2F2, #E5E5E5, #CBCBCB, #B1B1B1
                - You MUST NOT use any color outside this palette.
                - You MAY add a <div> wrapper with inline style "border-bottom:1px solid #DEDEDE; padding-bottom:8px;" between major sections.

                ARTICLE STRUCTURE:
                - <h1>: A clear, engaging headline based on the document's topic.
                - Introduction: 2-3 sentences summarizing the main idea.
                - Body: Multiple logical <h2> sections, each containing short paragraphs (2-4 sentences).
                - Bullet points allowed ONLY if the document already suggests list-like information.
                - Keep the tone professional, clear, and informative.
                - <h2> and <h3> should reflect the document's themes.
                - End with a concise conclusion summarizing key insights.

                DOCUMENT CONTENT:
                <document>
                {content}
                </document>
                """

        if target_format.lower() == "podcast":
            async for chunk in self.podcast_service.generate_podcast_with_audio(
                content_text=content,
                style=podcast_style or "dialogue",
                customization=customization,
                references=None,
                speaker1_name=speaker1_name or "Host 1",
                speaker1_voice=speaker1_voice or "Male",
                speaker1_accent=speaker1_accent or "American",
                speaker2_name=speaker2_name or "Host 2",
                speaker2_voice=speaker2_voice or "Female",
                speaker2_accent=speaker2_accent or "American"
            ):
                yield chunk
            return
        
        # Detect platform from customization if it's a social media post
        platform_specific_instructions = ""
        if target_format.lower() in ["social media post", "social media"] and customization:
            customization_lower = customization.lower()
            if "x.com" in customization_lower or "twitter" in customization_lower:
                platform_specific_instructions = """
PLATFORM-SPECIFIC FORMAT: X.COM (TWITTER) TWEET
- Write in tweet format: concise, punchy, engaging
- Character limit awareness: Aim for 280 characters or less for optimal engagement (though content may be longer if word limit allows)
- Use short, impactful sentences
- Start with a hook: question, bold statement, or surprising fact
- Use line breaks strategically to create visual separation
- Include 1-3 relevant hashtags at the end (PwC-related or topic-specific)
- Use emojis very sparingly (1-2 max) and only if they add value
- Create urgency or curiosity to encourage engagement
- End with a call-to-action or thought-provoking question when appropriate
- Format: Single paragraph or 2-3 short paragraphs with line breaks
- Tone: Bold, direct, conversational while maintaining professionalism
"""
                
            elif "linkedin" in customization_lower:
                platform_specific_instructions = """
PLATFORM-SPECIFIC FORMAT: LINKEDIN PROFESSIONAL POST
- Write in LinkedIn post format: professional, insightful, value-driven
- Structure: Hook → Value proposition → Key insights → Call to action
- Use 3-5 short paragraphs (2-4 sentences each) for readability
- Start with a compelling hook: statistic, question, or bold insight
- Include professional insights and thought leadership perspective
- Use bullet points or numbered lists for key takeaways when appropriate
- Include 3-5 relevant hashtags at the end (mix of broad and niche)
- Use emojis sparingly (2-3 max) and only for visual breaks or emphasis
- End with engagement prompt: question, call-to-action, or invitation to discuss
- Format: Professional narrative with clear structure and scannable content
- Tone: Authoritative, collaborative, optimistic - full PwC brand voice
- Length: Typically 150-300 words for optimal engagement (adjust based on word limit)
"""
                
        
        system_prompt = f"""You are a PwC content format specialist with expertise in converting and enhancing content for different formats while maintaining precision, clarity, strict adherence to word limits, and full compliance with PwC brand standards.

                            1. WORD COUNT COMPLIANCE:
                            - If a word limit is specified, you MUST generate content that is EXACTLY within that limit.
                            - Count words carefully. Do not exceed or fall short of the limit.
                            - If the source text is longer than the limit, retain the most important insights, facts, and value-added elements.
                            - For LinkedIn outputs, the final content MUST be between 200 – 350 words.
                            - Content must be optimized for mobile reading with short paragraphs and clear white space.
                            - No paragraph may exceed approximately 3 lines when viewed on mobile.

                            2. EXECUTIVE AUTHORITY MANDATE (ADDED):
                            - Every output MUST articulate a clear, confident point of view.
                            - Lead with judgment, not summary or scene-setting.
                            - Write as a seasoned advisor drawing on experience and observed executive consensus.
                            - Avoid hedging language such as “many believe,” “it may be,” or “studies suggest.”
                            - State perspectives directly and calmly, as accepted good practice among informed leaders.

                            3. THOUGHT LEADERSHIP SHAPE (MANDATORY FOR SOCIAL / LINKEDIN FORMATS):
                            - This structure MUST ALWAYS be followed in the exact order listed below for LinkedIn and social posts.

                            - Opening perspective (1–2 lines):
                            A clear, experience-based assertion that immediately signals credibility.

                            - Why this matters now (2–4 lines):
                            Anchor relevance in leadership realities, market shifts, or observed practice.
                            Avoid urgency theater or hype.

                            - What good looks like:
                            Articulate what effective leaders and organizations are doing or aiming toward.
                            Focus on synthesis and judgment, not explanation.

                            - Selective reinforcement:
                            Include a concrete example, observed pattern, or high-level data point ONLY if it strengthens credibility.
                            Use no more than one example or data point.
                            Do NOT use report-style evidence, statistics lists, or research framing.

                            - Forward-looking orientation:
                            Close with a steady, confidence-building view of what leaders should focus on next.
                            Reinforce direction and trust, not debate or provocation.

                            This is NOT a marketing announcement, tactical explainer, or promotional post.

                            4. POST FORMAT (for Social Media, Webpage, Placemat formats):
                            - Write in a POST format, never conversational or influencer-style.
                            - Use clear, direct, high-impact language.
                            - Maintain focus on a single core leadership issue.
                            - Avoid engagement bait, hype, or urgency signaling.
                            - Do NOT use emojis for executive thought leadership posts.
                            - If hashtags are used for LinkedIn, limit to a maximum of 2–3.
                            - Hashtags must be broad and reputational, placed only at the end.

                            {platform_specific_instructions}
                            {ANTI_FABRICATION_RULES}
                            {webarticle_specific_instructions}

                            5. CONTENT DEPTH & JUDGMENT:
                            - Avoid generic or explanatory statements.
                            - Assume executive familiarity with strategy, technology, operating models, and market dynamics.
                            - Do NOT explain fundamentals or define basic terms.
                            - Synthesize insight; do not list features, steps, or methodologies.
                            - Do NOT invent statistics, case studies, or research findings.
                            - Do NOT use phrases such as “studies show,” “research indicates,” “experts say,” or “many believe.”
                            - Do NOT write in a report, survey, or whitepaper tone.
                            - Every paragraph must be clearly relevant to C-suite leaders, board members, or enterprise decision-makers.
                            - If a paragraph does not materially matter to these audiences, it must be rewritten or removed.

                            6. ACTIONABILITY DISCIPLINE (REFINED):
                            - For senior-leader posts, prioritize orientation over instruction.
                            - Avoid step-by-step guidance, “how-to” language, or operational detail.
                            - Actionability should come from clarity of thinking, not tactical advice.

                            7. PwC BRAND VOICE & TONE (MANDATORY):
                            Apply all three simultaneously:
                            - Bold: Decisive, concise, judgment-led.
                            - Collaborative: Use “we/our” and “you/your organization” where appropriate.
                            - Optimistic: Future-oriented, opportunity-focused, realistic and grounded.

                            8. TONE DISCIPLINE (ADDED):
                            - Calm, confident, measured, and assured.
                            - No hype language, emotional appeals, or exaggerated future claims.
                            - Write to reinforce trust, not to attract attention.
                            - Do NOT include influencer-style storytelling or personal anecdotes.
                            - Do NOT list features, capabilities, solutions, or methodologies.
                            - Do NOT provoke debate or include attention-seeking closing questions.

                            9. STRUCTURE & FLOW:
                            - Ensure a logical executive narrative arc.
                            - Every paragraph must reinforce credibility or clarify the perspective.
                            - Remove filler, repetition, or descriptive padding.

                            10. CONTENT PRESERVATION & SYNTHESIS:
                            - Preserve the core intent and major themes of the source content.
                            - Elevate the material from explanation to executive judgment.
                            - Clarify what matters most; deprioritize secondary detail.
                            - Preserve all factual content exactly unless it violates editorial rules.

                            11. COPY, LINE, AND LEGAL STANDARDS:
                            (All existing PwC copy, legal, China & territories, and editorial rules apply unchanged.)

                            12. PARAGRAPH LENGTH DISCIPLINE (MANDATORY):
                            - Paragraphs must be short and visually separated.
                            - No paragraph may exceed ~3 lines when viewed on a standard mobile screen.
                            - Enforce hard paragraph breaks to preserve white space.
                            - If a thought exceeds this length, it MUST be split into multiple paragraphs.


                            13. OUTPUT FORMAT:
                            - Output ONLY the final content—no explanations or metadata.
                            - Begin directly with the rewritten post.
                            - The result must read credibly as something a PwC Senior Partner would publish under their own name.

                            14. SELF-VERIFICATION (MANDATORY):
                            Before finalizing, verify that:
                            - The opening establishes authority immediately.
                            - The perspective reflects mature, experience-based judgment.
                            - Nothing sounds promotional, tactical, speculative, or attention-seeking.
                            - Every paragraph reinforces senior executive orientation.
                            - The post would read credibly as something a PwC Senior Partner would publish on LinkedIn.

                            If any condition fails, revise before responding.
                            """
        
#         system_prompt = f"""You are a PwC content format specialist with expertise in converting and enhancing content for different formats while maintaining precision, clarity, strict adherence to word limits, and full compliance with PwC brand standards.

# CRITICAL RULES:

# 1. WORD COUNT COMPLIANCE:
#    - If a word limit is specified, you MUST generate content that is EXACTLY within that limit.
#    - Count words carefully. Do not exceed or fall short of the limit.
#    - If the source text is longer than the limit, retain the most important insights, facts, and value-added elements.

# 2. POST FORMAT (for Social Media, Webpage, Placemat formats):
#    - Write in a POST format, never conversational.
#    - Use clear, direct, high-impact language.
#    - Structure the post with logical flow, coherence, and scannable paragraphs.
#    - Maintain focus on a single core topic; avoid drifting into unrelated high-level concepts.
#    - Include relevant hashtags (for social formats).
#    - Use emojis sparingly and only when appropriate for readability and tone.
#    - Ensure the content is engaging, shareable, and suitable for a professional audience.
# {platform_specific_instructions}
# {webarticle_specific_instructions}
# 3. CONTENT DEPTH & SPECIFICITY:
#    - Avoid generic or shallow statements. Add clarity, specificity, and meaningful detail.
#    - **STRENGTHEN CORE FOCUS:** Make the main theme the central, prominent focus of the content. Lead with the core topic and ensure it's emphasized throughout, not buried in high-level generalities. The post should clearly emphasize the main theme rather than staying broad and high-level.
#    - **INCLUDE CONCRETE EXAMPLES:** When possible, include 1-2 specific, real-world examples, statistics, or outcomes from the source content to enhance credibility and relatability. Prioritize concrete details over generic statements. Include concrete examples, brief data points, or illustrative facts to strengthen credibility.
#    - Highlight distinctive elements (technical details, mechanisms, processes, or human elements) to enhance originality and insight.
#    - Ensure the narrative stays tightly aligned with the main theme of the source content.
#    - **CRITICAL: Do NOT invent statistics, percentages, dates, case studies, or research findings. If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").**

# 3a. ACTIONABLE TAKEAWAYS & PRACTICAL GUIDANCE:
#    - Include clear, actionable takeaways that provide practical value to professionals.
#    - When appropriate, add simple, practical steps such as:
#      * A recommended starting point or first step
#      * A quick win or immediate action item
#      * A recommended practice or approach
#    - Make the content useful for professionals who want guidance, not just information.
#    - Structure takeaways clearly (e.g., bullet points, numbered steps, or a dedicated section) when the format allows.

# 4. STRUCTURE & FLOW:
#    - Present information in a logical sequence instead of listing disconnected ideas.
#    - Ensure smooth transitions between sections or themes.
#    - If the original text lacks structure, reorganize it into a clear, professional, and cohesive flow.

# 5. PwC BRAND VOICE & TONE (MANDATORY):
#    **You MUST apply all three voice characteristics simultaneously:**
   
#    **Bold:**
#    - Use decisive, assertive language; remove soft qualifiers.
#    - Cut jargon and filler; keep sentences tight.
#    - Use short, direct sentences.
#    - Use rhythm and emphasis through structure, not exclamation marks.
   
#    **Collaborative:**
#    - Use "we/our/us" not "PwC" for the firm.
#    - Use "you/your organization" not "clients".
#    - Use conversational tone with contractions (in most marketing, digital, internal, thought leadership content).
#    - Write conversationally to emphasize partnership.
   
#    **Optimistic:**
#    - Prefer active voice.
#    - Future-forward, outcome-focused.
#    - Use action verbs: transform, unlock, accelerate, adapt, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transition, etc.
#    - Show opportunity beyond challenge.
#    - Use positive but realistic language supported by data.

# 6. PwC PROHIBITED TERMS & STYLE:
#    - **DO NOT use:**
#      - "catalyst" or "catalyst for momentum" → use "driver", "enabler", "accelerator".
#      - "PwC Network" → "PwC network" (lowercase n).
#      - "clients" when "you/your organization" works.
#      - ALL CAPS for emphasis (only for acronyms).
#      - Exclamation marks in headlines, subheads, or body copy.

# 7. CHINA & TERRITORIES (LEGAL – STRICT):
#    **Correct usage:**
#    - "PwC China" (not "PwC China/Hong Kong").
#    - "Hong Kong SAR", "Macau SAR".
#    - "Chinese Mainland" (not "Mainland China").
#    - Office references: "PwC China, Beijing Office", "PwC China, Hong Kong Office", etc.
#    - Use "PwC China", "PwC Hong Kong", "PwC Macau" when referring to a single territory.
#    - Use "Countries/Regions" or "Countries and Regions" where appropriate.
   
#    **Prohibited usage:**
#    - "PwC China/Hong Kong" or variants.
#    - "Mainland China" → use "Chinese Mainland".
#    - "Greater China" (external use).
#    - "PRC" (external use).

# 8. PwC BRAND VOCABULARY (INFUSE, DON'T FORCE):
#    **Movement words (examples):**
#    adapt, break through, disrupt, evolve, modernize, reconfigure, redefine, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transform, transition, unlock.
   
#    **Energy words (examples):**
#    act decisively, agile, anticipate, build, create, deliver, fast-track, forward-thinking, lay foundations, lead, move forward, navigate, propel, spot, surge.
   
#    **Pace / outcome words (examples):**
#    achieve, act, capitalize, drive, embrace resilience, further/faster, seize, accelerate progress, breakthrough results, build trust, gain competitive advantage, unlock value.
   
#    Use combinations that feel natural and on-brand.

# 9. COPY EDITOR STANDARDS:
#    - **Spelling:** Use American English (-ize/-yze, -or, -er, -se nouns, -eled/-aling).
#    - **Capitalization:** Use sentence case for headlines/subheads; capitalize proper nouns only.
#    - **Numbers:** Spell out one to ten (unless with million/billion); use numerals for 11+.
#    - **Percentages:** Always numerals + "%", no space ("5%", not "five percent").
#    - **Dates:** US format: "December 31, 2025"; no ordinals.
#    - **Commas:** Always use Oxford comma in three-item lists.
#    - **Ampersands:** Write "and" instead of &/+ except in proper names, PwC offerings (Audit & Assurance, Tax & Legal), or space-limited contexts.
#    - **Bullets:** Capitalize first word; use period only if bullet is a complete sentence.

# 10. LINE EDITOR STANDARDS:
#     - **Active voice:** Prefer active voice; convert passive where possible.
#     - **Sentence length:** One clear idea per sentence; break long sentences into shorter ones.
#     - **Point of view:** Use "we/our/us" for the firm when appropriate; use "you/your" to address the reader.
#     - **Gender neutrality:** Use "they" for unspecified individuals; avoid gendered nouns.
#     - **Fewer vs less:** Fewer = countable; Less = uncountable.
#     - **Corporate singularity:** PwC and teams take singular verbs ("PwC is...", "The team has...").

# 11. CONTENT PRESERVATION & ENHANCEMENT:
#     - Preserve the core message, insights, and intent of the original source text.
#     - **CRITICAL: Preserve ALL major themes and key concepts from the source content.** Do not omit important themes such as team resilience, continuous improvement practices, leadership roles, learning culture, psychological safety, or practical examples (e.g., feedback cycles, process reviews, knowledge sharing). The output must adequately represent the depth and intent of the original piece.
#     - Improve precision, coherence, and impact where the original is vague or high-level.
#     - Do not add new information that changes factual meaning, but you may clarify or refine concepts to increase quality.
#     - **CRITICAL: Preserve all factual content exactly (company names, numbers, statistics, proper nouns) unless they violate editorial rules.**

# 12. OUTPUT FORMAT:
#     - Output ONLY the converted content—no explanations, no metadata, no reasoning.
#     - Do NOT include headings like "Final Output" or "Translation."
#     - Do NOT repeat or quote the original text.
#     - Begin directly with the rewritten content ready for publishing.
#     - Do NOT include word counts, source information, or explanatory text.

# Remember:
# Your output must be polished, high-quality, deeply aligned to the core topic, EXACTLY within the specified word count, and fully compliant with PwC brand voice (Bold + Collaborative + Optimistic), terminology, and style guidelines."""
        
        # Build word limit instruction if provided
        word_limit_instruction = ""
        if word_limit and word_limit.strip():
            try:
                limit_num = int(word_limit.strip())
                word_limit_instruction = f"\n\nCRITICAL WORD LIMIT REQUIREMENT: The translated content MUST be EXACTLY {limit_num} words or less. You MUST count your words and ensure the final output does not exceed {limit_num} words. If the source content is longer, you MUST prioritize and condense to fit within {limit_num} words. The word count is non-negotiable - your output must be within this limit."
            except ValueError:
                logger.warning(f"[Format Translator] Invalid word limit format: {word_limit}")
        
        user_message = f"""Convert the following content:

Source Format: {source_format}
Target Format: {target_format}
{word_limit_instruction}

Content:
{content}

CRITICAL INSTRUCTIONS - READ CAREFULLY:
1. Output ONLY the converted content in the target format, fully compliant with PwC brand standards
2. Apply PwC voice (Bold + Collaborative + Optimistic) throughout the content
3. Ensure all PwC brand rules are followed (terminology, voice, style, prohibited terms)
4. Do NOT include ANY of the following:
   - Word counts (e.g., "Word Count: 189 words", "Since the content is already within the 200-word limit")
   - Source information (e.g., "Source Format:", "Target Format:")
   - Output word limits (e.g., "Output Word Limit: 200 words")
   - Explanatory text (e.g., "Here is the converted content:", "Here is the translation:", "Here is the rewritten response")
   - Notes about the translation process (e.g., "there is no need to prioritize", "can be directly translated")
   - "Key Takeaways:" sections or summary lists
   - The original source content
   - Any metadata, labels, or commentary
   - Any sentences that explain what you're doing or describe the translation

5. Start directly with the translated content - no introductions, no explanations, no notes, no markers
6. The first line of your output should be the actual translated content, not any explanatory text
7. Do NOT repeat or include the original source content in your output
8. Do NOT include "Key Takeaways" or summary sections
9. Ensure the content uses PwC brand voice: "we/our/us" for the firm, "you/your organization" for audience, active voice, and PwC brand vocabulary where natural

Begin your response with the translated content immediately. Do not include any text before it.{word_limit_instruction}"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        # Stream response normally - cleaning will happen in frontend
        # The improved prompt should prevent most metadata, but we'll also clean on frontend
        async for chunk in self.stream_response(messages):
            yield chunk
    
    async def execute(self, *args, **kwargs):
        async for chunk in self.translate_format(*args, **kwargs):
            yield chunk


class PlusDocsClient:
    """ for interacting with PlusDocs API"""

    def __init__(self, api_token: str):
        """
        Initialize the PlusDocs client
        Args:
            api_token: Bearer token for API authentication
        """
        settings = get_settings()
        self.api_token = api_token
        self.base_url = settings.PLUSDOC_BASE_URL
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_token}"
        }

    def create_presentation(self, prompt: str, numberOfSlides: int, template_id: str) -> Optional[str]:
        """
        Create a new presentation
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
        Returns:
            Presentation ID if successful, None otherwise
        """
        url = f"{self.base_url}/presentation"
        payload = {
            "prompt": prompt,
            "templateId": template_id,
            "numberOfSlides": numberOfSlides
        }

        try:
            print(f"Creating presentation with prompt: '{prompt}'")
            response = requests.post(url, headers=self.headers, json=payload)
            response.raise_for_status()

            data = response.json()
            presentation_id = data.get('id')

            if presentation_id:
                print(f"✓ Presentation created successfully!")
                print(f"  Presentation ID: {presentation_id}")
                return presentation_id
            else:
                print("✗ No presentation ID returned")
                return None

        except requests.exceptions.RequestException as e:
            print(f"✗ Error creating presentation: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"  Response: {e.response.text}")
            return None

    def get_presentation_status(self, presentation_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the status of a presentation
        Args:
            presentation_id: ID of the presentation to check
        Returns:
            Presentation data if successful, None otherwise
        """
        url = f"{self.base_url}/presentation/{presentation_id}"

        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            print(f"✗ Error getting presentation status: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"  Response: {e.response.text}")
            return None

    def poll_until_complete(
        self,
        presentation_id: str,
        poll_interval: int = 5,
        max_attempts: int = 60
    ) -> Optional[str]:
        """
        Poll the API until the presentation is complete
        Args:
            presentation_id: ID of the presentation to poll
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 60)
        Returns:
            Download URL if successful, None otherwise
        """
        print(f"\nPolling for completion (checking every {poll_interval}s)...")

        for attempt in range(1, max_attempts + 1):
            print(f"  Attempt {attempt}/{max_attempts}...", end=" ")

            data = self.get_presentation_status(presentation_id)
            if data is None:
                print("failed to get status")
                time.sleep(poll_interval)
                continue

            status = data.get('status', 'unknown')
            print(f"status: {status}")

            # Check if completed
            if status == 'GENERATED' or status == 'success':
                download_url = (
                    data.get('downloadUrl')
                    or data.get('download_url')
                    or data.get('url')
                )
                if download_url:
                    print(f"\n✓ Presentation completed successfully!")
                    return download_url
                else:
                    print(f"\n✓ Presentation completed but no download URL found")
                    print(f"  Full response: {json.dumps(data, indent=2)}")
                    return None

            # Check if failed
            if status in ['failed', 'error']:
                print(f"\n✗ Presentation generation failed")
                print(f"  Response: {json.dumps(data, indent=2)}")
                return None

            # Still processing
            time.sleep(poll_interval)

        print(f"\n✗ Timeout: Presentation did not complete after {max_attempts} attempts")
        return None

    def create_and_wait(
        self,
        prompt: str,
        numberOfSlides: int,
        template_id: str,
        poll_interval: int = 5,
        max_attempts: int = 60
    ) -> Optional[str]:
        """
        Create a presentation and wait for it to complete
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 60)
        Returns:
            Download URL if successful, None otherwise
        """
        presentation_id = self.create_presentation(prompt, numberOfSlides, template_id)
        if not presentation_id:
            return None

        return self.poll_until_complete(
            presentation_id,
            poll_interval,
            max_attempts
        )
