# ============================================================
# LangGraph orchestration for Refine Content
# ============================================================

from typing import Optional, Dict, Any, List, Literal
from pydantic import BaseModel, Field
import json

from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig

from app.utils.market_intelligence_agent.graph import get_market_insights


# ============================================================
# STATE
# ============================================================

class RefineGraphState(BaseModel):
    # -------- INPUT --------
    original_content: str
    services: Dict[str, Any]

    # -------- FLAGS --------
    is_expand: bool = False
    is_compress: bool = False
    apply_tone: bool = False
    apply_research: bool = False
    apply_edit: bool = False
    apply_suggestions: bool = False
    trim_applied: bool = False

    tone: Optional[str] = None

    # -------- TARGETS --------
    hard_target_word_count: Optional[int] = None
    grow_target_word_count: Optional[int] = None
    max_allowed_word_count: Optional[int] = None

    # -------- CONTENT --------
    cleaned_content: Optional[str] = None
    grown_content: Optional[str] = None
    final_output: Optional[str] = None
    suggestions: Optional[str] = None

    # -------- CONTEXT --------
    market_insights: Optional[str] = None

    # -------- METRICS --------
    current_word_count: Optional[int] = None
    retry_count: int = 0
    max_retries: int = 3

    # -------- CONTROL --------
    next_step: Optional[
        Literal[
            "SEMANTIC_CLEAN",
            "MARKET_INSIGHTS",
            "RESEARCH_ENRICH",
            "EXPAND_GROW",
            "TONE_ADJUST",
            "EDIT_SEQUENCE",
            "EXPAND_TRIM",
            "COMPRESS_ENFORCE",
            "VALIDATE",
            "SUGGESTIONS_ONLY",
            "COMPLETE",
            "FAIL",
        ]
    ] = "SEMANTIC_CLEAN"

    warnings: List[str] = Field(default_factory=list)

    class Config:
        extra = "forbid"


# ============================================================
# HELPERS
# ============================================================

def _get_latest_text(state: RefineGraphState) -> str:
    return (
        state.final_output
        or state.grown_content
        or state.cleaned_content
        or state.original_content
    )


# ============================================================
# PLANNER
# ============================================================

def planner_node(state: RefineGraphState):
    services = state.services
    target = int(services.get("requested_word_limit", 0))
    is_expand = bool(services.get("is_expand"))

    print(f"[PLANNER] Target={target}, Expand={is_expand}")

    updates = {
        "is_expand": is_expand,
        "is_compress": not is_expand,
        "apply_tone": bool(services.get("tone")),
        "apply_research": bool(services.get("research")),
        "apply_edit": bool(services.get("edit")),
        "apply_suggestions": bool(services.get("suggestions")),
        "tone": services.get("tone"),
        "hard_target_word_count": target,
        "next_step": "SEMANTIC_CLEAN",
    }

    if is_expand:
        updates.update(
            {
                "grow_target_word_count": int(target * 1.05),
                "max_allowed_word_count": int(target * 1.05),
            }
        )

    return updates


# ============================================================
# SEMANTIC CLEAN
# ============================================================

async def semantic_clean_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    messages = [
        {
            "role": "system",
            "content": (
                "You are a senior PwC editorial consultant.\n"
                "Clean grammar and improve clarity.\n"
                "Do NOT expand or compress.\n"
                "Do NOT change paragraph order or meaning."
            ),
        },
        {"role": "user", "content": state.original_content},
    ]

    cleaned = await llm.chat_completion(messages)
    wc = len(cleaned.split())

    print(f"[SEMANTIC_CLEAN] Completed | Words={wc}")

    return {
        "cleaned_content": cleaned,
        "current_word_count": wc,
        "next_step": "MARKET_INSIGHTS" if state.apply_research else (
            "EXPAND_GROW" if state.is_expand else "COMPRESS_ENFORCE"
        ),
    }


# ============================================================
# MARKET INSIGHTS
# ============================================================

def build_market_insights_input(services: dict) -> dict:
    """
    Adapt frontend-enhanced research config → market_insights graph input
    """

    return {
        # REQUIRED
        "research_topics": services.get("research_topics"),
        "research_guidelines": services.get("research_guidelines"),

        # PwC document path (optional)
        "pwc_content": {
            "isSelected": bool(services.get("pwc_research_doc")),
            "supportingDoc": services.get("pwc_research_doc"),
            "supportingDoc_instructions": services.get(
                "supporting_doc_instructions"
            ),
        },

        # Proprietary research (this is TRUE in your payload)
        "proprietary": {
            "isSelected": services.get("proprietary", {}).get("isSelected", False),
            "sources": services.get("proprietary", {}).get("sources", []),
        },

        # External research (TRUE in your payload)
        "externalResearch": {
            "isSelected": services.get("externalResearch", {}).get("isSelected", False)
        },
    }

async def market_insights_node(state: RefineGraphState, config: RunnableConfig):
    print("[MARKET_INSIGHTS] Fetching insights")
    print(json.dumps(state.services, indent=2))
    market_input = build_market_insights_input(state.services)
    print("[MARKET_INSIGHTS] Router input:", market_input)
    insights = get_market_insights(market_input)
    print("=================", json.dumps(insights, indent=2))
    return {
        "market_insights": json.dumps(insights, indent=2),
        "next_step": "RESEARCH_ENRICH",
    }


# ============================================================
# RESEARCH ENRICH
# ============================================================

async def research_enrich_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    print("[RESEARCH_ENRICH] Applying research grounding")

    research_block = ""

    if state.services.get("pwc_research_doc"):
        research_block += f"\nPWC RESEARCH:\n{state.services['pwc_research_doc']}"

    if state.market_insights:
        research_block += f"\nMARKET INSIGHTS:\n{state.market_insights}"

    messages = [
        {
            "role": "system",
            "content": (
                "Strengthen existing arguments using provided material ONLY.\n"
                "Do NOT add sections or reorder paragraphs.\n"
                "Do NOT invent facts."
            ),
        },
        {"role": "user", "content": state.cleaned_content + research_block},
    ]

    enriched = await llm.chat_completion(messages)
    wc = len(enriched.split())

    print(f"[RESEARCH_ENRICH] Completed | Words={wc}")

    return {
        "cleaned_content": enriched,
        "current_word_count": wc,
        "next_step": "EXPAND_GROW" if state.is_expand else "TONE_ADJUST",
    }


# ============================================================
# EXPAND — GROW
# ============================================================

async def expand_grow_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    print("[EXPAND_GROW] Expanding content")

    messages = [
        {
            "role": "system",
            "content": (
                f"Expand content to between {state.grow_target_word_count} "
                f"and {state.max_allowed_word_count} words.\n"
                "Deepen arguments, add examples, implications, and transitions.\n"
                "Use the research-backed content already present.\n"
                "Preserve all paragraphs and structure.\n"
                "Do NOT invent facts."
            ),
        },
        {
            "role": "user",
            "content": _get_latest_text(state),  # ✅ THIS IS THE FIX
        },
    ]

    grown = await llm.chat_completion(messages)
    wc = len(grown.split())

    print(f"[EXPAND_GROW] Completed | Words={wc}")

    if wc > state.max_allowed_word_count:
        return {
            "grown_content": grown,
            "current_word_count": wc,
            "next_step": "EXPAND_TRIM",
        }

    return {
        "grown_content": grown,
        "current_word_count": wc,
        "next_step": "TONE_ADJUST",
    }


# ============================================================
# TONE ADJUST
# ============================================================

async def tone_adjust_node(state: RefineGraphState, config: RunnableConfig):
    if not state.apply_tone:
        return {"next_step": "EDIT_SEQUENCE"}

    llm = config["configurable"]["llm_service"]

    print(f"[TONE_ADJUST] Applying tone: {state.tone}")

    messages = [
        {
            "role": "system",
            "content": (
                f"Rewrite in '{state.tone}' tone.\n"
                "Preserve meaning, structure, and length."
            ),
        },
        {"role": "user", "content": _get_latest_text(state)},
    ]

    toned = await llm.chat_completion(messages)
    wc = len(toned.split())

    print(f"[TONE_ADJUST] Completed | Words={wc}")

    return {
        "cleaned_content": toned,
        "current_word_count": wc,
        "next_step": "EDIT_SEQUENCE",
    }


# ============================================================
# EDIT
# ============================================================

async def edit_sequence_node(state: RefineGraphState, config: RunnableConfig):
    if not state.apply_edit:
        return {"next_step": "VALIDATE"}

    llm = config["configurable"]["llm_service"]

    print("[EDIT_SEQUENCE] Editing content")

    messages = [
        {
            "role": "system",
            "content": "Improve clarity and grammar. Do NOT add or remove content.",
        },
        {"role": "user", "content": _get_latest_text(state)},
    ]

    edited = await llm.chat_completion(messages)
    wc = len(edited.split())

    print(f"[EDIT_SEQUENCE] Completed | Words={wc}")

    return {
        "final_output": edited,
        "current_word_count": wc,
        "next_step": "VALIDATE",
    }


# ============================================================
# COMPRESS — ENFORCE (STRICT)
# ============================================================

async def compress_enforce_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    print(f"[COMPRESS] Enforcing compression → {state.hard_target_word_count} words")

    messages = [
        {
            "role": "system",
            "content": (
                f"Compress to EXACTLY {state.hard_target_word_count} words.\n"
                "Word count is NON-NEGOTIABLE.\n"
                "Remove redundancy and secondary examples.\n"
                "Do NOT add content.\n"
                "Output ONLY the compressed content."
            ),
        },
        {"role": "user", "content": _get_latest_text(state)},
    ]

    compressed = await llm.chat_completion(messages)
    wc = len(compressed.split())

    print(f"[COMPRESS] Result | Words={wc}")

    return {
        "final_output": compressed,
        "current_word_count": wc,
        "next_step": "VALIDATE",
    }


# ============================================================
# EXPAND — TRIM
# ============================================================

async def expand_trim_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    print("[EXPAND_TRIM] Trimming overshoot")

    messages = [
        {
            "role": "system",
            "content": f"Reduce to EXACTLY {state.hard_target_word_count} words.",
        },
        {"role": "user", "content": _get_latest_text(state)},
    ]

    trimmed = await llm.chat_completion(messages)
    wc = len(trimmed.split())

    print(f"[EXPAND_TRIM] Completed | Words={wc}")

    return {
        "final_output": trimmed,
        "current_word_count": wc,
        "trim_applied": True,
        "next_step": "VALIDATE",
    }


# ============================================================
# VALIDATE (HARD GATE)
# ============================================================

def validate_node(state: RefineGraphState):
    wc = len(_get_latest_text(state).split())
    target = state.hard_target_word_count

    print(f"[VALIDATE] Words={wc} | Target={target} | Retry={state.retry_count}")

    if wc == target:
        print("[VALIDATE] ✅ Target achieved", flush=True)
        return {
            "next_step": "SUGGESTIONS_ONLY"
            if state.apply_suggestions
            else "COMPLETE"
        }
    
    # 🔁 Expand failed to reach target → retry grow
    if state.is_expand and wc < target and state.retry_count < state.max_retries:
        print("[VALIDATE] 🔁 Expand under target → retry grow")
        return {
            "retry_count": state.retry_count + 1,
            "next_step": "EXPAND_GROW",
        }

    if state.is_expand and wc > target and not state.trim_applied:
        print("[VALIDATE] 🔁 Expand overshoot → TRIM")
        return {"next_step": "EXPAND_TRIM"}

    if state.is_compress and wc > target:
        if state.retry_count >= state.max_retries:
            print("[VALIDATE] ❌ Compression failed")
            return {
                "warnings": [f"Compression ended at {wc} words (target {target})"],
                "next_step": "FAIL",
            }

        print("[VALIDATE] 🔁 Retrying compression")
        return {
            "retry_count": state.retry_count + 1,
            "next_step": "COMPRESS_ENFORCE",
        }

    if state.is_expand and state.retry_count >= state.max_retries:
        print("[VALIDATE] Expansion max retries reached — accepting best effort")
        return {
            "warnings": [f"Expansion ended at {wc} words (target {target})"],
            "final_output": _get_latest_text(state),
            "next_step": "SUGGESTIONS_ONLY"
            if state.apply_suggestions
            else "COMPLETE",
        }

    return {
        "warnings": [f"Unexpected state at {wc} words"],
        "next_step": "FAIL",
    }


# ============================================================
# SUGGESTIONS
# ============================================================

async def suggestions_node(state: RefineGraphState, config: RunnableConfig):
    llm = config["configurable"]["llm_service"]

    print("[SUGGESTIONS] Generating PwC feedback")

    messages = [
        {
            "role": "system",
            "content": (
                "Provide improvement suggestions ONLY.\n"
                "Do NOT rewrite content."
            ),
        },
        {"role": "user", "content": state.final_output},
    ]

    suggestions = await llm.chat_completion(messages)
    return {"suggestions": suggestions}


# ============================================================
# BUILD GRAPH
# ============================================================

def build_refine_graph():
    graph = StateGraph(RefineGraphState)

    graph.add_node("PLANNER", planner_node)
    graph.add_node("SEMANTIC_CLEAN", semantic_clean_node)
    graph.add_node("MARKET_INSIGHTS", market_insights_node)
    graph.add_node("RESEARCH_ENRICH", research_enrich_node)
    graph.add_node("EXPAND_GROW", expand_grow_node)
    graph.add_node("EXPAND_TRIM", expand_trim_node)
    graph.add_node("COMPRESS_ENFORCE", compress_enforce_node)
    graph.add_node("TONE_ADJUST", tone_adjust_node)
    graph.add_node("EDIT_SEQUENCE", edit_sequence_node)
    graph.add_node("VALIDATE", validate_node)
    graph.add_node("SUGGESTIONS_ONLY", suggestions_node)

    graph.set_entry_point("PLANNER")

    graph.add_edge("PLANNER", "SEMANTIC_CLEAN")
    graph.add_edge("MARKET_INSIGHTS", "RESEARCH_ENRICH")
    graph.add_edge("RESEARCH_ENRICH", "EXPAND_GROW")
    graph.add_edge("EXPAND_GROW", "TONE_ADJUST")
    graph.add_edge("TONE_ADJUST", "EDIT_SEQUENCE")
    graph.add_edge("EDIT_SEQUENCE", "VALIDATE")
    graph.add_edge("EXPAND_TRIM", "VALIDATE")
    graph.add_edge("COMPRESS_ENFORCE", "VALIDATE")
    graph.add_edge("SUGGESTIONS_ONLY", END)

    graph.add_conditional_edges(
        "SEMANTIC_CLEAN",
        lambda s: s.next_step,
        {
            "MARKET_INSIGHTS": "MARKET_INSIGHTS",
            "EXPAND_GROW": "EXPAND_GROW",
            "COMPRESS_ENFORCE": "COMPRESS_ENFORCE",
        },
    )

    graph.add_conditional_edges(
        "VALIDATE",
        lambda s: s.next_step,
        {
            "EXPAND_GROW": "EXPAND_GROW",
            "EXPAND_TRIM": "EXPAND_TRIM",
            "COMPRESS_ENFORCE": "COMPRESS_ENFORCE",
            "SUGGESTIONS_ONLY": "SUGGESTIONS_ONLY",
            "COMPLETE": END,
            "FAIL": END,
        },
    )

    return graph.compile()


# ============================================================
# PUBLIC API
# ============================================================

async def run_refine_content_graph(*, original_content, services, llm_service):
    graph = build_refine_graph()

    state = RefineGraphState(
        original_content=original_content,
        services=services,
    )

    result = await graph.ainvoke(
        state,
        config={"configurable": {"llm_service": llm_service}},
    )

    return {
        "content": result.get("final_output"),
        "suggestions": result.get("suggestions"),
        "word_count": result.get("current_word_count"),
        "warnings": result.get("warnings", []),
        "success": result.get("next_step") == "COMPLETE",
    }
