"""
Service layer for chat history business logic.
Provides high-level operations for managing chat sessions and conversations.
"""
import json
import uuid
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

from app.repositories.chat_history_repository import ChatHistoryRepository
from app.models.chat_history import ChatHistory

logger = logging.getLogger(__name__)


class ChatHistoryService:
    """
    Service for managing chat history with business logic.
    Handles conversation serialization, validation, and orchestration.
    One session = one conversation stored as a single record.
    """
    
    def __init__(self, repository: ChatHistoryRepository):
        """
        Initialize service with repository.
        
        Args:
            repository: ChatHistoryRepository instance
        """
        self.repository = repository
        logger.info("ChatHistoryService initialized")
    
    def create_new_chat_session(
        self,
        user_id: uuid.UUID,
        session_id: str,
        source: str,
        initial_content: Optional[str] = None,
        user_email: Optional[str] = None,
        title: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new chat session.
        
        Args:
            user_id: User identifier (UUID)
            session_id: Session identifier (simple string, not UUID)
            source: Source of conversation (DDDC, Market_Intelligence, Thought_Leadership, Export, Chat)
            initial_content: Optional initial user message
            user_email: Optional user email for creating user record
            title: Optional session title
            
        Returns:
            Dictionary with session_id and initial conversation data
        """
        try:
            # Validate source
            valid_sources = ['DDDC', 'Market_Intelligence', 'Thought_Leadership', 'Export', 'Chat']
            if source not in valid_sources:
                raise ValueError(f"Invalid source: {source}. Must be one of {valid_sources}")
            
            initial_message = None
            if initial_content:
                initial_message = {
                    "role": "user",
                    "content": initial_content
                }
            
            chat_history = self.repository.create_session(
                session_id=session_id,
                user_id=user_id,
                source=source,
                initial_message=initial_message,
                user_email=user_email,
                title=title
            )
            
            conversation = json.loads(chat_history.conversation)
            
            return {
                "session_id": chat_history.session_id,
                "source": chat_history.source,
                "title": chat_history.title,
                "conversation": conversation,
                "created_at": chat_history.created_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error creating chat session: {str(e)}")
            raise
    
    def add_message_to_session(
        self,
        session_id: str,
        role: str,
        content: str
    ) -> Dict[str, Any]:
        """
        Add a message to an existing session.
        
        Args:
            session_id: Session identifier
            role: Message role (user, assistant, system)
            content: Message content
            
        Returns:
            Updated conversation data
        """
        try:
            message = {
                "role": role,
                "content": content
            }
            
            chat_history = self.repository.append_message(session_id, message)
            conversation = json.loads(chat_history.conversation)
            
            return {
                "session_id": chat_history.session_id,
                "conversation": conversation,
                "updated_at": chat_history.updated_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error adding message to session {session_id}: {str(e)}")
            raise
    
    def add_message_to_session_or_create(
        self,
        session_id: str,
        role: str,
        content: str,
        user_id: Optional[uuid.UUID] = None,
        source: str = "Chat",
        user_email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Add a message to an existing session, or create session if not found.
        Used by streaming responses to handle cases where frontend sends messages before session creation.
        
        Args:
            session_id: Session identifier
            role: Message role (user, assistant, system)
            content: Message content
            user_id: User UUID (required if creating new session)
            source: Source of conversation (required if creating new session)
            user_email: Optional user email for user creation
            
        Returns:
            Updated or newly created conversation data
        """
        try:
            message = {
                "role": role,
                "content": content
            }
            
            chat_history = self.repository.append_message_or_create(
                session_id=session_id,
                message=message,
                user_id=user_id,
                source=source,
                user_email=user_email
            )
            conversation = json.loads(chat_history.conversation)
            
            return {
                "session_id": chat_history.session_id,
                "conversation": conversation,
                "updated_at": chat_history.updated_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error adding/creating message for session {session_id}: {str(e)}")
            raise
    
    def get_session_conversation(
        self,
        session_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Retrieve full conversation for a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Conversation data or None if not found
        """
        try:
            chat_history = self.repository.get_session_by_id(session_id)
            
            if not chat_history:
                return None
            
            conversation = json.loads(chat_history.conversation)
            
            logger.info(f"🔍 Retrieved session {session_id}")
            logger.info(f"   Conversation type: {type(conversation)}")
            logger.info(f"   Conversation keys/length: {list(conversation.keys()) if isinstance(conversation, dict) else f'Array length: {len(conversation)}'}")
            logger.info(f"   First 200 chars: {str(conversation)[:200]}")
            
            return {
                "session_id": chat_history.session_id,
                "source": chat_history.source,
                "title": chat_history.title,
                "conversation": conversation,
                "created_at": chat_history.created_at.isoformat(),
                "updated_at": chat_history.updated_at.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error retrieving session {session_id}: {str(e)}")
            raise
    
    def list_user_sessions(
        self,
        user_id: uuid.UUID
    ) -> List[Dict[str, Any]]:
        """
        List all chat sessions for a user.
        
        Args:
            user_id: User identifier
            
        Returns:
            List of session summaries
        """
        try:
            sessions = self.repository.get_user_sessions(user_id)
            
            result = []
            for session in sessions:
                conversation_str = session.get('conversation', '{}')
                conversation = json.loads(conversation_str) if isinstance(conversation_str, str) else conversation_str
                messages = conversation.get("messages", [])
                
                # Get preview from first or last message
                preview = session.get('title') or ""
                if not preview and messages:
                    first_msg = messages[0].get("content", "")
                    preview = first_msg[:100] + "..." if len(first_msg) > 100 else first_msg
                
                created_at = session.get('created_at')
                updated_at = session.get('updated_at')
                
                # Convert datetime to ISO string if needed
                if created_at and hasattr(created_at, 'isoformat'):
                    created_at = created_at.isoformat()
                if updated_at and hasattr(updated_at, 'isoformat'):
                    updated_at = updated_at.isoformat()
                
                result.append({
                    "session_id": session.get('session_id'),
                    "source": session.get('source'),
                    "title": session.get('title'),
                    "preview": preview,
                    "message_count": len(messages),
                    "created_at": created_at,
                    "updated_at": updated_at
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Error listing sessions for user {user_id}: {str(e)}", exc_info=True)
            raise
    
    def list_user_sessions_by_email(
        self,
        user_email: str
    ) -> List[Dict[str, Any]]:
        """
        List all chat sessions for a user by email address.
        Queries ChatHistory table directly using user_email field.
        
        Args:
            user_email: User email address
            
        Returns:
            List of session summaries
        """
        try:
            logger.info(f"[ChatHistoryService] Listing sessions by email: {user_email}")
            # Get sessions directly by email from ChatHistory table
            sessions = self.repository.get_user_sessions_by_email(user_email)
            
            logger.info(f"[ChatHistoryService] Found {len(sessions)} sessions for email {user_email}")
            
            result = []
            for session in sessions:
                conversation_str = session.get('conversation', '{}')
                conversation = json.loads(conversation_str) if isinstance(conversation_str, str) else conversation_str
                messages = conversation.get("messages", [])
                
                # Get preview from first or last message
                preview = session.get('title') or ""
                if not preview and messages:
                    first_msg = messages[0].get("content", "")
                    preview = first_msg[:100] + "..." if len(first_msg) > 100 else first_msg
                
                created_at = session.get('created_at')
                updated_at = session.get('updated_at')
                
                # Convert datetime to ISO string if needed
                if created_at and hasattr(created_at, 'isoformat'):
                    created_at = created_at.isoformat()
                if updated_at and hasattr(updated_at, 'isoformat'):
                    updated_at = updated_at.isoformat()
                
                result.append({
                    "session_id": session.get('session_id'),
                    "source": session.get('source'),
                    "title": session.get('title'),
                    "preview": preview,
                    "message_count": len(messages),
                    "created_at": created_at,
                    "updated_at": updated_at
                })
            
            logger.info(f"[ChatHistoryService] Returning {len(result)} session summaries for email {user_email}")
            return result
            
        except Exception as e:
            logger.error(f"Error listing sessions by email {user_email}: {str(e)}", exc_info=True)
            raise
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a chat session (soft delete).
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if deleted, False if not found
        """
        try:
            return self.repository.delete_session(session_id)
        except Exception as e:
            logger.error(f"Error deleting session {session_id}: {str(e)}")
            raise
    
    def format_messages_for_llm(self, session_id: str) -> List[Dict[str, str]]:
        """
        Get conversation history formatted for LLM context.
        Returns only role and content fields.
        
        Args:
            session_id: Session identifier
            
        Returns:
            List of messages with role and content only
        """
        try:
            conversation_data = self.get_session_conversation(session_id)
            
            if not conversation_data:
                return []
            
            messages = conversation_data.get("conversation", {}).get("messages", [])
            
            # Format for LLM (only role and content)
            return [
                {"role": msg.get("role"), "content": msg.get("content")}
                for msg in messages
                if msg.get("role") and msg.get("content")
            ]
            
        except Exception as e:
            logger.error(f"Error formatting messages for LLM from session {session_id}: {str(e)}")
            raise
