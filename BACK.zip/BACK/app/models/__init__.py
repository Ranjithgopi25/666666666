"""
Database models for the application.
"""
from app.models.chat_history import User, ChatHistory

__all__ = ["User", "ChatHistory"]
