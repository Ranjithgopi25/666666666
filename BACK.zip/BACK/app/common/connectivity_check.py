"""
Connectivity checker API for external services.
"""

import logging
import os
from typing import Dict, Any
from fastapi import APIRouter
from app.core.config import get_connectivity_config, get_settings

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Connectivity"])

# Load configuration from environment variables
CONNECTIVITY_CONFIG = get_connectivity_config()

def get_sql_connection_string(config: dict) -> str:
    return (
        f"DRIVER={config['driver']};"
        f"SERVER={config['server']};"
        f"DATABASE={config['database']};"
        f"UID={config['username']};"
        f"PWD={config['password']};"
        "Encrypt=yes;"
        "TrustServerCertificate=yes;"
        "HostNameInCertificate=*.database.windows.net;"
        "LoginTimeout=60;"
        "ConnectionTimeout=60;"
    )

def check_tavily_connection(config: dict) -> Dict[str, Any]:
    """Check Tavily API connection."""
    try:
        from tavily import TavilyClient
    except ImportError:
        return {"status": "error", "message": "tavily-python package not installed", "stable": False}
 
    try:
        client = TavilyClient(config["api_key"])
        response = client.search(query="test")
        if response:
            return {"status": "success", "message": "Tavily API connection successful", "stable": True}
        return {"status": "failed", "message": "No response from Tavily API", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_azure_blob_connection(config: dict) -> Dict[str, Any]:
    """Check Azure Blob Storage connectivity and list up to 50 containers."""
    try:
        from azure.storage.blob import BlobServiceClient
        from azure.core.exceptions import ResourceNotFoundError
    except ImportError:
        return {
            "status": "error",
            "message": "azure-storage-blob package not installed",
            "stable": False,
        }

    try:
        blob_service_client = BlobServiceClient.from_connection_string(
            config["connection_string"],
            connection_verify=False
        )

        # Verify account connection
        account_info = blob_service_client.get_account_information()
        
        # List containers
        container_names = []
        for i, container in enumerate(blob_service_client.list_containers()):
            if i >= 50:
                break
            container_names.append(container["name"])

        return {
            "status": "success",
            "message": f"Azure Blob Storage connection successful ({config['account_name']})",
            "stable": True,
            "containers": container_names,
            "container_count": len(container_names),
            "container_limit": 50,
            "account_info": str(account_info)
        }

    except ResourceNotFoundError as e:
        return {
            "status": "failed",
            "message": f"Resource not found: {str(e)}",
            "stable": False,
        }
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
            "stable": False,
        }

def check_sql_connection(config: dict) -> Dict[str, Any]:
    """Check SQL Server database connection."""
    try:
        import pyodbc
    except ImportError:
        return {"status": "error", "message": "pyodbc package not installed", "stable": False}

    try:
        conn_str = get_sql_connection_string(config)
        conn = pyodbc.connect(conn_str, timeout=60)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        conn.close()
        return {"status": "success", "message": "SQL database connection successful", "stable": True}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}

# def check_azure_blob_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure Blob Storage connectivity and list up to 50 containers using Azure AD authentication."""
#     try:
#         from azure.storage.blob import BlobServiceClient
#         from azure.identity import ClientSecretCredential
#     except ImportError:
#         return {
#             "status": "error",
#             "message": "azure-storage-blob or azure-identity package not installed",
#             "stable": False,
#         }

#     try:
#         # Create credential using Azure AD
#         credential = ClientSecretCredential(
#             tenant_id=config["tenant_id"],
#             client_id=config["client_id"],
#             client_secret=config["client_secret"]
#         )
        
#         # Create BlobServiceClient using account URL and credential
#         account_url = f"https://{config['account_name']}.blob.core.windows.net"
#         blob_service_client = BlobServiceClient(
#             account_url=account_url,
#             credential=credential
#         )

#         container_names = []
#         for i, container in enumerate(blob_service_client.list_containers()):
#             if i >= 50:
#                 break
#             container_names.append(container["name"])

#         return {
#             "status": "success",
#             "message": f"Azure Blob Storage connection successful ({config['account_name']})",
#             "stable": True,
#             "containers": container_names,
#             "container_count": len(container_names),
#             "container_limit": 50,
#         }

#     except Exception as e:
#         return {
#             "status": "failed",
#             "message": str(e),
#             "stable": False,
#         }


def check_css_connection(config: dict) -> Dict[str, Any]:
    """Check Client Success Stories (CSS) API connection via Dynamics CRM."""
    try:
        import requests
    except ImportError:
        return {
            "status": "error",
            "message": "requests package not installed",
            "stable": False,
        }

    try:
        # Step 1: Get access token from Azure AD
        auth_payload = {
            "grant_type": "client_credentials",
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "scope": config["scope"],
        }
        
        auth_response = requests.post(
            config["auth_url"],
            data=auth_payload,
            timeout=30
        )
        
        if auth_response.status_code != 200:
            return {
                "status": "failed",
                "message": f"Failed to authenticate: {auth_response.status_code} - {auth_response.text}",
                "stable": False,
            }
        
        access_token = auth_response.json().get("access_token")
        if not access_token:
            return {
                "status": "failed",
                "message": "No access token received from authentication",
                "stable": False,
            }
        
        # Step 2: Call CSS API with access token
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        
        api_url = f"{config['api_endpoint']}?$select=csstory_preferredclientname,csstory_engagementtitle,csstory_publisheddate&$orderby=csstory_publisheddate desc&$filter=(csstory_restricted eq 'Unrestricted')&$top=3"
        
        api_response = requests.get(
            api_url,
            headers=headers,
            timeout=30
        )
        
        if api_response.status_code != 200:
            return {
                "status": "failed",
                "message": f"Failed to retrieve CSS data: {api_response.status_code} - {api_response.text}",
                "stable": False,
            }
        
        response_data = api_response.json()
        record_count = len(response_data.get("value", []))
        
        return {
            "status": "success",
            "message": "Client Success Stories API connection successful",
            "stable": True,
            "records_retrieved": record_count,
            "api_endpoint": config["api_endpoint"],
        }
    
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
            "stable": False,
        }

def check_azure_search_connection(config: dict) -> Dict[str, Any]:
    """Check Azure AI Search connection."""
    try:
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential
    except ImportError:
        return {"status": "error", "message": "azure-search-documents package not installed", "stable": False}

    try:
        client = SearchClient(
            endpoint=config["endpoint"],
            index_name=config["index"],
            credential=AzureKeyCredential(config["api_key"]),
        )
        results = client.search(search_text="*", top=1, include_total_count=True)
        _ = results.get_count()
        return {"status": "success", "message": "Azure AI Search connection successful", "stable": True}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_sharepoint_connection(config: dict) -> Dict[str, Any]:
    """Check SharePoint connection using MSAL."""
    try:
        from msal import ConfidentialClientApplication
    except ImportError:
        return {"status": "error", "message": "msal package not installed", "stable": False}

    try:
        authority = f"https://login.microsoftonline.com/{config['tenant_id']}"
        app = ConfidentialClientApplication(
            client_id=config["client_id"],
            client_credential=config["client_secret"],
            authority=authority,
        )
        result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])

        if "access_token" not in result:
            error_msg = result.get("error_description", "Failed to acquire access token")
            return {"status": "failed", "message": error_msg, "stable": False}

        return {"status": "success", "message": "SharePoint connection successful", "stable": True}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_speech_connection(config: dict) -> Dict[str, Any]:
    """Check Azure Speech Service connection."""
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        return {"status": "error", "message": "azure-cognitiveservices-speech package not installed", "stable": False}

    try:       
        speech_config = speechsdk.SpeechConfig(subscription=config["subscription_key"], endpoint=config["endpoint"])
        audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
        speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"

        synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        result = synthesizer.speak_text_async("test").get()

        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            return {"status": "success", "message": "Azure Speech Service connection successful", "stable": True}
        else:
            cancellation = result.cancellation_details
            return {"status": "failed", "message": cancellation.error_details, "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_cdo_database_connection(config: dict) -> Dict[str, Any]:
    """Check Azure CDO Database connection."""
    try:
        import pyodbc
    except ImportError:
        return {"status": "error", "message": "pyodbc package not installed", "stable": False}

    try:
        conn_str = get_sql_connection_string(config)
        conn = pyodbc.connect(conn_str, timeout=30)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        conn.close()
        return {"status": "success", "message": "Azure CDO Database connection successful", "stable": True}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_cdo_databricks_connection(config: dict) -> Dict[str, Any]:
    """Check Azure CDO Databricks connection."""
    try:
        from databricks import sql as databricks_sql
    except ImportError:
        return {"status": "error", "message": "databricks-sql-connector package not installed", "stable": False}

    try:
        connection = databricks_sql.connect(
            server_hostname=config["host"],
            http_path=config["http_path"],
            access_token=config["access_token"]
        )
        cursor = connection.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        connection.close()
        return {"status": "success", "message": "Azure CDO Databricks connection successful", "stable": True}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}

def check_phoenix_oauth_connection(config: dict) -> Dict[str, Any]:
    """Check PwC Phoenix OAuth API connection."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}
    
    try:
        if not config.get("oauth_url") or not config.get("basic_auth"):
            return {"status": "failed", "message": "Phoenix OAuth URL or Basic Auth not configured", "stable": False}
        
        url = config["oauth_url"]
        headers = {
            "authorization": config["basic_auth"]
        }
        response = requests.post(url, headers=headers, timeout=30)
        
        if response.status_code == 200 and "access_token" in response.json():
            return {"status": "success", "message": "PwC Phoenix OAuth API connection successful", "stable": True}
        return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_phoenix_ifs_config_connection(access_token: str, config: dict) -> Dict[str, Any]:
    """Check PwC Phoenix IFS Config API connection."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}
    
    try:
        if not config.get("ifs_config_url"):
            return {"status": "failed", "message": "Phoenix IFS Config URL not configured", "stable": False}
        
        url = config["ifs_config_url"]
        headers = {"authorization": f"Bearer {access_token}"}
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            return {"status": "success", "message": "PwC Phoenix IFS Config API connection successful", "stable": True}
        return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_phoenix_ifs_request_connection(access_token: str, config: dict) -> Dict[str, Any]:
    """Check PwC Phoenix IFS Create Request API connection (dry run)."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}
    
    try:
        if not config.get("ifs_create_request_url"):
            return {"status": "failed", "message": "Phoenix IFS Create Request URL not configured", "stable": False}
        
        url = config["ifs_create_request_url"]
        headers = {"authorization": f"Bearer {access_token}"}
        
        response = requests.head(url, headers=headers, timeout=30)
        
        if response.status_code in [200, 405]:
            return {"status": "success", "message": "PwC Phoenix IFS Create Request API endpoint reachable", "stable": True}
        return {"status": "failed", "message": f"HTTP {response.status_code}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_openai_connection(config: dict) -> Dict[str, Any]:
    """Check Azure OpenAI connection."""
    try:
        from openai import AzureOpenAI
    except ImportError:
        return {"status": "error", "message": "openai package not installed", "stable": False}

    try:
        if not config.get("endpoint") or not config.get("api_key"):
            return {"status": "failed", "message": "Azure OpenAI endpoint or API key not configured", "stable": False}
        
        client = AzureOpenAI(
            api_key=config["api_key"],
            api_version=config.get("api_version", ""),
            azure_endpoint=config["endpoint"],
        )
        
        # Test with a simple completion request
        response = client.chat.completions.create(
            model=config["deployment"],
            messages=[{"role": "user", "content": "test"}],
            max_tokens=5,
        )
        
        if response.choices:
             return {"status": "success", "message": "Azure OpenAI connection successful", "stable": True}
        return {"status": "failed", "message": "No response from Azure OpenAI", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_factiva_connection(config: dict) -> Dict[str, Any]:
    """Check Factiva API connection."""
    try:
        import httpx
    except ImportError:
        return {"status": "error", "message": "httpx package not installed", "stable": False}

    try:
        if not config.get("auth_url") or not config.get("username") or not config.get("password"):
            return {"status": "failed", "message": "Factiva credentials not configured", "stable": False}
        
        # Test authentication
        async def test_auth():
            async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
                response = await client.post(
                    config["auth_url"],
                    data={
                        "username": config["username"],
                        "client_id": config.get("client_id", ""),
                        "password": config["password"],
                        "connection": "service-account",
                        "grant_type": "password",
                        "scope": "openid service_account_id"
                    },
                    headers={"Content-Type": "application/x-www-form-urlencoded"}
                )
                response.raise_for_status()
                return response.json().get("access_token") is not None
        
        import asyncio
        result = asyncio.run(test_auth())
        
        if result:
            return {"status": "success", "message": "Factiva API authentication successful", "stable": True}
        return {"status": "failed", "message": "Factiva authentication failed", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_connected_source_connection(config: dict) -> Dict[str, Any]:
    """Check Connected Source (Passage Retrieval) API connection."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}
    
    try:
        if not config.get("api_url") or not config.get("subscription_key"):
            return {"status": "failed", "message": "Connected Source API URL or subscription key not configured", "stable": False}
        
        url = config["api_url"]
        headers = {
            "accept": "application/json",
            "sc_apikey": config.get("sc_apikey", ""),
            "Content-Type": "application/json"
        }
        payload = {
            "input": "test connection",
            "additionalFields": "entityurl"
        }
        
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            params={"subscription-key": config["subscription_key"]},
            timeout=30
        )
        
        if response.status_code == 200:
            return {"status": "success", "message": "Connected Source API connection successful", "stable": True}
        return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text[:200]}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_redis_connection(config: dict) -> Dict[str, Any]:
    """Check Redis cache connection."""
    try:
        import redis
    except ImportError:
        return {"status": "error", "message": "redis package not installed", "stable": False}

    try:
        if not config.get("host"):
            return {"status": "skipped", "message": "Redis not configured (host not set)", "stable": False}
        
        redis_client = redis.Redis(
            host=config["host"],
            port=config.get("port", 6379),
            password=config.get("password") or None,
            ssl=config.get("ssl", False),
            socket_connect_timeout=5,
            decode_responses=True
        )
        
        # Test connection with ping
        result = redis_client.ping()
        
        if result:
            # Test read/write
            redis_client.set("connectivity_test", "ok", ex=10)
            test_value = redis_client.get("connectivity_test")
            redis_client.delete("connectivity_test")
            
            if test_value == "ok":
                return {"status": "success", "message": "Redis cache connection successful", "stable": True}
            return {"status": "failed", "message": "Redis read/write test failed", "stable": False}
        return {"status": "failed", "message": "Redis ping failed", "stable": False}
    except redis.ConnectionError as e:
        return {"status": "failed", "message": f"Redis connection error: {str(e)}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}


def check_phoenix_apis(config: dict) -> Dict[str, Any]:
    """Check all PwC Phoenix APIs in sequence."""
    oauth_result = check_phoenix_oauth_connection(config)
    if oauth_result["status"] != "success":
        return {
            "oauth": oauth_result,
            "ifs_config": {"status": "skipped", "message": "OAuth failed", "stable": False},
            "ifs_request": {"status": "skipped", "message": "OAuth failed", "stable": False}
        }
    
    try:
        import requests
        if not config.get("oauth_url") or not config.get("basic_auth"):
            return {
                "oauth": oauth_result,
                "ifs_config": {"status": "failed", "message": "Phoenix OAuth configuration missing", "stable": False},
                "ifs_request": {"status": "failed", "message": "Phoenix OAuth configuration missing", "stable": False}
            }
        
        url = config["oauth_url"]
        headers = {
            "authorization": config["basic_auth"]
        }
        response = requests.post(url, headers=headers, timeout=30)
        access_token = response.json()["access_token"]
    except Exception as e:
        return {
            "oauth": oauth_result,
            "ifs_config": {"status": "failed", "message": f"Token retrieval error: {str(e)}", "stable": False},
            "ifs_request": {"status": "failed", "message": f"Token retrieval error: {str(e)}", "stable": False}
        }
    
    return {
        "oauth": oauth_result,
        "ifs_config": check_phoenix_ifs_config_connection(access_token, config),
        "ifs_request": check_phoenix_ifs_request_connection(access_token, config)
    }


def check_plusdocs_connection(config: dict) -> Dict[str, Any]:
    """Check PlusDocs (Plus AI) API connection."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}

    try:
        if not config.get("api_token"):
            return {"status": "failed", "message": "PlusDocs API token not configured", "stable": False}
        
        base_url = config.get("base_url", "")
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config['api_token']}"
        }
        
        # Test API connection by making a request to validate authentication
        # We'll make a minimal POST request with invalid data to test auth without creating a presentation
        test_url = f"{base_url}/presentation"
        
        # Make a request with minimal/invalid payload to test authentication
        # This will fail validation but should return auth-related errors if token is invalid
        # or validation errors if token is valid (which means API is reachable and auth works)
        response = requests.post(
            test_url,
            headers=headers,
            json={"test": "connection"},  # Invalid payload that won't create a presentation
            timeout=10
        )
        
        # Status codes that indicate API is reachable:
        # - 400/422: Bad request (API is reachable, auth might be OK, but payload is invalid)
        # - 401/403: Unauthorized/Forbidden (API is reachable but auth failed)
        # - 200: Success (unlikely with invalid payload, but if it happens, API is working)
        if response.status_code in [200, 400, 401, 403, 422]:
            # API is reachable
            if response.status_code in [401, 403]:
                return {
                    "status": "failed", 
                    "message": f"PlusDocs API authentication failed: HTTP {response.status_code}", 
                    "stable": False
                }
            else:
                # API is reachable and auth appears valid (got validation error, not auth error)
                template_info = f" (template: {config['template_id']})" if config.get("template_id") else ""
                return {
                    "status": "success", 
                    "message": f"PlusDocs API connection successful{template_info}", 
                    "stable": True
                }
        elif response.status_code >= 500:
            return {
                "status": "failed", 
                "message": f"PlusDocs API server error: HTTP {response.status_code}", 
                "stable": False
            }
        else:
            return {
                "status": "failed", 
                "message": f"PlusDocs API returned unexpected status: HTTP {response.status_code}", 
                "stable": False
            }
    except requests.exceptions.ConnectionError as e:
        return {"status": "failed", "message": f"PlusDocs API connection error: {str(e)}", "stable": False}
    except requests.exceptions.Timeout:
        return {"status": "failed", "message": "PlusDocs API connection timeout", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}



@router.get("/api/connectivity")
async def check_all_connections():
    """Check all external service connections for the current environment."""
    settings = get_settings()
    env = settings.APP_ENV.lower() if settings.APP_ENV else "unknown"
    
    return {
        "environment": env,
        "connections": {
            "sql_database": check_sql_connection(CONNECTIVITY_CONFIG["sql"]),
            "azure_search": check_azure_search_connection(CONNECTIVITY_CONFIG["azure_search"]),
            "sharepoint": check_sharepoint_connection(CONNECTIVITY_CONFIG["sharepoint"]),
            "speech_service": check_speech_connection(CONNECTIVITY_CONFIG["speech"]),
            "cdo_database": check_cdo_database_connection(CONNECTIVITY_CONFIG["cdo_database"]),
            "cdo_databricks": check_cdo_databricks_connection(CONNECTIVITY_CONFIG["cdo_databricks"]),
            "tavily": check_tavily_connection(CONNECTIVITY_CONFIG["tavily"]),
            "azure_blob_storage": check_azure_blob_connection(CONNECTIVITY_CONFIG["azure_blob"]),
            "openai": check_openai_connection(CONNECTIVITY_CONFIG["openai"]),
            "factiva": check_factiva_connection(CONNECTIVITY_CONFIG["factiva"]),
            "phoenix": check_phoenix_apis(CONNECTIVITY_CONFIG.get("phoenix", {})),
            "connected_source": check_connected_source_connection(CONNECTIVITY_CONFIG["connected_source"]),
            "redis_cache": check_redis_connection(CONNECTIVITY_CONFIG["redis"]),
            "plusdocs": check_plusdocs_connection(CONNECTIVITY_CONFIG["plusdocs"]),
        },
    }
    # return {
    #     "dev": {
    #         "azure_blob_storage": check_azure_blob_connection(DEV_CONFIG["azure_blob"]),
    #         "css_api": check_css_connection(DEV_CONFIG["css"]),
    #         "connected_source": check_passage_retrieval_connection()
    #     },
    #     "stage": {
    #         "azure_blob_storage": check_azure_blob_connection(STAGE_CONFIG["azure_blob"]),
    #         "css_api": check_css_connection(STAGE_CONFIG["css"]),
    #         "connected_source": check_passage_retrieval_connection()
    #     },
        
    # }


def get_router():
    return router