"""
Factiva Client for fetching news articles and research content via Factiva GenAI Retrieval API
Handles per-request authentication (token refresh) and article search
"""

import httpx
import logging
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class FactivaArticle:
    """Structured representation of a Factiva article"""
    id: str
    title: str
    headline: str
    content: str
    byline: Optional[str]
    publication_date: str
    load_date: str
    source_name: str
    source_code: str
    language_code: str
    snippet: str
    copyright: str
    url: str


class FactivaClient:
    """
    Client for Factiva GenAI Retrieval API
    Implements per-request token refresh with two-step OAuth2 authentication:
    1. Authenticate with service account credentials to get JWT token
    2. Exchange JWT token for authorization token (bearer token)
    """

    def __init__(
        self,
        api_key: str,
        endpoint: str,
        base_url: str = "https://api.dowjones.com",
        username: str = "",
        client_id: str = "",
        password: str = "",
    ):
        """
        Initialize Factiva Client

        Args:
            api_key: Factiva API key (for future use or validation)
            endpoint: GenAI Retrieval endpoint (e.g., /content/gen-ai/retrieve)
            base_url: Base URL for Factiva API (default: https://api.dowjones.com)
            username: Service account username (e.g., "9PRI033400-svcaccount@dowjones.com")
            client_id: OAuth2 client ID (e.g., "bbFvlCtgXICfEAky3cIihoLH2dPWhUxcjE7YRA72")
            password: Service account password
        """
        self.api_key = api_key
        self.endpoint = endpoint
        self.base_url = base_url
        self.full_url = f"{base_url}{endpoint}"
        self.username = username
        self.client_id = client_id
        self.password = password
        self._token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
        self.auth_base_url = "https://accounts.dowjones.com/oauth2/v1/token"

    async def authenticate(self) -> str:
        """
        Obtain bearer token from Factiva API via two-step OAuth2 authentication:
        
        Step 1: Authenticate with service account credentials to get JWT token
        Step 2: Exchange JWT token for authorization token (bearer token for GenAI API)

        Per-request: no caching/pooling - fresh token every request

        Returns:
            Bearer token string for GenAI API requests

        Raises:
            Exception: If authentication fails
        """
        try:
            logger.info("Starting two-step Factiva OAuth2 authentication...")
            
            # Step 1: Get JWT token using service account credentials
            jwt_token = await self._get_jwt_token()
            logger.debug("Step 1 complete: JWT token obtained")
            
            # Step 2: Exchange JWT token for authorization token
            bearer_token = await self._get_authorization_token(jwt_token)
            logger.debug("Step 2 complete: Authorization token obtained")
            
            self._token = bearer_token
            logger.debug("Factiva authentication successful (per-request token refresh)")
            return self._token

        except Exception as e:
            logger.error(f"Factiva authentication failed: {str(e)}")
            raise

    async def _get_jwt_token(self) -> str:
        """
        Step 1: Authenticate with service account credentials to get JWT token

        Request:
            POST https://accounts.dowjones.com/oauth2/v1/token
            Content-Type: application/x-www-form-urlencoded
            
            username=<service-account-email>
            client_id=<client-id>
            password=<password>
            connection=service-account
            grant_type=password
            scope=openid service_account_id

        Returns:
            JWT token (assertion)

        Raises:
            Exception: If JWT token retrieval fails
        """
        try:
            payload = {
                "username": self.username,
                "client_id": self.client_id,
                "password": self.password,
                "connection": "service-account",
                "grant_type": "password",
                "scope": "openid service_account_id",
            }

            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
            }

            logger.debug(f"Step 1: Requesting JWT token from {self.auth_base_url}")

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self.auth_base_url,
                    data=payload,
                    headers=headers,
                )

                if response.status_code != 200:
                    logger.error(
                        f"JWT token request failed {response.status_code}: {response.text}"
                    )
                    raise Exception(
                        f"Failed to get JWT token: {response.status_code} - {response.text}"
                    )

                data = response.json()
                jwt_token = data.get("id_token")

                if not jwt_token:
                    raise Exception("No id_token in response")

                logger.debug("JWT token retrieved successfully")
                return jwt_token

        except Exception as e:
            logger.error(f"Failed to get JWT token: {str(e)}")
            raise

    async def _get_authorization_token(self, jwt_token: str) -> str:
        """
        Step 2: Exchange JWT token for authorization token (bearer token)

        Uses JWT token from Step 1 to request bearer token for GenAI API

        Request:
            POST https://accounts.dowjones.com/oauth2/v1/token
            Content-Type: application/x-www-form-urlencoded
            
            assertion=<jwt_token>
            client_id=<client-id>
            grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer

        Returns:
            Bearer token for GenAI API

        Raises:
            Exception: If authorization token retrieval fails
        """
        try:
            payload = {
                "assertion": jwt_token,
                "client_id": self.client_id,
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                "scope": "openid pib"
            }

            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
            }

            logger.debug(f"Step 2: Requesting authorization token from {self.auth_base_url}")

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self.auth_base_url,
                    data=payload,
                    headers=headers,
                )

                if response.status_code != 200:
                    logger.error(
                        f"Authorization token request failed {response.status_code}: {response.text}"
                    )
                    raise Exception(
                        f"Failed to get authorization token: {response.status_code} - {response.text}"
                    )

                data = response.json()
                bearer_token = data.get("access_token")

                if not bearer_token:
                    raise Exception("No access token in response")

                logger.debug("Authorization token retrieved successfully")
                return bearer_token

        except Exception as e:
            logger.error(f"Failed to get authorization token: {str(e)}")
            raise

    async def search_articles(
        self,
        query: str,
        response_limit: int = 10,
        language_filters: Optional[List[str]] = None,
    ) -> List[FactivaArticle]:
        """
        Search articles on Factiva using GenAI Retrieval API

        Args:
            query: Search query/topic (e.g., "weight loss drugs and impact on USA")
            response_limit: Max number of articles to return (configurable per content-type)
            language_filters: Language codes to filter by (default: ["en", "de"])

        Returns:
            List of FactivaArticle objects with full content

        Raises:
            Exception: If search fails
        """
        if language_filters is None:
            language_filters = ["en", "de"]

        try:
            # Authenticate (per-request)
            token = await self.authenticate()

            # Build request payload for GenAI Retrieval endpoint
            request_body = {
                "data": {
                    "attributes": {
                        "response_limit": response_limit,
                        "query": {
                            "search_filters": [
                                {
                                    "scope": "Language",
                                    "value": " or ".join(language_filters),
                                }
                            ],
                            "value": query,
                        },
                    },
                    "id": "GenAIRetrieval",
                    "type": "genai-content",
                }
            }

            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "application/vnd.dowjones.genai-content.v_1.0",
            }

            logger.info(f"Searching Factiva for: {query} (limit: {response_limit})")
            logger.debug(f"[FACTIVA] Request body: {request_body}")

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self.full_url,
                    json=request_body,
                    headers=headers,
                )

                if response.status_code != 200:
                    logger.error(
                        f"Factiva API error {response.status_code}: {response.text}"
                    )
                    raise Exception(
                        f"Factiva API returned {response.status_code}: {response.text}"
                    )

                data = response.json()
                logger.debug(f"[FACTIVA] Full API response: {data}")
                articles = self._parse_response(data)
                logger.info(f"Retrieved {len(articles)} articles from Factiva")
                return articles

        except Exception as e:
            logger.error(f"Factiva search failed: {str(e)}")
            raise

    def _parse_response(self, response_data: Dict[str, Any]) -> List[FactivaArticle]:
        """
        Parse Factiva GenAI Retrieval API response into FactivaArticle objects

        Args:
            response_data: Raw JSON response from Factiva API

        Returns:
            List of FactivaArticle objects
        """
        articles = []

        try:
            data_items = response_data.get("data", [])
            logger.debug(f"[FACTIVA] Total items in response: {len(data_items)}")

            for item_idx, item in enumerate(data_items):
                try:
                    logger.debug(f"[FACTIVA] Parsing item {item_idx + 1}/{len(data_items)}")
                    # Extract metadata
                    meta = item.get("meta", {})
                    attributes = item.get("attributes", {})
                    links = item.get("links", {})

                    # Extract article data
                    title = (
                        attributes.get("headline", {}).get("main", {}).get("text", "")
                    )
                    headline = title  # Use same as title for consistency
                    byline = attributes.get("byline", {}).get("text", "")
                    publication_date = attributes.get("publication_date", "")
                    load_date = attributes.get("load_date", "")
                    copyright_text = attributes.get("copyright", {}).get("text", "")
                    
                    # Extract full content (primary source of truth)
                    content_array = attributes.get("content", [])
                    full_content = ""
                    if content_array:
                        full_content = content_array[0].get("text", "")
                    
                    # Extract snippet for preview
                    snippet_obj = attributes.get("snippet", {}).get("content", [])
                    snippet = ""
                    if snippet_obj:
                        snippet = snippet_obj[0].get("text", "")

                    # Extract source information
                    source = meta.get("source", {})
                    source_name = source.get("name", "Unknown Source")
                    source_code = source.get("code", "")

                    # Extract language
                    language = meta.get("language", {})
                    language_code = language.get("code", "en")

                    # Extract URL
                    url = links.get("self", "")

                    # Extract article ID
                    article_id = item.get("id", "")

                    # Create FactivaArticle object
                    article = FactivaArticle(
                        id=article_id,
                        title=title,
                        headline=headline,
                        content=full_content,  # Full article text
                        byline=byline,
                        publication_date=publication_date,
                        load_date=load_date,
                        source_name=source_name,
                        source_code=source_code,
                        language_code=language_code,
                        snippet=snippet,
                        copyright=copyright_text,
                        url=url,
                    )

                    articles.append(article)
                    logger.debug(f"[FACTIVA] Successfully parsed article: '{title}' from {source_name}")

                except Exception as e:
                    logger.warning(f"[FACTIVA] Failed to parse article at index {item_idx}: {str(e)}, skipping...")
                    continue

            logger.info(f"[FACTIVA] Parse complete: Successfully converted {len(articles)} articles from {len(data_items)} items")
            return articles

        except Exception as e:
            logger.error(f"[FACTIVA] Failed to parse Factiva response: {str(e)}")
            return []

    async def close(self) -> None:
        """
        Cleanup resources (for future connection pooling if needed)
        Currently no-op as we use per-request httpx clients
        """
        self._token = None
        logger.debug("Factiva client closed")
