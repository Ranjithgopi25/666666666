"""
Citation Validator for ensuring citations are valid and properly formatted
"""

import re
import logging
from typing import List, Set, Tuple

logger = logging.getLogger(__name__)


def validate_citations(
    text: str, available_citations: List[int]
) -> Tuple[str, Set[int]]:
    """
    Validate and clean citations in generated text.

    Args:
        text: Generated text with citations
        available_citations: List of valid citation numbers

    Returns:
        Tuple of (cleaned_text, valid_citation_numbers)
    """
    if not text:
        return text, set()

    available_set = set(available_citations)
    found_citations = set()

    # Find all citations in format [1.], [2.], etc.
    citation_pattern = r"\[(\d+)\.\]"
    matches = list(re.finditer(citation_pattern, text))

    for match in matches:
        citation_num = int(match.group(1))
        if citation_num in available_set:
            found_citations.add(citation_num)
        else:
            # Remove invalid citation
            logger.warning(
                f"Removing invalid citation [{citation_num}.] (not in available sources)"
            )
            text = text.replace(match.group(0), "", 1)  # Remove only first occurrence

    # Clean up any double spaces or formatting issues
    text = re.sub(r"\s+", " ", text)  # Multiple spaces to single
    text = re.sub(r"\s+\[", " [", text)  # Ensure space before citation

    return text, found_citations


def extract_citations_from_text(text: str) -> Set[int]:
    """
    Extract all citation numbers from text.

    Args:
        text: Text containing citations

    Returns:
        Set of citation numbers found
    """
    citation_pattern = r"\[(\d+)\.\]"
    matches = re.findall(citation_pattern, text)
    return {int(m) for m in matches}


def ensure_citations_are_used(text: str, retrieved_sources: List[dict]) -> str:
    """
    Ensure that retrieved sources are actually cited in the text.
    If a source was retrieved but not cited, add a reminder to the LLM.

    Args:
        text: Generated text
        retrieved_sources: List of sources that were retrieved

    Returns:
        Text with validation notes (if needed)
    """
    if not retrieved_sources:
        return text

    cited_numbers = extract_citations_from_text(text)
    retrieved_numbers = {
        s.get("citation_number") for s in retrieved_sources if s.get("citation_number")
    }

    uncited_sources = retrieved_numbers - cited_numbers

    if uncited_sources and len(uncited_sources) < len(retrieved_numbers):
        # Some sources were retrieved but not cited - this is okay, just log
        logger.info(
            f"Retrieved {len(retrieved_numbers)} sources, cited {len(cited_numbers)}"
        )

    return text
