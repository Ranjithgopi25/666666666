"""
Repository for chat history database operations.
Implements repository pattern for data access layer.
Simple session-focused model: one session = one complete conversation.
"""
import json
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy import create_engine, desc
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError
import logging

from app.models.chat_history import ChatHistory, User, Base

logger = logging.getLogger(__name__)


class ChatHistoryRepository:
    """
    Repository for managing chat history persistence in SQL Server.
    One session = one complete conversation stored as a single record.
    """
    
    def __init__(self, connection_string: str):
        """
        Initialize repository with database connection.
        
        Args:
            connection_string: SQL Server connection string
        """
        self.engine = create_engine(
            f"mssql+pyodbc:///?odbc_connect={connection_string}",
            pool_pre_ping=True,
            pool_size=10,
            max_overflow=20
        )
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        logger.info("ChatHistoryRepository initialized with SQL Server connection")
    
    def get_session(self) -> Session:
        """Get a new database session."""
        return self.SessionLocal()
    
    def create_session(
        self,
        session_id: str,
        user_id: uuid.UUID,
        source: str,
        initial_message: Optional[Dict[str, Any]] = None,
        user_email: Optional[str] = None,
        title: Optional[str] = None
    ) -> ChatHistory:
        """
        Create a new chat session.
        
        Args:
            session_id: Session identifier (string)
            user_id: User UUID
            source: Source of conversation (Chat, DDDC, Thought_Leadership, etc.)
            initial_message: Optional first message
            user_email: Optional user email for user creation
            title: Optional session title (defaults to first message)
            
        Returns:
            ChatHistory: Created session record
        """
        db = self.get_session()
        try:
            # Ensure user exists in database (for FK constraint)
            if user_email:
                existing_user = db.query(User).filter(User.id == user_id).first()
                if not existing_user:
                    user = User(id=user_id, email=user_email, username=user_email.split('@')[0])
                    db.add(user)
                    db.commit()
                    logger.info(f"Created new user: {user_email}")
            
            # Initialize conversation with messages array
            conversation = {"messages": []}
            
            if initial_message:
                initial_message["timestamp"] = datetime.utcnow().isoformat()
                conversation["messages"].append(initial_message)
                # Auto-generate title from first message if not provided
                if not title and "content" in initial_message:
                    title = initial_message["content"][:100]
            
            chat_history = ChatHistory(
                session_id=session_id,
                user_id=user_id,
                source=source,
                title=title,
                conversation=json.dumps(conversation)
            )
            
            db.add(chat_history)
            db.commit()
            db.refresh(chat_history)
            
            logger.info(f"Created session {session_id} for user {user_id} with source {source}")
            return chat_history
            
        except SQLAlchemyError as e:
            db.rollback()
            logger.error(f"Error creating session: {str(e)}")
            raise
        finally:
            db.close()
    
    def get_session_by_id(self, session_id: str) -> Optional[ChatHistory]:
        """
        Get a session by session_id.
        
        Args:
            session_id: Session identifier
            
        Returns:
            ChatHistory record or None if not found
        """
        db = self.get_session()
        try:
            chat_history = db.query(ChatHistory).filter(
                ChatHistory.session_id == session_id,
                ChatHistory.deleted_at.is_(None)
            ).first()
            
            return chat_history
            
        except SQLAlchemyError as e:
            logger.error(f"Error getting session {session_id}: {str(e)}")
            raise
        finally:
            db.close()
    
    def append_message_or_create(
        self,
        session_id: str,
        message: Dict[str, Any],
        user_id: Optional[uuid.UUID] = None,
        source: str = "Chat",
        user_email: Optional[str] = None
    ) -> ChatHistory:
        """
        Append a message to an existing session, or create session if not found.
        Prevents 'Session not found' errors when frontend sends session_id before session is created.
        
        Args:
            session_id: Session identifier
            message: Message with role and content
            user_id: User UUID (required if creating new session)
            source: Source of conversation (required if creating new session)
            user_email: Optional user email for user creation
            
        Returns:
            ChatHistory: Updated or newly created session record
        """
        db = self.get_session()
        try:
            chat_history = db.query(ChatHistory).filter(
                ChatHistory.session_id == session_id,
                ChatHistory.deleted_at.is_(None)
            ).first()
            
            # If session doesn't exist, create it with this message as initial content
            if not chat_history:
                logger.warning(f"Session {session_id} not found during append. Creating new session with user_id={user_id}, source={source}")
                if not user_id:
                    raise ValueError(f"Session {session_id} not found and cannot create new session without user_id")
                
                # Create session with the message as initial content
                initial_message = {
                    **message,
                    "timestamp": datetime.utcnow().isoformat()
                }
                return self.create_session(
                    session_id=session_id,
                    user_id=user_id,
                    source=source,
                    initial_message=initial_message,
                    user_email=user_email
                )
            
            # Session exists, proceed with normal append
            return self._append_message_to_existing(db, chat_history, message)
            
        except SQLAlchemyError as e:
            db.rollback()
            logger.error(f"Error appending/creating session {session_id}: {str(e)}")
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"Error in append_message_or_create for {session_id}: {str(e)}")
            raise
        finally:
            db.close()
    
    def _append_message_to_existing(
        self,
        db: Session,
        chat_history: ChatHistory,
        message: Dict[str, Any]
    ) -> ChatHistory:
        """
        Internal helper to append message to existing session.
        
        Args:
            db: Database session
            chat_history: Existing chat history record
            message: Message to append
            
        Returns:
            Updated ChatHistory record
        """
        # Parse existing conversation
        conversation = json.loads(chat_history.conversation)
        
        # Add timestamp to message
        message["timestamp"] = datetime.utcnow().isoformat()
        
        # Append message
        conversation["messages"].append(message)
        
        # Update record
        chat_history.conversation = json.dumps(conversation)
        chat_history.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(chat_history)
        
        logger.info(f"Appended message to session {chat_history.session_id}")
        return chat_history
    
    def append_message(
        self,
        session_id: str,
        message: Dict[str, Any]
    ) -> ChatHistory:
        """
        Append a message to an existing session.
        Raises error if session not found (for backward compatibility).
        
        Args:
            session_id: Session identifier
            message: Message with role and content
            
        Returns:
            ChatHistory: Updated session record
        """
        db = self.get_session()
        try:
            chat_history = db.query(ChatHistory).filter(
                ChatHistory.session_id == session_id,
                ChatHistory.deleted_at.is_(None)
            ).first()
            
            if not chat_history:
                raise ValueError(f"Session {session_id} not found")
            
            # Use internal helper for actual append logic
            return self._append_message_to_existing(db, chat_history, message)
            
        except SQLAlchemyError as e:
            db.rollback()
            logger.error(f"Error appending message to session {session_id}: {str(e)}")
            raise
        finally:
            db.close()
    
    def get_user_sessions(self, user_id: uuid.UUID) -> List[Dict[str, Any]]:
        """
        Get all sessions for a user.
        
        Args:
            user_id: User identifier
            
        Returns:
            List of ChatHistory records as dictionaries
        """
        db = self.get_session()
        try:
            sessions = db.query(ChatHistory).filter(
                ChatHistory.user_id == user_id,
                ChatHistory.deleted_at.is_(None)
            ).order_by(desc(ChatHistory.created_at)).all()
            
            # Convert to dictionaries while session is still open to avoid detached instance errors
            result = []
            for session_obj in sessions:
                result.append({
                    'session_id': session_obj.session_id,
                    'source': session_obj.source,
                    'title': session_obj.title,
                    'conversation': session_obj.conversation,
                    'created_at': session_obj.created_at,
                    'updated_at': session_obj.updated_at,
                    'user_id': session_obj.user_id,
                    'deleted_at': session_obj.deleted_at
                })
            
            return result
            
        except SQLAlchemyError as e:
            logger.error(f"Error getting sessions for user {user_id}: {str(e)}")
            raise
        finally:
            db.close()
    
    def get_user_sessions_by_email(self, email: str) -> List[Dict[str, Any]]:
        """
        Get all sessions for a user by email address.
        First looks up user UUID by email, then queries sessions.
        
        Args:
            email: User email address
            
        Returns:
            List of ChatHistory records as dictionaries
        """
        db = self.get_session()
        try:
            logger.info(f"[ChatHistoryRepository] Getting user by email: {email}")
            # First, get the user UUID by querying the Users table
            user = db.query(User).filter(User.email == email).first()
            
            if not user:
                logger.warning(f"[ChatHistoryRepository] User not found with email: {email}")
                return []
            
            user_uuid = user.id
            logger.info(f"[ChatHistoryRepository] Found user UUID {user_uuid} for email {email}")
            
            # Now get all sessions for this user
            sessions = db.query(ChatHistory).filter(
                ChatHistory.user_id == user_uuid,
                ChatHistory.deleted_at.is_(None)
            ).order_by(desc(ChatHistory.created_at)).all()
            
            logger.info(f"[ChatHistoryRepository] Found {len(sessions)} sessions for user {user_uuid}")
            
            # Convert to dictionaries while session is still open
            result = []
            for session_obj in sessions:
                result.append({
                    'session_id': session_obj.session_id,
                    'source': session_obj.source,
                    'title': session_obj.title,
                    'conversation': session_obj.conversation,
                    'created_at': session_obj.created_at,
                    'updated_at': session_obj.updated_at,
                    'user_id': session_obj.user_id,
                    'deleted_at': session_obj.deleted_at
                })
            
            return result
            
        except SQLAlchemyError as e:
            logger.error(f"Error getting sessions by email {email}: {str(e)}", exc_info=True)
            raise
        finally:
            db.close()
    
    def get_user_by_email(self, email: str) -> Optional[uuid.UUID]:
        """
        Get user UUID by email address.
        
        Args:
            email: User email address
            
        Returns:
            User UUID if found, None otherwise
        """
        db = self.get_session()
        try:
            user = db.query(User).filter(User.email == email).first()
            if user:
                logger.info(f"[ChatHistoryRepository] Found user with email {email}, UUID: {user.id}")
                return user.id
            else:
                logger.warning(f"[ChatHistoryRepository] User not found with email: {email}")
                return None
        except SQLAlchemyError as e:
            logger.error(f"Error getting user by email {email}: {str(e)}")
            raise
        finally:
            db.close()
    
    def delete_session(self, session_id: str) -> bool:
        """
        Soft delete a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if deleted, False if not found
        """
        db = self.get_session()
        try:
            chat_history = db.query(ChatHistory).filter(
                ChatHistory.session_id == session_id,
                ChatHistory.deleted_at.is_(None)
            ).first()
            
            if not chat_history:
                return False
            
            chat_history.deleted_at = datetime.utcnow()
            db.commit()
            
            logger.info(f"Soft deleted session {session_id}")
            return True
            
        except SQLAlchemyError as e:
            db.rollback()
            logger.error(f"Error deleting session {session_id}: {str(e)}")
            raise
        finally:
            db.close()
    
    def get_or_create_user(self, email: str, username: str) -> User:
        """
        Get existing user or create new one.
        
        Args:
            email: User email
            username: Username
            
        Returns:
            User record
        """
        db = self.get_session()
        try:
            user = db.query(User).filter(User.email == email).first()
            
            if not user:
                user = User(email=email, username=username)
                db.add(user)
                db.commit()
                db.refresh(user)
                logger.info(f"Created new user: {email}")
            
            return user
            
        except SQLAlchemyError as e:
            db.rollback()
            logger.error(f"Error getting/creating user {email}: {str(e)}")
            raise
        finally:
            db.close()
