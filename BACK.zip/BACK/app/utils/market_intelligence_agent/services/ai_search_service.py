# app/utils/market_intelligence_agent/langgraph/azure_search.py

import logging
from typing import List, Dict, Any
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class AISearchService:
    """
    Lightweight Azure AI Search wrapper for LangGraph usage.
    """

    def __init__(self):
        self.client = SearchClient(
            endpoint=settings.AI_SEARCH_ENDPOINT,
            index_name=settings.AI_SEARCH_INDEX_NAME,
            credential=AzureKeyCredential(settings.AI_SEARCH_API_KEY),
        )

    async def search(self, query: str, top: int = 5) -> List[Dict[str, Any]]:
        """
        Execute Azure AI Search query (synchronous).
        """
        logger.info(f"[AzureSearchTool] Query: {query}")

        results = self.client.search(
            search_text=query,
            top=top,
            include_total_count=True,
        )

        documents = []
        for result in results:
            chunk = result.get("chunk", "")
            if chunk:
                documents.append(
                    {
                        "chunk": chunk,
                        "score": result.get("@search.score", 0.0),
                    }
                )

        return self.format_for_llm(documents)

    @staticmethod
    def format_for_llm(results: List[Dict[str, Any]]) -> str:
        """
        Format results for LangGraph / LLM context injection.
        """
        if not results:
            return "No relevant documents found in internal knowledge base."

        blocks = ["### Internal Knowledge Base Results\n"]

        for idx, doc in enumerate(results, start=1):
            blocks.append(
                f"**Document {idx}** (Relevance: {doc['score']:.2f})\n"
                f"{doc['chunk']}\n"
                "---\n"
            )

        return "\n".join(blocks)
