from langchain_core.tools import tool
from typing import Dict, List
import logging
import asyncio

from .connected_source import PassageRetrievalService
from app.core.config import get_settings
from app.utils.market_intelligence_agent.services.ai_search_service import AISearchService

logger = logging.getLogger(__name__)
settings = get_settings()

# =========================================================
# Connected Source Client
# =========================================================
passage_retrieval_service = PassageRetrievalService(
    api_url=settings.PASSAGE_RETRIEVAL_API_URL,
    subscription_key=settings.PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY,
    sc_apikey=settings.PASSAGE_RETRIEVAL_SC_APIKEY
)

# =========================================================
# AZURE AI SEARCH (SYNC TOOL)
# =========================================================
@tool("azure_ai_search")
def search_azure_ai(query: str, top: int = 5) -> str:
    """
    Search internal knowledge base using Azure AI Search.
    """
    print(">>> azure_ai_search TOOL CALLED <<<")
    print("Input query for Azure AI search   ", query)
    search_tool = AISearchService()

    async def _run():
        results = await search_tool.search(query=query, top=top)
        return results

    return asyncio.run(_run())

# =========================================================
# PROPRIETARY CONTENT TOOLS
# =========================================================
@tool("pwc_industry_edge")
def search_pwc_industry_edge(query: str, guidelines: str = "") -> str:
    """Search PwC Industry Edge for industry-specific insights."""
    logger.info("[Tool: pwc_industry_edge]")
    return f"Research data from PwC Industry Edge for: {query}\nGuidelines: {guidelines}"

@tool("pwc_insights")
def search_pwc_insights(query: str, guidelines: str = "") -> str:
    """Search PwC Insights for research content."""
    logger.info("[Tool: pwc_insights]")
    return f"Research data from PwC Insights for: {query}\nGuidelines: {guidelines}"

@tool("sb_journal")
def search_sb_journal(query: str, guidelines: str = "") -> str:
    """Search s+b Journal for articles and insights."""
    logger.info("[Tool: sb_journal]")
    return f"Research data from s+b Journal for: {query}\nGuidelines: {guidelines}"

@tool("executive_leadership_hub")
def search_executive_leadership_hub(query: str, guidelines: str = "") -> str:
    """Search Executive Leadership Hub for leadership insights."""
    logger.info("[Tool: executive_leadership_hub]")
    return f"Research data from Executive Leadership Hub for: {query}\nGuidelines: {guidelines}"

@tool("the_exchange")
def search_the_exchange(query: str, guidelines: str = "") -> str:
    """Search The Exchange for content."""
    logger.info("[Tool: the_exchange]")
    return f"Research data from The Exchange for: {query}\nGuidelines: {guidelines}"

# =========================================================
# CONNECTED SOURCE (ASYNC TOOL)
# =========================================================
@tool("pwc_connected_source")
def search_pwc_connected_source(query: str, guidelines: str = "") -> str:
    """
    Search PwC Connected Source for internal documents and passages.
    """
    logger.info("[Tool: pwc_connected_source] invoked")

    search_query = f"{query} {guidelines}".strip()

    async def _run():
        passages = await passage_retrieval_service.retrieve_passages(search_query)
        return passage_retrieval_service.format_response(passages)

    try:
        # Safe async → sync bridge
        return asyncio.run(_run())
    except RuntimeError:
        # In case we're already inside an event loop (LangGraph thread pool)
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(_run())
    except Exception as e:
        logger.error(f"[Tool: pwc_connected_source] Error: {e}", exc_info=True)
        return f"Error searching PwC Connected Source: {str(e)}"

# =========================================================
# OTHER INTERNAL TOOLS
# =========================================================
@tool("pwc_benchmarking")
def search_pwc_benchmarking(query: str, guidelines: str = "") -> str:
    """Search PwC Benchmarking for benchmarking data."""
    logger.info("[Tool: pwc_benchmarking]")
    return f"Research data from PwC Benchmarking for: {query}\nGuidelines: {guidelines}"

@tool("insights_factory")
def search_insights_factory(query: str, guidelines: str = "") -> str:
    """Search Insights Factory for insights."""
    logger.info("[Tool: insights_factory]")
    return f"Research data from Insights Factory for: {query}\nGuidelines: {guidelines}"

@tool("pwc_intelligence")
def search_pwc_intelligence(query: str, guidelines: str = "") -> str:
    """Search PwC Intelligence for intelligence data."""
    logger.info("[Tool: pwc_intelligence]")
    return f"Research data from PwC Intelligence for: {query}\nGuidelines: {guidelines}"

@tool("client_success_stories")
def search_client_success_stories(query: str, guidelines: str = "") -> str:
    """Search Client Success Stories for case studies."""
    logger.info("[Tool: client_success_stories]")
    return f"Research data from Client Success Stories for: {query}\nGuidelines: {guidelines}"

@tool("inside_industries")
def search_inside_industries(query: str, guidelines: str = "") -> str:
    """Search Inside Industries for industry-specific content."""
    logger.info("[Tool: inside_industries]")
    return f"Research data from Inside Industries for: {query}\nGuidelines: {guidelines}"

@tool("value_store")
def search_value_store(query: str, guidelines: str = "") -> str:
    """Search Value Store for content."""
    logger.info("[Tool: value_store]")
    return f"Research data from Value Store for: {query}\nGuidelines: {guidelines}"

# =========================================================
# TOOL REGISTRY (SAFE KEYS ONLY)
# =========================================================
PROPRIETARY_TOOLS_MAP = {
    "azure_ai_search": search_azure_ai,
    "pwc_industry_edge": search_pwc_industry_edge,
    "pwc_insights": search_pwc_insights,
    "sb_journal": search_sb_journal,
    "executive_leadership_hub": search_executive_leadership_hub,
    "the_exchange": search_the_exchange,
    "pwc_connected_source": search_pwc_connected_source,
    "pwc_benchmarking": search_pwc_benchmarking,
    "insights_factory": search_insights_factory,
    "pwc_intelligence": search_pwc_intelligence,
    "client_success_stories": search_client_success_stories,
    "inside_industries": search_inside_industries,
    "value_store": search_value_store,
}
