import { Routes } from '@angular/router';
import { environment } from '../environments/environment';
import { MsalGuard } from '@azure/msal-angular';

const guard = environment.useAuth ? [MsalGuard] : undefined;

export const routes: Routes = [
    //oauth provider will redirect here aftre login
    { path: '**', redirectTo: '' },
];
