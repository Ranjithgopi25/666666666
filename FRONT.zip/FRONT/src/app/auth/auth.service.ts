import { Injectable, Injector, inject } from '@angular/core';
import { MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { AuthenticationResult, InteractionStatus } from '@azure/msal-browser';
import { Observable, of, fromEvent, merge } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const ENABLE_AUTH = environment.useAuth;
const INACTIVITY_TIMEOUT = 60 * 60 * 1000; // 60 minutes in milliseconds
const MAX_SESSION_LENGTH = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
@Injectable({
  providedIn: 'root'
})
export class AuthService {
private injector = inject(Injector);
  private msalService: MsalService | null = null;
  private msalBroadcastService: MsalBroadcastService | null = null;
  
  private inactivityTimer: any;
  private sessionStartTime: number | null = null;
  private maxSessionTimer: any;
  private statusLogTimer: any;
  
  constructor() {
    if (ENABLE_AUTH) {
        this.msalService = this.injector.get(MsalService);
        this.msalBroadcastService = this.injector.get(MsalBroadcastService);
        
        // Structured logging for easy sharing/debugging
        console.group('🔐 [AuthService] MSAL Services Initialized');
        console.log('MsalService:', this.msalService);
        console.log('MsalBroadcastService:', this.msalBroadcastService);
        
        // Key properties for troubleshooting (copyable format)
        const debugInfo = {
          timestamp: new Date().toISOString(),
          msalServiceExists: !!this.msalService,
          msalBroadcastServiceExists: !!this.msalBroadcastService,
          activeAccount: this.msalService?.instance?.getActiveAccount?.() || null,
          allAccountsCount: this.msalService?.instance?.getAllAccounts?.()?.length || 0,
          configuration: {
            clientId: (this.msalService?.instance as any)?.config?.auth?.clientId || 'N/A',
            authority: (this.msalService?.instance as any)?.config?.auth?.authority || 'N/A'
          }
        };
        console.log('📋 Debug Info (copy-friendly):', JSON.stringify(debugInfo, null, 2));
        console.groupEnd();

        
    this.msalService.handleRedirectObservable().subscribe({
      next: (result: AuthenticationResult) => {
        if (result) {
          ////console.log('Login successful:', result);
          this.msalService?.instance.setActiveAccount(result.account);
          this.startSessionTimers();
        }
      },
      error: (error) => console.error('Login error:', error)
    });

    // Check if user is already logged in and start timers
    if (this.isLoggedIn()) {
      this.startSessionTimers();
    }
  }
}

  private startSessionTimers() {
    // Clear any existing timers
    this.clearTimers();

    // Set session start time
    const storedStartTime = sessionStorage.getItem('sessionStartTime');
    if (storedStartTime) {
      this.sessionStartTime = parseInt(storedStartTime, 10);
      
      // Check if max session time has already elapsed
      const elapsedTime = Date.now() - this.sessionStartTime;
      console.log('[Session] Resuming session. Elapsed time:', Math.floor(elapsedTime / 1000 / 60), 'minutes');
      
      if (elapsedTime >= MAX_SESSION_LENGTH) {
        console.log('[Session] Maximum session length exceeded on resume');
        this.logoutDueToTimeout('Maximum session length exceeded');
        return;
      }
      
      // Set timer for remaining session time
      const remainingTime = MAX_SESSION_LENGTH - elapsedTime;
      console.log('[Session] Maximum session will expire in:', Math.floor(remainingTime / 1000 / 60), 'minutes');
      this.maxSessionTimer = setTimeout(() => {
        this.logoutDueToTimeout('Maximum session length exceeded');
      }, remainingTime);
    } else {
      this.sessionStartTime = Date.now();
      sessionStorage.setItem('sessionStartTime', this.sessionStartTime.toString());
      console.log('[Session] New session started. Will expire in 24 hours');
      
      // Set max session timer for 24 hours
      this.maxSessionTimer = setTimeout(() => {
        this.logoutDueToTimeout('Maximum session length exceeded');
      }, MAX_SESSION_LENGTH);
    }

    // Set up activity listeners for inactivity timeout
    this.setupInactivityTimer();
    
    // Start periodic status logging
    this.startStatusLogging();
  }

  private startStatusLogging() {
    // Log status every minute
    this.statusLogTimer = setInterval(() => {
      if (this.sessionStartTime) {
        const elapsedTime = Date.now() - this.sessionStartTime;
        const elapsedMinutes = Math.floor(elapsedTime / 1000 / 60);
        const remainingSessionMinutes = Math.floor((MAX_SESSION_LENGTH - elapsedTime) / 1000 / 60);
        
        //console.log('[Session Status] Session active for:', elapsedMinutes, 'minutes | Remaining time:', remainingSessionMinutes, 'minutes');
      }
    }, 60000); // Log every 60 seconds
  }

  private setupInactivityTimer() {
    //console.log('[Session] Setting up inactivity monitoring. Timeout:', INACTIVITY_TIMEOUT / 1000 / 60, 'minutes');
    
    // Listen to user activity events
    const activityEvents$ = merge(
      fromEvent(document, 'mousedown'),
      fromEvent(document, 'keydown'),
      fromEvent(document, 'scroll'),
      fromEvent(document, 'touchstart'),
      fromEvent(document, 'click')
    );

    // Reset inactivity timer on any activity
    activityEvents$.pipe(
      debounceTime(1000) // Debounce to avoid too many resets
    ).subscribe(() => {
      //console.log('[Session] User activity detected - resetting inactivity timer');
      this.resetInactivityTimer();
    });

    // Start initial inactivity timer
    this.resetInactivityTimer();
  }

  private resetInactivityTimer() {
    // Clear existing timer
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
    }

    const timeoutMinutes = INACTIVITY_TIMEOUT / 1000 / 60;
    console.log('[Session] Inactivity timer set - will logout in', timeoutMinutes, 'minutes if no activity');

    // Set new timer
    this.inactivityTimer = setTimeout(() => {
      console.log('[Session] Inactivity timeout reached - logging out');
      this.logoutDueToTimeout('Session expired due to inactivity');
    }, INACTIVITY_TIMEOUT);
  }

  private clearTimers() {
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
      this.inactivityTimer = null;
      console.log('[Session] Inactivity timer cleared');
    }
    
    if (this.maxSessionTimer) {
      clearTimeout(this.maxSessionTimer);
      this.maxSessionTimer = null;
      console.log('[Session] Maximum session timer cleared');
    }

    if (this.statusLogTimer) {
      clearInterval(this.statusLogTimer);
      this.statusLogTimer = null;
      console.log('[Session] Status logging stopped');
    }
  }

  private logoutDueToTimeout(reason: string) {
    console.log('[Session] Auto logout triggered:', reason);
    
    // Clear session storage
    sessionStorage.removeItem('sessionStartTime');
    
    // Perform logout
    this.logout();
  }

  isLoggedIn(): boolean {
    if (!ENABLE_AUTH) return true;
    return this.msalService?.instance.getActiveAccount() != null;
  }

  getUserInfo() {
    if (!ENABLE_AUTH) {
      // Return mock user info when auth disabled
      return {
        name: 'Sayantan',
        email: 'sayantan.d.das@dev365.pwc.com',
        id: 'dev-123'
      };
    }
    const activeAccount = this.msalService?.instance.getActiveAccount(
    );
    if (activeAccount) {
      console.log('Active account:', activeAccount);
      return {
        name: activeAccount.name || activeAccount.username,
        email: activeAccount.username,
        // id: activeAccount.localAccountId
      };
    }
    return null;
  }

  login() {
    if (!ENABLE_AUTH) {
      //console.log('Authentication disabled - skipping login');
      return;
    }
    this.msalService?.loginRedirect({
      //scopes: ['openid','profile']
      scopes: ['User.Read openid profile email']
    });
  }

  logout() {
    if (!ENABLE_AUTH) {
      //console.log('Authentication disabled - skipping logout');
      return;
    }
    
    console.log('[Session] Logout initiated - clearing all timers and session data');
    
    // Clear timers and session data
    this.clearTimers();
    sessionStorage.removeItem('sessionStartTime');
    this.sessionStartTime = null;
    
    this.msalService?.logoutRedirect();
  }

  getLoginStatus(): Observable<InteractionStatus> {
    if (!ENABLE_AUTH) {
      return of('None' as InteractionStatus);
    }
    return this.msalBroadcastService?.inProgress$ || of('None' as InteractionStatus);
  }

  // Get access token for API calls
  async getAccessToken(): Promise<string | null> {
    if (!ENABLE_AUTH) return 'mock-token';
    try {
      const response = await this.msalService?.instance.acquireTokenSilent({
        //scopes: ['openid','profile'],
        scopes: ['User.Read'],
        account: this.msalService.instance.getActiveAccount()!
      });
      return response?.idToken||null;
    } catch (error) {
      //console.error('Error getting access token:', error);
      return null;
    }
  }
}