import { Component, EventEmitter, Output, Input } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CurrentUserService } from '../../core/services/current-user.service';
import { User } from '../../core/models/user.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() featureName: string = 'MCX AI';
  @Input() showSearch: boolean = true;
  @Output() searchChange = new EventEmitter<string>();
  @Output() menuToggle = new EventEmitter<void>();
  @Output() themeToggle = new EventEmitter<void>();
  
  user$: Observable<User | null>;

  constructor(private currentUserService: CurrentUserService) {
    this.user$ = this.currentUserService.user$;
  }
  searchQuery: string = '';

  onSearchChange(): void {
    this.searchChange.emit(this.searchQuery);
  }

  onMenuClick(): void {
    this.menuToggle.emit();
  }

  onThemeClick(): void {
    this.themeToggle.emit();
  }
}
