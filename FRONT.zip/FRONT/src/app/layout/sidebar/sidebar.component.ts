import { Component, EventEmitter, Output, Input } from '@angular/core';


export interface NavItem {
  icon: string;
  label: string;
  badge?: number;
  active?: boolean;
  action?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() expanded: boolean = false;
  @Output() navItemClick = new EventEmitter<string>();
  @Output() expandToggle = new EventEmitter<boolean>();

  navItems: NavItem[] = [
    { icon: 'new-chat', label: 'New Chat', action: 'new-chat' },
    { icon: 'history', label: 'History', action: 'history' },
    { icon: 'analytics', label: 'Analytics', action: 'analytics' }
  ];

  onNavItemClick(action: string): void {
    this.navItemClick.emit(action);
  }

  toggleExpand(): void {
    this.expanded = !this.expanded;
    this.expandToggle.emit(this.expanded);
  }
}
