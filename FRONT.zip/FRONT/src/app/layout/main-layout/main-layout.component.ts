import { Component } from '@angular/core';

import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { SidebarComponent } from '../sidebar/sidebar.component';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, SidebarComponent],
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent {
  sidebarExpanded: boolean = false;
  featureName: string = 'MCX AI';

  onSearchChange(query: string): void {
    console.log('Search query:', query);
    // Implement search logic
  }

  onMenuToggle(): void {
    // Toggle mobile menu
    console.log('Menu toggled');
  }

  onThemeToggle(): void {
    // Handle theme toggle
    console.log('Theme toggled');
  }

  onNavItemClick(action: string): void {
    console.log('Nav action:', action);
    // Handle navigation
  }

  onSidebarExpandToggle(expanded: boolean): void {
    this.sidebarExpanded = expanded;
  }
}
