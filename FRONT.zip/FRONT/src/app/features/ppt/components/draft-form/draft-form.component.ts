import { Component, Output, EventEmitter } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../../../../shared/components/file-upload/file-upload.component';

@Component({
  selector: 'app-draft-form',
  standalone: true,
  imports: [FormsModule, FileUploadComponent],
  templateUrl: './draft-form.component.html',
  styleUrls: ['./draft-form.component.scss']
})
export class DraftFormComponent {
  @Output() submit = new EventEmitter<any>();
  
  topic: string = '';
  slideCount: number = 10;
  referenceFile: File | null = null;

  onFileSelected(file: File): void {
    this.referenceFile = file;
  }

  onFileRemoved(): void {
    this.referenceFile = null;
  }

  onSubmit(): void {
    if (this.topic.trim()) {
      this.submit.emit({
        topic: this.topic,
        slideCount: this.slideCount,
        referenceFile: this.referenceFile
      });
    }
  }
}
