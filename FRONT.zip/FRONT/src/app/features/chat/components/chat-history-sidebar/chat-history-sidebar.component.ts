import { Component, Input, Output, EventEmitter } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { ChatSession } from '../../../../core/models';

@Component({
  selector: 'app-chat-history-sidebar',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './chat-history-sidebar.component.html',
  styleUrls: ['./chat-history-sidebar.component.scss']
})
export class ChatHistorySidebarComponent {
  @Input() sessions: ChatSession[] = [];
  @Input() searchQuery: string = '';
  @Input() isLoading: boolean = false;
  @Output() searchQueryChange = new EventEmitter<string>();
  @Output() sessionLoad = new EventEmitter<string>();
  @Output() sessionDelete = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  getFilteredSessions(): ChatSession[] {
    if (!this.searchQuery.trim()) {
      return this.sessions;
    }
    
    const query = this.searchQuery.toLowerCase();
    return this.sessions.filter(session =>
      session.title.toLowerCase().includes(query)
    );
  }

  onSearchChange(): void {
    this.searchQueryChange.emit(this.searchQuery);
  }

  onLoadSession(sessionId: string): void {
    this.sessionLoad.emit(sessionId);
  }

  onDeleteSession(sessionId: string, event: Event): void {
    event.stopPropagation();
    this.sessionDelete.emit(sessionId);
  }

  onClose(): void {
    this.close.emit();
  }

  formatDate(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    
    return new Date(date).toLocaleDateString();
  }
}
