import { Component, Output, EventEmitter, Input, ViewChild, ElementRef } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { VoiceInputComponent } from '../../../../shared/components/voice-input/voice-input.component';

@Component({
  selector: 'app-chat-input',
  standalone: true,
  imports: [FormsModule, VoiceInputComponent],
  templateUrl: './chat-input.component.html',
  styleUrls: ['./chat-input.component.scss']
})
export class ChatInputComponent {
  @Input() userInput: string = '';
  @Input() isLoading: boolean = false;
  @Input() uploadedFile: File | null = null;
  @Output() userInputChange = new EventEmitter<string>();
  @Output() sendMessage = new EventEmitter<void>();
  @Output() fileSelected = new EventEmitter<File>();
  @Output() fileRemoved = new EventEmitter<void>();
  
  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;
  @ViewChild(VoiceInputComponent) voiceInput?: VoiceInputComponent;
  
  isVoiceInputActive = false;

  onInputChange(): void {
    this.userInputChange.emit(this.userInput);
  }

  onSend(): void {
    if (this.userInput.trim() || this.uploadedFile) {
      this.sendMessage.emit();
    }
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.onSend();
    }
  }

  triggerFileUpload(): void {
    this.fileInput?.nativeElement.click();
  }

  onFileSelected(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      this.fileSelected.emit(file);
    }
  }

  removeFile(): void {
    this.fileRemoved.emit();
    this.clearFileInput();
  }

  clearFileInput(): void {
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  startVoiceInput(): void {
    this.isVoiceInputActive = true;
    setTimeout(() => {
      this.voiceInput?.startListening();
    }, 100);
  }

  onVoiceTranscriptChange(transcript: string): void {
    this.userInput = transcript;
    this.userInputChange.emit(this.userInput);
  }

  onVoiceListeningChange(isListening: boolean): void {
    if (!isListening) {
      this.isVoiceInputActive = false;
    }
  }
}
