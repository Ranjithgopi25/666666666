import { Component, EventEmitter, inject, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule, FormArray } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { firstValueFrom, switchMap, catchError, throwError} from 'rxjs';
import { CurrentUserService } from '../../../core/services/current-user.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-ddc-request-form',
  standalone: true,
  imports: [CommonModule, FileUploadComponent,ReactiveFormsModule],
  templateUrl: './request-form-ddc.html',
  styleUrls: ['./request-form-ddc.scss']
})
export class DDCRequestFormComponent implements OnInit {
  @Output() close = new EventEmitter<void>();
  @Output() ticketCreated = new EventEmitter<{ requestNumber: string; phoenixRdpLink: string }>();

  private currentUserService = inject(CurrentUserService);

  form!: FormGroup;
  requestConfig: any = { "source": "69244907b6aaf264b9629e14", "requestor": "", "requestName": "", "configId": "65bbf3faa00e6a0cab28f969", "configName": "Document Development Center (DDC) Support", "requestTeamMembers": { "roleOptions": [ "Engagement Team Primary", "Engagement Team Member", "Engagement Partner", "Engagement Manager", "Engagement Director" ], "teamMembers": [ { "guidOrEmail": "", "role": "" } ] }, "integrationComponents": [ { "name": "WBS Code", "value": "", "required": true, "subFields": [ { "name": "SEC/Non-SEC Designation", "required": true, "value": "", "options": [ "Yes", "No" ] } ] } ], "fieldComponents": [ { "name": "Due Date/Time", "required": true, "value": "" }, { "name": "Is this request a revision or related to a previous DDC request?", "required": true, "value": "", "options": [ "Yes", "No" ] }, { "name": "Project number of the existing project", "required": true, "value": "", "condition": { "fieldName": "Is this request a revision or related to a previous DDC request?", "operator": "EQUALS", "value": "Yes" } }, { "name": "What's your preferred method of contact?", "required": true, "value": "", "options": [ "Email", "MS Teams", "Google Chat", "Phone" ] }, { "name": "Project Name", "required": true, "value": "" }, { "name": "Is this request in support of billable work already won by the firm? (Engagement work, client deliverables, value reports, audit committee reports, etc.)", "required": true, "value": "", "options": [ "Yes", "No" ] }, { "name": "Is this request in support of winning new work for the firm? (All current pursuit, proposal, RFP/RFP responses, etc. and anything supporting those types of projects)", "required": true, "value": "", "options": [ "Yes", "No" ], "condition": { "fieldName": "Is this request a revision or related to a previous DDC request?", "operator": "EQUALS", "value": "No" } }, { "name": "Company Name", "required": true, "value": "", "condition": { "fieldName": "Is this request in support of winning new work for the firm? (All current pursuit, proposal, RFP/RFP responses, etc. and anything supporting those types of projects)", "operator": "EQUALS", "value": "Yes" } }, { "name": "Which line of service is this project in support of?", "required": true, "value": "", "options": [ "Trust", "Consulting", "Business Services" ] }, { "name": "Is this work in support of:", "required": true, "value": "", "options": [ "Trust", "Consulting", "IFS / Firmwide only" ], "condition": { "fieldName": "Which line of service is this project in support of?", "operator": "EQUALS", "value": "Business Services" } }, { "name": "Project Type", "required": true, "value": "", "options": [ "Dashboard / Form / Survey", "File Type Conversion", "Graphics and Images", "Presentation", "Print Piece", "Pursuit", "Reports", "Single Page Document", "Sites / Mailers", "Video & Animation", "Virtual Whiteboard" ] }, { "name": "Please select the output type(s) required for this Pursuit", "required": true, "value": [], "options": [ "Animated GIF", "Backgrounds", "Banners", "Bio Book", "Bio Page", "Brochure", "Character Animation", "Diagram Recreation", "Flow Chart", "Orals Presentation", "Org Chart", "Pecha Kucha", "Placemats", "Posters", "Presentation", "Proposal on a Page", "RFI", "RFP", "Timeline", "Video", "Wallpaper", "Virtual Whiteboard", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Pursuit" } }, { "name": "Please select the output type(s) required for this report", "required": true, "value": [], "options": [ "Audit Committee Report", "Annual Report", "Thought Leadership", "Value Report", "Whitepaper", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Reports" } }, { "name": "Please select the output type(s) required for this graphic", "required": true, "value": [], "options": [ "Background", "Banner", "Diagram Recreation", "Infographic", "Photo Editing", "Photo Selection", "Wallpaper", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Graphics and Images" } }, { "name": "Please select the output type(s) required for this print piece:", "required": true, "value": [], "options": [ "Brochure", "Name tags", "Poster", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Print Piece" } }, { "name": "Please select the output type(s) required for this document", "required": true, "value": [], "options": [ "Bio page", "Flow Chart", "One-pager", "Org Chart", "Placemat", "Quick Reference Guide / QRG", "Timeline", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Single Page Document" } }, { "name": "Please select the output type required for the site / mailer", "required": true, "value": [], "options": [ "Google Mailer", "Google Site", "SharePoint Site", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Sites / Mailers" } }, { "name": "Please select the output type(s) required for this presentation:", "required": true, "value": [], "options": [ "Demo Deck", "General Presentation", "Template Creation", "Training Deck", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Presentation" } }, { "name": "Please select the output type required for this dashboard / form / survey:", "required": true, "value": [], "options": [ "Automation", "EGA / Dynamic form", "Excel", "Google Script", "Survey Analysis and Visualisation", "Tableau", "Other" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Dashboard / Form / Survey" } }, { "name": "What is the preferred file format for this output?", "required": true, "value": "" }, { "name": "Project Size", "required": true, "value": "", "options": [ "Small", "Medium", "Large" ] }, { "name": "Who is the ultimate end user or audience for this project?", "required": true, "value": "", "options": [ "Client", "External", "Internal", "Both (internal + external)" ] }, { "name": "Audience Description: please provide any additional context (e.g. Campus recruiting, C-Suite, High-visibility conference presentation, etc)", "required": false, "value": "" }, { "name": "Complexity", "required": true, "value": "", "options": [ "Basic (least complex)", "Simple (mid-level complexity)", "Complex (most complex)" ] }, { "name": "Detailed Instructions", "required": true, "value": "" }, { "name": "How would you like your project branded?", "required": true, "value": "", "options": [ "PwC Brand", "Client Brand" ] }, { "name": "Please provide appropriate client brand guides, identity kits, templates, etc.", "required": true, "value": "", "condition": { "fieldName": "How would you like your project branded?", "operator": "EQUALS", "value": "Client Brand" } }, { "name": "Is this project a part of a specific campaign?", "required": true, "value": "", "options": [ "Yes", "No" ] }, { "name": "Which campaign is this for?", "required": true, "value": "", "condition": { "fieldName": "Is this project a part of a specific campaign?", "operator": "EQUALS", "value": "Yes" } }, { "name": "Is there an existing template you want used on this project?", "required": true, "value": "", "options": [ "Yes", "No" ] }, { "name": "Please provide the template as a link or attachment; otherwise, please describe the specific template:", "required": true, "value": "", "condition": { "fieldName": "Is there an existing template you want used on this project?", "operator": "EQUALS", "value": "Yes" } }, { "name": "Is this request from NPT Advisory?", "required": true, "value": "", "options": [ "Yes", "No" ], "condition": { "fieldName": "Project Type", "operator": "EQUALS", "value": "Pursuit" } }, { "name": "Are you already working with and/or is a US-MX Creative Team designer involved in this project?", "required": true, "value": "", "options": [ "Yes", "No" ] }, { "name": "Please provide the US Creative Team Designer's name", "required": true, "value": "", "condition": { "fieldName": "Are you already working with and/or is a US-MX Creative Team designer involved in this project?", "operator": "EQUALS", "value": "Yes" } }, { "name": "I acknowledge that I and/or my team has completed due diligence to secure proper authorization for use of any photos, images and/or logos we have provided to the DDC for this project.", "required": true, "value": [], "options": [ "Yes, I acknowledge" ] }]};
  supportingFiles: File[] = [];
  isGenerating = false;
  minDateTime = '';
  submitErrorMessage: string | null = null;

  constructor(private fb: FormBuilder, private chatService: ChatService) {}

  async ngOnInit(): Promise<void> {
    //await this.getConfigDetails();
    this.setMinDateTime();
    this.buildForm();
    this.setupConditionalValidation();
    this.form.valueChanges.subscribe(() => {
    this.submitErrorMessage = null;
  });

    //(window as any).debugForm = this.form;
  }

   async getConfigDetails(): Promise<void> {
    try{
    this.requestConfig = await firstValueFrom(this.chatService.getPhoenixRequestConfigDdc());
    } catch (error: any) {
      console.error('Error fetching DDC config:', error);
    }
  }

  setMinDateTime(): void {
    const d = new Date();
    d.setHours(d.getHours() + 24);
    this.minDateTime = d.toISOString().slice(0, 16);
  }

  buildForm(): void {
    const group: any = { requestName: ['', Validators.required] };

    // --- Integration Components ---
    this.requestConfig.integrationComponents?.forEach((field: any, i: number) => {
      group[`integration_${i}`] = [field.value || '', field.required ? Validators.required : []];
      field.subFields?.forEach((sub: any, si: number) => {
        group[`integration_${i}_sub_${si}`] = [sub.value || '', sub.required ? Validators.required : []];
      });
    });

    // --- Field Components ---
    this.requestConfig.fieldComponents?.forEach((field: any, i: number) => {
      const isMulti = Array.isArray(field.value);      
      //group[`field_${i}`] = [field.value || (isMulti ? [] : ''), field.required && !field.condition ? Validators.required : []];

      if (isMulti) {
      // Create a FormArray of FormControls initialized with existing values
      const controls = (field.value || []).map((val: any) => this.fb.control(val));
      group[`field_${i}`] = this.fb.array(controls, field.required && !field.condition ? Validators.required : []);
    } else {
      group[`field_${i}`] = [field.value || '', field.required && !field.condition ? Validators.required : []];
    }
    });

    this.form = this.fb.group(group);
  }




  setupConditionalValidation(): void {
    this.requestConfig.fieldComponents?.forEach((field: any, i: number) => {
      if (!field.condition) return;

      const parentIndex = this.requestConfig.fieldComponents.findIndex((f: any) => f.name === field.condition.fieldName);
      const parentControl = this.form.get(`field_${parentIndex}`);
      const currentControl = this.form.get(`field_${i}`);

      parentControl?.valueChanges.subscribe((parentValue: any) => {
        if (this.evaluateCondition(field.condition, parentValue)) {
          currentControl?.setValidators(field.required ? Validators.required : []);
        } else {
          currentControl?.clearValidators();
          currentControl?.setValue(Array.isArray(field.value) ? [] : '');
        }
        currentControl?.updateValueAndValidity({ emitEvent: false });
      });

      // Initialize visibility on load
      if (!this.evaluateCondition(field.condition, parentControl?.value)) {
        currentControl?.clearValidators();
        currentControl?.setValue(Array.isArray(field.value) ? [] : '');
        currentControl?.updateValueAndValidity({ emitEvent: false });
      }
    });
  }

  evaluateCondition(condition: any, parentValue: any): boolean {
    switch (condition.operator) {
      case 'EQUALS':
        return parentValue === condition.value;
      case 'NOT_EQUALS':
        return parentValue !== condition.value;
      default:
        return false;
    }
  }

  isFieldVisible(field: any): boolean {
    if (!field.condition) return true;
    const parentIndex = this.requestConfig.fieldComponents.findIndex((f: any) => f.name === field.condition.fieldName);
    const parentValue = this.form.get(`field_${parentIndex}`)?.value;
    return this.evaluateCondition(field.condition, parentValue);
  }

  isMultiSelect(field: any): boolean {
    return Array.isArray(field.value);
  }

  isDateField(field: any): boolean {
    return field.name.toLowerCase().includes('date');
  }
/*
  toggleMultiSelect(controlName: string, value: string): void {
    const ctrl = this.form.get(controlName);
    if (!ctrl) return;

    const val = ctrl.value as string[];
    const idx = val.indexOf(value);
    if (idx > -1) {
      val.splice(idx, 1);
    } else {
      val.push(value);
    }
    ctrl.setValue([...val]);
  }

  isChecked(controlName: string, value: string): boolean {
    const ctrl = this.form.get(controlName);
    return ctrl?.value?.includes(value);
  }
    */

  isChecked(controlName: string, value: string): boolean {
  const arr = this.form.get(controlName) as FormArray;
  return arr?.value.includes(value);
}

toggleMultiSelect(controlName: string, value: string): void {
  const arr = this.form.get(controlName) as FormArray;
  const index = arr.value.indexOf(value);

  if (index > -1) {
    arr.removeAt(index);
  } else {
    arr.push(this.fb.control(value));
  }
}

  hasIntegrationValue(index: number): boolean {
    return !!this.form.get(`integration_${index}`)?.value;
  }

  onFileSelected(file: File): void {
    this.supportingFiles.push(file);
  }

  async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isGenerating = true;

    const user = await firstValueFrom(this.currentUserService.user$);
    this.requestConfig.requestor = (user?.email || '').toLowerCase().replace('@dev365.', '@');
    this.requestConfig.requestName = this.form.value.requestName;

    // Integration Components
    this.requestConfig.integrationComponents?.forEach((field: any, i: number) => {
      field.value = this.form.value[`integration_${i}`];
      field.subFields?.forEach((sub: any, si: number) => {
        sub.value = this.form.value[`integration_${i}_sub_${si}`];
      });
    });

    // Field Components
    this.requestConfig.fieldComponents?.forEach((field: any, i: number) => {
      let val = this.form.value[`field_${i}`];
      if (this.isDateField(field) && val) {
        val = new Date(val).toISOString();
      }
      field.value = val;
    });

    console.log('FINAL REQUEST JSON:', this.requestConfig);

   
    /*const response = await firstValueFrom(
      this.service.createRequest(this.requestConfig, this.supportingFiles)
    );
    */
   const formData = new FormData();
   formData.append('request', JSON.stringify(this.requestConfig));

      this.supportingFiles.forEach(file => {
        formData.append('files', file); // backend expects "files"
      });

    const response: any = await firstValueFrom(this.chatService.createPhoenixRequest(formData));

    if (response.requestId === "0"){ 
      this.isGenerating = false;
    this.submitErrorMessage = response.errorMessage || 'Unable to submit request. Request creation failed with the error: '+ response.errorMessage;
    return;
}

else{
    console.log('API RESPONSE:', response.requestNumber, response.phoenixRdpLink);

    this.ticketCreated.emit({
      requestNumber: response.requestNumber,
      phoenixRdpLink: response.phoenixRdpLink
    });

    this.isGenerating = false;
    this.close.emit();
  }
  
    
  
  
  }

  cancel(): void {
    this.close.emit();
  }
}


