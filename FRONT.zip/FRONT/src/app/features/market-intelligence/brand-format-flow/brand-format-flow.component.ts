import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';

@Component({
    selector: 'app-mi-brand-format-flow',
    imports: [FormsModule],
    templateUrl: './brand-format-flow.component.html',
    styleUrls: ['./brand-format-flow.component.scss']
})
export class MiBrandFormatFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(private miFlowService: MiFlowService) {}

  ngOnInit(): void {
    this.miFlowService.brandFormatFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => this.isOpen = isOpen);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onClose(): void {
    this.miFlowService.closeBrandFormatFlow();
  }
}
