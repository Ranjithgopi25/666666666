import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export type MiFlowType = 'conduct-research' | 'create-pov' | 'prepare-client-meeting' | 'gather-proposal-insights' | 'target-industry-insights' | null;

/**
 * Market Intelligence Flow Service
 * Manages all flow states for Market Intelligence feature
 * Completely isolated from Thought Leadership and DDC services
 */
@Injectable({
  providedIn: 'root'
})
export class MiFlowService {
  private activeFlowSubject = new BehaviorSubject<MiFlowType>(null);
  private draftContentFlowOpen = new BehaviorSubject<boolean>(false);
  private conductResearchFlowOpen = new BehaviorSubject<boolean>(false);
  private editContentFlowOpen = new BehaviorSubject<boolean>(false);
  private formatTranslatorFlowOpen = new BehaviorSubject<boolean>(false);
  private generatePodcastFlowOpen = new BehaviorSubject<boolean>(false);
  private refineContentFlowOpen = new BehaviorSubject<boolean>(false);
  private brandFormatFlowOpen = new BehaviorSubject<boolean>(false);
  private professionalPolishFlowOpen = new BehaviorSubject<boolean>(false);
  private createPOVFlowOpen = new BehaviorSubject<boolean>(false);
  private prepareClientMeetingFlowOpen = new BehaviorSubject<boolean>(false);
  private gatherProposalInsightsFlowOpen = new BehaviorSubject<boolean>(false);
  private targetIndustryInsightsFlowOpen = new BehaviorSubject<boolean>(false);

  private preselectedContentTypeSubject = new BehaviorSubject<string | null>(null);
  public preselectedContentType$: Observable<string | null> = this.preselectedContentTypeSubject.asObservable();

  private preselectedTopicSubject = new BehaviorSubject<string | null>(null);
  public preselectedTopic$: Observable<string | null> = this.preselectedTopicSubject.asObservable();

  public activeFlow$: Observable<MiFlowType> = this.activeFlowSubject.asObservable();
  
  draftContentFlow$ = this.draftContentFlowOpen.asObservable();
  conductResearchFlow$ = this.conductResearchFlowOpen.asObservable();
  editContentFlow$ = this.editContentFlowOpen.asObservable();
  formatTranslatorFlow$ = this.formatTranslatorFlowOpen.asObservable();
  generatePodcastFlow$ = this.generatePodcastFlowOpen.asObservable();
  refineContentFlow$ = this.refineContentFlowOpen.asObservable();
  brandFormatFlow$ = this.brandFormatFlowOpen.asObservable();
  professionalPolishFlow$ = this.professionalPolishFlowOpen.asObservable();
  createPOVFlow$ = this.createPOVFlowOpen.asObservable();
  prepareClientMeetingFlow$ = this.prepareClientMeetingFlowOpen.asObservable();
  gatherProposalInsightsFlow$ = this.gatherProposalInsightsFlowOpen.asObservable();
  targetIndustryInsightsFlow$ = this.targetIndustryInsightsFlowOpen.asObservable();

  constructor() {
    console.log('[MiFlowService] Initialized - Market Intelligence service started');
  }

  openDraftContentFlow(): void {
    console.log('[MiFlowService] Opening draft content flow');
    this.draftContentFlowOpen.next(true);
  }

  closeDraftContentFlow(): void {
    console.log('[MiFlowService] Closing draft content flow');
    this.draftContentFlowOpen.next(false);
  }

  openConductResearchFlow(): void {
    console.log('[MiFlowService] Opening conduct research flow');
    this.conductResearchFlowOpen.next(true);
  }

  closeConductResearchFlow(): void {
    console.log('[MiFlowService] Closing conduct research flow');
    this.conductResearchFlowOpen.next(false);
  }

  openCreatePOVFlow(): void {
    console.log('[MiFlowService] Opening create POV flow');
    this.createPOVFlowOpen.next(true);
  }

  closeCreatePOVFlow(): void {
    console.log('[MiFlowService] Closing create POV flow');
    this.createPOVFlowOpen.next(false);
  }

  openPrepareClientMeetingFlow(): void {
    console.log('[MiFlowService] Opening prepare client meeting flow');
    this.prepareClientMeetingFlowOpen.next(true);
  }

  closePrepareClientMeetingFlow(): void {
    console.log('[MiFlowService] Closing prepare client meeting flow');
    this.prepareClientMeetingFlowOpen.next(false);
  }

  openGatherProposalInsightsFlow(): void {
    console.log('[MiFlowService] Opening gather proposal inputs flow');
    this.gatherProposalInsightsFlowOpen.next(true);
  }

  closeGatherProposalInsightsFlow(): void {
    console.log('[MiFlowService] Closing gather proposal inputs flow');
    this.gatherProposalInsightsFlowOpen.next(false);
  }

  openTargetIndustryInsightsFlow(): void {
    console.log('[MiFlowService] Opening gather proposal inputs flow');
    this.targetIndustryInsightsFlowOpen.next(true);
  }

  closeTargetIndustryInsightsFlow(): void {
    console.log('[MiFlowService] Closing gather proposal inputs flow');
    this.targetIndustryInsightsFlowOpen.next(false);
  }
   openEditContentFlow(): void {
    console.log('[MiFlowService] Opening edit content flow');
    this.editContentFlowOpen.next(true);
  }

  closeEditContentFlow(): void {
    console.log('[MiFlowService] Closing edit content flow');
    this.editContentFlowOpen.next(false);
  }

  openFormatTranslatorFlow(): void {
    console.log('[MiFlowService] Opening format translator flow');
    this.formatTranslatorFlowOpen.next(true);
  }

  closeFormatTranslatorFlow(): void {
    console.log('[MiFlowService] Closing format translator flow');
    this.formatTranslatorFlowOpen.next(false);
  }

  openGeneratePodcastFlow(): void {
    console.log('[MiFlowService] Opening generate podcast flow');
    this.generatePodcastFlowOpen.next(true);
  }

  closeGeneratePodcastFlow(): void {
    console.log('[MiFlowService] Closing generate podcast flow');
    this.generatePodcastFlowOpen.next(false);
  }

  openRefineContentFlow(): void {
    console.log('[MiFlowService] Opening refine content flow');
    this.refineContentFlowOpen.next(true);
  }

  closeRefineContentFlow(): void {
    console.log('[MiFlowService] Closing refine content flow');
    this.refineContentFlowOpen.next(false);
  }

  openBrandFormatFlow(): void {
    console.log('[MiFlowService] Opening brand format flow');
    this.brandFormatFlowOpen.next(true);
  }

  closeBrandFormatFlow(): void {
    console.log('[MiFlowService] Closing brand format flow');
    this.brandFormatFlowOpen.next(false);
  }

  openProfessionalPolishFlow(): void {
    console.log('[MiFlowService] Opening professional polish flow');
    this.professionalPolishFlowOpen.next(true);
  }

  closeProfessionalPolishFlow(): void {
    console.log('[MiFlowService] Closing professional polish flow');
    this.professionalPolishFlowOpen.next(false);
  }

  private guidedDialogSubject = new BehaviorSubject<boolean>(false);
  public guidedDialog$ = this.guidedDialogSubject.asObservable();

  openGuidedDialog(): void {
    this.guidedDialogSubject.next(true);
  }

  closeGuidedDialog(): void {
    this.guidedDialogSubject.next(false);
  }


  get currentFlow(): MiFlowType {
      return this.activeFlowSubject.value;
    }

  get isGuidedDialogOpen(): boolean {
    return this.guidedDialogSubject.value;
  }  

  closeAllFlows(): void {
    console.log('[MiFlowService] Closing all flows');
    this.draftContentFlowOpen.next(false);
    this.conductResearchFlowOpen.next(false);
    this.editContentFlowOpen.next(false);
    this.formatTranslatorFlowOpen.next(false);
    this.generatePodcastFlowOpen.next(false);
    this.refineContentFlowOpen.next(false);
    this.brandFormatFlowOpen.next(false);
    this.professionalPolishFlowOpen.next(false);
    this.createPOVFlowOpen.next(false);
    this.prepareClientMeetingFlowOpen.next(false);
    this.gatherProposalInsightsFlowOpen.next(false);
    this.targetIndustryInsightsFlowOpen.next(false);
    this.activeFlowSubject.next(null);
  }

  closeFlow(): void {
    this.activeFlowSubject.next(null);
    this.preselectedContentTypeSubject.next(null);
    this.preselectedTopicSubject.next(null);
  }

  openFlow(flowType: 'conduct-research' | 'create-pov' | 'prepare-client-meeting' | 'gather-proposal-insights' | 'target-industry-insights'): void {
    console.log('[MiFlowService] Opening flow:', flowType);
    
    // Close all flows first
    this.closeAllFlows();
    
    // Set the active flow
    this.activeFlowSubject.next(flowType);

    // Open the requested flow
    switch (flowType) {
      // case 'draft-content':
      //   this.openDraftContentFlow();
      //   break;
      case 'conduct-research':
        this.openConductResearchFlow();
        break;
        case 'create-pov':
        //console.log('Opening create POV flow test');
        this.openCreatePOVFlow();
        break;
        case 'prepare-client-meeting':
        this.openPrepareClientMeetingFlow();
        break;
        case 'gather-proposal-insights':
        this.openGatherProposalInsightsFlow();
        break;
        case 'target-industry-insights':
        this.openTargetIndustryInsightsFlow();
        break;

      // case 'edit-content':
      //   this.openEditContentFlow();
      //   break;
      // case 'refine-content':
      //   this.openRefineContentFlow();
      //   break;
      // case 'format-translator':
      //   this.openFormatTranslatorFlow();
      //   break;
      // case 'generate-podcast':
      //   this.openGeneratePodcastFlow();
      //   break;
      // case 'brand-format':
      //   this.openBrandFormatFlow();
      //   break;
      // case 'professional-polish':
      //   this.openProfessionalPolishFlow();
      //   break;
      default:
        console.warn('[MiFlowService] Unknown flow type:', flowType);
    }
  }
  


  // processDraftContent(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing draft content:', message, context);
  // }

  processConductResearch(message: any, context: any): void {
    console.log('[MiFlowService] Processing conduct research:', message, context);
  }
  processCreatePOV(message: any, context: any): void {
    console.log('[MiFlowService] Processing create POV:', message, context);
  }
  processPrepareClientMeeting(message: any, context: any): void {
    console.log('[MiFlowService] Processing prepare client meeting:', message, context);
  }
  processGatherProposalInsights(message: any, context: any): void {
    console.log('[MiFlowService] Processing gather proposal insights:', message, context);
  }

  processTargetIndustryInsights(message: any, context: any): void {
    console.log('[MiFlowService] Processing target industry insights:', message, context);
  }

  // processEditContent(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing edit content:', message, context);
  // }

  // processFormatTranslate(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing format translate:', message, context);
  // }

  // processGeneratePodcast(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing generate podcast:', message, context);
  // }

  // processRefineContent(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing refine content:', message, context);
  // }

  // processBrandFormat(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing brand format:', message, context);
  // }

  // processProfessionalPolish(message: any, context: any): void {
  //   console.log('[MiFlowService] Processing professional polish:', message, context);
  // }
}
