import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';

@Component({
    selector: 'app-mi-generate-podcast-flow',
    imports: [FormsModule],
    templateUrl: './generate-podcast-flow.component.html',
    styleUrls: ['./generate-podcast-flow.component.scss']
})
export class MiGeneratePodcastFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(private miFlowService: MiFlowService) {}

  ngOnInit(): void {
    this.miFlowService.generatePodcastFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => this.isOpen = isOpen);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onClose(): void {
    this.miFlowService.closeGeneratePodcastFlow();
  }
}
