import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

@Component({
    selector: 'app-ddc-format-translator-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './format-translator-flow.component.html',
    styleUrls: ['./format-translator-flow.component.scss']
})
export class FormatTranslatorFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  
  // Format toggles
  createCaseStudy = false;
  generatePodcast = false;
  
  // Case Study options
  selectedTemplate = '';
  customTemplateFile: File | null = null;
  
  // Case Study styles
  onePageTextHeavy = false;
  onePageVisual = false;
  multiPageVisual = false;
  
  // Reference format (optional)
  referenceFormatFile: File | null = null;
  
  // Additional fields
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'ddc-format-translator';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[FormatTranslatorFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.createCaseStudy = false;
    this.generatePodcast = false;
    this.selectedTemplate = '';
    this.customTemplateFile = null;
    this.onePageTextHeavy = false;
    this.onePageVisual = false;
    this.multiPageVisual = false;
    this.referenceFormatFile = null;
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  onReferenceFileSelected(file: File): void {
    this.referenceFormatFile = file;
  }

  onFormatChange(): void {
    // Clear Case Study options if it's deselected
    if (!this.createCaseStudy) {
      this.selectedTemplate = '';
      this.customTemplateFile = null;
      this.onePageTextHeavy = false;
      this.onePageVisual = false;
      this.multiPageVisual = false;
      this.referenceFormatFile = null;
    }
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  onTemplateChange(): void {
    if (!this.needsCustomTemplate) {
      this.customTemplateFile = null;
    }
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    
    // At least one format must be selected
    if (!this.createCaseStudy && !this.generatePodcast) return false;
    
    // If Case Study is selected, validate its requirements
    if (this.createCaseStudy) {
      if (!this.selectedTemplate.trim()) return false;
      if (this.needsCustomTemplate && !this.customTemplateFile) return false;
      // At least one style must be selected
      if (!this.onePageTextHeavy && !this.onePageVisual && !this.multiPageVisual) return false;
    }
    
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const formats = [];
      
      if (this.createCaseStudy) {
        const caseStudyConfig: any = {
          id: 'case-study',
          label: 'Create Case Study',
          template: this.selectedTemplate,
          styles: []
        };
        
        if (this.customTemplateFile) {
          formData.append('case_study_template_file', this.customTemplateFile);
        }
        
        if (this.onePageTextHeavy) {
          caseStudyConfig.styles.push({ id: 'one-page-text-heavy', label: 'One-page Text Heavy' });
        }
        if (this.onePageVisual) {
          caseStudyConfig.styles.push({ id: 'one-page-visual', label: 'One-page Visual' });
          
          if (this.referenceFormatFile) {
            formData.append('reference_format_file', this.referenceFormatFile);
          }
        }
        if (this.multiPageVisual) {
          caseStudyConfig.styles.push({ id: 'multi-page-visual', label: 'Multi-Page Visual' });
        }
        
        formats.push(caseStudyConfig);
      }
      
      if (this.generatePodcast) {
        formats.push({ id: 'podcast', label: 'Generate Podcast' });
      }
      
      formData.append('formats', JSON.stringify(formats));

      console.log('[FormatTranslatorFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        createCaseStudy: this.createCaseStudy,
        generatePodcast: this.generatePodcast,
        template: this.selectedTemplate,
        hasCustomTemplate: !!this.customTemplateFile,
        hasReferenceFormat: !!this.referenceFormatFile,
        formats: formats
      });

      this.streamSubscription = this.chatService.streamDdcFormatTranslator(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[FormatTranslatorFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error translating the format. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[FormatTranslatorFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[FormatTranslatorFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    console.log('[FormatTranslatorFlow] Download triggered');
  }
}
