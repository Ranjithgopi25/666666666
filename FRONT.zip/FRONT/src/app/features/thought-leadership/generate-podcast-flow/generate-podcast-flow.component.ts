import { Component, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { GuidedDialogComponent } from '../../../shared/components/guided-dialog/guided-dialog.component';

interface PodcastForm {
  topic: string;
  podcastStyle: 'dialogue' | 'monologue';
  keyPoints: string;
  customization: string;
  referenceFiles: File[];
  referenceUrls: string;
  speaker1Name: string;
  speaker1Voice: string;
  speaker1Accent: string;
  speaker2Name: string;
  speaker2Voice: string;
  speaker2Accent: string;
}

@Component({
    selector: 'app-generate-podcast-flow',
    imports: [FormsModule, GuidedDialogComponent],
    templateUrl: './generate-podcast-flow.component.html',
    styleUrls: ['./generate-podcast-flow.component.scss']
})
export class GeneratePodcastFlowComponent implements OnInit {
  currentStep: number = 1;
  totalSteps: number = 4;
  isGenerating: boolean = false;
  generatedScript: string = '';
  fileReadError: string = '';
  podcastAudioUrl: string = '';
  podcastFilename: string = 'podcast.mp3';
  
  formData: PodcastForm = {
    topic: '',
    podcastStyle: 'dialogue',
    keyPoints: '',
    customization: '',
    referenceFiles: [],
    referenceUrls: '',
    speaker1Name: 'Sarah',
    speaker1Voice: 'Female',
    speaker1Accent: 'American',
    speaker2Name: 'Michael',
    speaker2Voice: 'Male',
    speaker2Accent: 'American'
  };

  voiceOptions = ['Male', 'Female'];
  accentOptions = ['American', 'British', 'Australian', 'Canadian', 'Indian'];

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {}

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'generate-podcast';
  }

  onClose(): void {
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  resetForm(): void {
    this.currentStep = 1;
    this.isGenerating = false;
    this.generatedScript = '';
    this.podcastAudioUrl = '';
    this.formData = {
      topic: '',
      podcastStyle: 'dialogue',
      keyPoints: '',
      customization: '',
      referenceFiles: [],
      referenceUrls: '',
      speaker1Name: 'Sarah',
      speaker1Voice: 'Female',
      speaker1Accent: 'American',
      speaker2Name: 'Michael',
      speaker2Voice: 'Male',
      speaker2Accent: 'American'
    };
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  previousStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  canProceed(): boolean {
    switch (this.currentStep) {
      case 1:
        return this.formData.topic.trim().length > 0;
      case 2:
        return true; // Podcast style always has a default value
      case 3:
        return true; // References are optional
      default:
        return true;
    }
  }

  onFileSelect(event: any): void {
    const files = Array.from(event.target.files) as File[];
    this.formData.referenceFiles = files;
  }

  async generatePodcast(): Promise<void> {
    this.isGenerating = true;
    this.currentStep = 4;
    this.fileReadError = '';
    this.podcastAudioUrl = '';
    this.generatedScript = '';
    
    let contentText = `Topic: ${this.formData.topic}. Key Points: ${this.formData.keyPoints}.`;
    
    if (this.formData.referenceUrls) {
      contentText += ` Reference URLs: ${this.formData.referenceUrls}`;
    }

    const podcastFiles = this.formData.referenceFiles && this.formData.referenceFiles.length > 0 
      ? this.formData.referenceFiles 
      : null;

    let scriptContent = '';
    let audioBase64 = '';

    this.chatService.generatePodcast(
      podcastFiles,
      contentText,
      this.formData.customization || null,
      this.formData.podcastStyle,
      this.formData.speaker1Name,
      this.formData.speaker1Voice,
      this.formData.speaker1Accent,
      this.formData.speaker2Name,
      this.formData.speaker2Voice,
      this.formData.speaker2Accent
    ).subscribe({
      next: (data) => {
        if (data.type === 'progress') {
          this.generatedScript = `Generating podcast...\n\n${data.message}`;
        } else if (data.type === 'script') {
          scriptContent = data.content;
          this.generatedScript = `📻 **Podcast Generated Successfully!**\n\n**Script:**\n\n${scriptContent}\n\n`;
        } else if (data.type === 'complete') {
          audioBase64 = data.audio;
          this.generatedScript += `\n🎧 **Audio Ready!** Listen to your podcast below or download it as an MP3 file.\n\n`;
          
          const audioBlob = this.base64ToBlob(audioBase64, 'audio/mpeg');
          const audioUrl = URL.createObjectURL(audioBlob);
          
          this.podcastAudioUrl = audioUrl;
          this.isGenerating = false;
        } else if (data.type === 'error') {
          this.generatedScript = `❌ Error generating podcast: ${data.message}`;
          this.isGenerating = false;
        }
      },
      error: (error) => {
        console.error('Error generating podcast:', error);
        this.generatedScript = `❌ Error generating podcast: ${error.message || 'Unknown error occurred'}`;
        this.isGenerating = false;
      }
    });
  }

  private base64ToBlob(base64: string, contentType: string): Blob {
    const byteCharacters = atob(base64);
    const byteArrays = [];
    
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    
    return new Blob(byteArrays, { type: contentType });
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.generatedScript);
  }

  downloadPodcast(): void {
    if (this.podcastAudioUrl && this.podcastFilename) {
      const link = document.createElement('a');
      link.href = this.podcastAudioUrl;
      link.download = this.podcastFilename;
      link.click();
    }
  }
}
