import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Subject, Subscription, takeUntil, Observable } from 'rxjs';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { ThoughtLeadershipMetadata } from '../../../core/models';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-refine-content-flow',
  standalone: true,
  imports: [CommonModule, FormsModule, FileUploadComponent, MatSelectModule, MatOptionModule, MatFormFieldModule],
  templateUrl: './refine-content-flow.component.html',
  styleUrls: ['./refine-content-flow.component.scss']
})
export class RefineContentFlowComponent implements OnInit, OnDestroy {
  @Output() contentGenerated = new EventEmitter<string>();
  @Output() streamToChat = new EventEmitter<{userMessage: string, streamObservable: any, fileName?: string, metadata?: ThoughtLeadershipMetadata}>();
  isGenerating = false;
  refinedContent = '';
  refinedTitle = '';
  refinedContentBody = '';
  
  // File upload
  uploadedFile: File | null = null;
  uploadedFileWordCount = 'uploaded content';
  
  // Service toggles - all ON by default
  expandCompressContent = false;
  adjustAudienceTone = false;
  enhanceResearch = false;
  editContent = false;
  provideSuggestions = false;
  
  // Edit Content sub-options (editor types) - all ON by default
  developmentEditor = true;
  contentEditor = true;
  lineEditor = true;
  copyEditor = true;
  pwcBrandEditor = true; // Always true, disabled in UI
  
  // Enhance Research sub-options - sources ON by default
  researchTopics = '';
  pwcContentLink = true;
  pwcProprietaryResearch = true;
  pwcLicensedThirdParty = true;
  externalResearch = true;
  researchDocumentFile: File | null = null;
  researchLinks = '';
  selectSpecificPwcSources = false;
  allPwcProprietarySources = false;
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;
  allPwcThirdPartySources = false;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;
  
pwcProprietarySources = [
    { name: 'PwC Industry Edge', selected: false },
    { name: 'PwC Insights', selected: false },
    { name: 's+b Journal', selected: false },
    { name: 'Executive Leadership Hub', selected: false },
    { name: 'The Exchange', selected: false },
    { name: 'PwC Connected Source', selected: false },
    { name: 'PwC Benchmarking', selected: false },
    //{ name: 'Insights Factory', selected: false },
    //{ name: 'PwC Intelligence', selected: false },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    // { name: 'Client Success Stories', selected: true },
    // { name: 'Inside Industries', selected: false },
    // { name: 'Value Store', selected: false }
  ];

  pwcThirdPartySources = [
  { name: 'Factiva', selected: false },
    { name: 'S&P Global- Capital IQ Xpressfeed', selected: false },
    { name: 'IBIS World', selected: false },
    { name: 'BoardEx', selected: false },
    // { name: 'S&P Global- Connect', selected: true },
    // { name: 'Audit Analytics', selected: true },
    // { name: 'S&P Global- SNL Insurance', selected: true },
    // { name: 'Claritas', selected: true },
    // { name: 'Equifax', selected: true },
    // { name: 'Equifax IXI', selected: true },
    // { name: 'Definitive Healthcare Provider Database', selected: true },
    // { name: 'Sg2 Health Care Intelligence', selected: true },
    // //{ name: 'Strata Market Insights', selected: true },
    // //{ name: 'CompanyIQ', selected: true },
    // { name: 'Global Data(Retail)', selected: true },
    // { name: 'Technology Business Review', selected: true },
    
    // //{ name: 'IDC', selected: true },
    // { name: 'CFRA Industry Surveys', selected: true }
];

  // Conditional fields
  wordLimitExpandCompress: number = 0;
  maxWordLimitExpandCompress: number = 0;
  // Inline background style for the slider to color the left side up to the thumb
  wordLimitSliderBackground = '';
  selectedAudienceTone = '';
  audienceToneInput = '';
  wordLimitResearch = '';

  // Audience/Tone dropdown options
  audienceToneOptions = [
    'Mediagenic',
    'Professional Tone - CEO',
    'Professional Tone - CTO',
    'Professional Tone - CFO',
    'Casual Tone',
    'Others'
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService
  ) {}

  ngOnInit(): void {
    this.tlFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe((flow: any) => {
        if (flow === 'refine-content') {
          // Flow opened - reset to ensure fresh state
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[RefineContentFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'refine-content';
  }

  onClose(): void {
    this.cancelStream();
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.tlFlowService.closeFlow();
    this.tlFlowService.openGuidedDialog();
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.uploadedFileWordCount = 'uploaded content';
    this.expandCompressContent = false;
    this.adjustAudienceTone = false;
    this.enhanceResearch = false;
    this.editContent = false;
    this.provideSuggestions = false;
    this.developmentEditor = true;
    this.contentEditor = true;
    this.lineEditor = true;
    this.copyEditor = true;
    this.pwcBrandEditor = true;
    this.researchTopics = '';
    this.pwcContentLink = true;
    this.pwcProprietaryResearch = true;
    this.pwcLicensedThirdParty = true;
    this.externalResearch = true;
    this.researchDocumentFile = null;
    this.researchLinks = '';
    this.selectSpecificPwcSources = false;
    this.allPwcProprietarySources = false;
    this.pwcSource1 = false;
    this.pwcSource2 = false;
    this.pwcSource3 = false;
    this.pwcSource4 = false;
    this.allPwcThirdPartySources = false;
    this.pwcThirdPartySource1 = false;
    this.pwcThirdPartySource2 = false;
    this.pwcThirdPartySource3 = false;
    this.pwcThirdPartySource4 = false;
    this.wordLimitExpandCompress = 0;
    this.maxWordLimitExpandCompress = 0;
    this.updateSliderBackground(this.wordLimitExpandCompress);
    this.selectedAudienceTone = '';
    this.audienceToneInput = '';
    this.wordLimitResearch = '';
      this.refinedContent = '';
    this.refinedTitle = '';
    this.refinedContentBody = '';
    this.isGenerating = false;
  }

  private parseRefinedContent(): void {
    if (!this.refinedContent) {
      this.refinedTitle = '';
      this.refinedContentBody = '';
      return;
    }

    // Parse title from format: **Title**\n\nContent
    const titleMatch = this.refinedContent.match(/^\*\*(.+?)\*\*\s*\n\n/);
    if (titleMatch) {
      this.refinedTitle = titleMatch[1];
      // Extract content after title (skip title line and blank line)
      const contentStart = titleMatch[0].length;
      this.refinedContentBody = this.refinedContent.substring(contentStart).trim();
    } else {
      // Try alternative format: **Title**\nContent (single newline)
      const titleMatchAlt = this.refinedContent.match(/^\*\*(.+?)\*\*\s*\n/);
      if (titleMatchAlt) {
        this.refinedTitle = titleMatchAlt[1];
        const contentStart = titleMatchAlt[0].length;
        this.refinedContentBody = this.refinedContent.substring(contentStart).trim();
      } else {
        // No title found, use entire content as body
        this.refinedTitle = '';
        this.refinedContentBody = this.refinedContent;
      }
    }
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
    // Extract word count from file
    this.extractWordCount(file);
  }

  private async extractWordCount(file: File): Promise<void> {
    const fileExtension = file.name.toLowerCase().split('.').pop() || '';
    
    // Show processing state for PDF/DOCX files
    if (fileExtension === 'pdf' || fileExtension === 'docx' || fileExtension === 'doc') {
      this.uploadedFileWordCount = 'processing...';
    }
    
    try {
      const text = await this.extractFileText(file);
      if (text && text.trim()) {
        const wordCount = text.trim().split(/\s+/).length;
        this.uploadedFileWordCount = `${wordCount}`;
        // Calculate max word limit and set initial slider value
        this.calculateMaxWordLimit(wordCount);
        this.wordLimitExpandCompress = wordCount;
        this.updateSliderBackground(this.wordLimitExpandCompress);
      } else {
        this.uploadedFileWordCount = 'uploaded content';
        this.calculateMaxWordLimit(100); // Default fallback
        this.wordLimitExpandCompress = 100;
        this.updateSliderBackground(this.wordLimitExpandCompress);
      }
    } catch (error) {
      console.error('Error reading file for word count:', error);
      this.uploadedFileWordCount = 'uploaded content';
      this.calculateMaxWordLimit(100); // Default fallback
      this.wordLimitExpandCompress = 100;
      this.updateSliderBackground(this.wordLimitExpandCompress);
    }
  }

  private calculateMaxWordLimit(wordCount: number): void {
    // Calculate max as 3x word count, rounded to nearest 100
    const maxLimit = Math.round((wordCount * 3) / 100) * 100;
    this.maxWordLimitExpandCompress = maxLimit;
  }

  private async extractFileText(file: File): Promise<string> {
    const fileExtension = file.name.toLowerCase().split('.').pop() || '';
    
    // For text-based files, read directly
    if (fileExtension === 'txt' || fileExtension === 'md') {
      return await file.text();
    }
    
    // For PDF, DOCX, DOC - use backend API
    if (fileExtension === 'pdf' || fileExtension === 'docx' || fileExtension === 'doc') {
      const formData = new FormData();
      formData.append('file', file);
      
      try {
        // Get API URL from environment (supports runtime config via window._env)
        const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
        const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/export/extract-text`, {
          method: 'POST',
          body: formData
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error(`[RefineContentFlow] Extract text failed: ${response.status} ${response.statusText}`, errorText);
          throw new Error(`Failed to extract text from ${fileExtension.toUpperCase()} file: ${response.statusText}`);
        }
        
        const data = await response.json();
        if (!data.text || !data.text.trim()) {
          throw new Error(`No text content extracted from ${fileExtension.toUpperCase()} file`);
        }
        
        return data.text;
      } catch (error) {
        console.error(`[RefineContentFlow] Error extracting text from ${fileExtension} file:`, error);
        throw error;
      }
    }
    
    // Fallback: try to read as text
    try {
      return await file.text();
    } catch (error) {
      console.error('[RefineContentFlow] Error reading file as text:', error);
      throw new Error('Unable to read file content. Please ensure the file is a supported format (PDF, DOCX, TXT, MD).');
    }
  }

  onServiceToggle(service: string): void {
    // Clear conditional fields when service is toggled off
    if (service === 'expand-compress' && !this.expandCompressContent) {
      this.wordLimitExpandCompress = this.uploadedFileWordCount ? parseInt(this.uploadedFileWordCount.toString()) : 0;
      this.updateSliderBackground(this.wordLimitExpandCompress);
    }
    if (service === 'audience-tone' && !this.adjustAudienceTone) {
      this.selectedAudienceTone = '';
      this.audienceToneInput = '';
    }
    if (service === 'research' && !this.enhanceResearch) {
      this.wordLimitResearch = '';
      this.researchTopics = '';
      this.pwcContentLink = false;
      this.pwcProprietaryResearch = false;
      this.pwcLicensedThirdParty = false;
      this.externalResearch = false;
      this.researchDocumentFile = null;
      this.researchLinks = '';
      this.selectSpecificPwcSources = false;
      this.allPwcProprietarySources = false;
      this.pwcSource1 = false;
      this.pwcSource2 = false;
      this.pwcSource3 = false;
      this.pwcSource4 = false;
      this.allPwcThirdPartySources = false;
      this.pwcThirdPartySource1 = false;
      this.pwcThirdPartySource2 = false;
      this.pwcThirdPartySource3 = false;
      this.pwcThirdPartySource4 = false;
    }
    if (service === 'edit-content' && !this.editContent) {
      // Reset editor selections to defaults when Edit Content is toggled off
      this.developmentEditor = true;
      this.contentEditor = true;
      this.lineEditor = true;
      this.copyEditor = true;
      this.pwcBrandEditor = true;
    }
  }

  onWordLimitChange(): void {
    // Update the slider background to color the track to the left of the thumb
    this.updateSliderBackground(this.wordLimitExpandCompress);
  }

  private updateSliderBackground(value: number): void {
    const min = 50;
    const max = this.maxWordLimitExpandCompress || Math.max(value, min);
    // guard against division by zero
    const pct = max > min ? Math.round(((value - min) / (max - min)) * 100) : 0;
    const clamped = Math.max(0, Math.min(100, pct));
    this.wordLimitSliderBackground = `linear-gradient(to right, #fd5108 0%, #fd5108 ${clamped}%, #E5E7EB ${clamped}%, #E5E7EB 100%)`;
  }

  onResearchDocumentSelected(file: File): void {
    this.researchDocumentFile = file;
  }

  onAllPwcProprietarySourcesChange(): void {
    const value = this.allPwcProprietarySources;
    this.pwcSource1 = value;
    this.pwcSource2 = value;
    this.pwcSource3 = value;
    this.pwcSource4 = value;
  }

  onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  onAllPwcThirdPartySourcesChange(): void {
    const value = this.allPwcThirdPartySources;
    this.pwcThirdPartySource1 = value;
    this.pwcThirdPartySource2 = value;
    this.pwcThirdPartySource3 = value;
    this.pwcThirdPartySource4 = value;
  }

  onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}


onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}

  get showPwcSourceSelection(): boolean {
    return this.enhanceResearch && (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }

  get canRefine(): boolean {
    if (!this.uploadedFile) return false;
    
    // At least one service must be selected
    if (!this.expandCompressContent && !this.adjustAudienceTone && 
        !this.enhanceResearch && !this.editContent && !this.provideSuggestions) {
      return false;
    }
    
    // Validate required conditional fields when their toggles are ON
    if (this.expandCompressContent && !this.wordLimitExpandCompress) {
      return false;
    }
    
    if (this.adjustAudienceTone) {
      if (!this.selectedAudienceTone) {
        return false;
      }
      // If "Others" is selected, require custom text input
      if (this.selectedAudienceTone === 'Others' && !this.audienceToneInput.trim()) {
        return false;
      }
    }
    
    return true;
  }

  async refineContent(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    this.isGenerating = true;
    this.refinedContent = '';
    this.refinedTitle = '';
    this.refinedContentBody = '';

    try {
      // Extract text from uploaded file
      const contentText = await this.extractFileText(this.uploadedFile);
      
      // Build service instructions
      // Only include services with meaningful parameters
      const services = [];
      console.log(`Word limit: ${this.wordLimitExpandCompress}`);
      // Expand/Compress - only if word limit is specified
      if (this.expandCompressContent && this.wordLimitExpandCompress) {
        services.push({
          name: 'Expand or Compress Content',
          params: `Word limit: ${this.wordLimitExpandCompress}`
        });
      }
      
      // Adjust Audience/Tone - only if audience/tone is specified
      if (this.adjustAudienceTone && this.selectedAudienceTone) {
        // If "Others" is selected, use the custom text input value; otherwise use the selected option
        const audienceToneValue = this.selectedAudienceTone === 'Others' 
          ? this.audienceToneInput 
          : this.selectedAudienceTone;
        console.log(`Audience tone: ${audienceToneValue}`);
        services.push({
          name: 'Adjust for Audience / Tone',
          params: `Audience and tone: ${audienceToneValue}`
        });
      }
      
      // Enhance Research - only if research topics are specified
      if (this.enhanceResearch && this.researchTopics.trim()) {
        let researchParams = `Research Topics: ${this.researchTopics}\n`;
        
        if (this.wordLimitResearch) {
          researchParams += `   Word Limit: ${this.wordLimitResearch}\n`;
        }
        
        const sources = [];
        if (this.pwcContentLink) sources.push('PwC Content or Link');
        if (this.pwcProprietaryResearch) sources.push('PwC Proprietary Research');
        if (this.pwcLicensedThirdParty) sources.push('PwC Licensed Third Party Tools');
        if (this.externalResearch) sources.push('External Research');
        
        if (sources.length > 0) {
          researchParams += `   Sources: ${sources.join(', ')}\n`;
        }
        
        if (this.researchLinks) {
          researchParams += `   Research Links: ${this.researchLinks}\n`;
        }
        
        if (this.selectSpecificPwcSources) {
          if (this.pwcProprietaryResearch) {
            const pwcSources = [];
            if (this.pwcSource1) pwcSources.push('Source 1');
            if (this.pwcSource2) pwcSources.push('Source 2');
            if (this.pwcSource3) pwcSources.push('Source 3');
            if (this.pwcSource4) pwcSources.push('Source 4');
            if (pwcSources.length > 0) {
              researchParams += `   PwC Proprietary Research Sources: ${pwcSources.join(', ')}\n`;
            }
          }
          
          if (this.pwcLicensedThirdParty) {
            const thirdPartySources = [];
            if (this.pwcThirdPartySource1) thirdPartySources.push('Source 1');
            if (this.pwcThirdPartySource2) thirdPartySources.push('Source 2');
            if (this.pwcThirdPartySource3) thirdPartySources.push('Source 3');
            if (this.pwcThirdPartySource4) thirdPartySources.push('Source 4');
            if (thirdPartySources.length > 0) {
              researchParams += `   PwC Third Party Tool Sources: ${thirdPartySources.join(', ')}\n`;
            }
          }
        }
        
        services.push({
          name: 'Enhance with Additional Research',
          params: researchParams.trim()
        });
      }
      
      if (this.editContent) {
        const selectedEditors = [];
        if (this.developmentEditor) selectedEditors.push('Development Editor');
        if (this.contentEditor) selectedEditors.push('Content Editor');
        if (this.lineEditor) selectedEditors.push('Line Editor');
        if (this.copyEditor) selectedEditors.push('Copy Editor');
        
        // PwC Brand Alignment Editor is ALWAYS included
        selectedEditors.push('PwC Brand Alignment Editor');
        
        services.push({
          name: 'Edit Content',
          params: `Using: ${selectedEditors.join(', ')}`
        });
      }
      
      if (this.provideSuggestions) {
        services.push({
          name: 'Provide Suggestions on Improving Content',
          params: 'General improvement suggestions'
        });
      }
      
      // Build prompt
      let prompt = 'Please refine the following content using these services:\n\n';
      services.forEach((service, index) => {
        prompt += `${index + 1}. ${service.name}\n   ${service.params}\n\n`;
      });
      prompt += `\nContent to Refine:\n${contentText}`;
      
      const messages = [{
        role: 'user' as const,
        content: prompt
      }];

      console.log('[RefineContentFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        services: services.map(s => s.name)
      });

      // Build user message for chat
      const userMessageText = `Refine content: ${services.map(s => s.name).join(', ')}`;
      
      // Create stream observable
      const streamObservable = this.chatService.streamRefineContent(messages);
      
      // Close panel immediately
      this.tlFlowService.closeFlow();
      
      // Build metadata for the refined content
      const metadata: ThoughtLeadershipMetadata = {
        contentType: 'article',
        topic: this.uploadedFile.name || 'Refined Content',
        fullContent: '', // Will be populated by the chat component from streamed content
        showActions: true
      };
      
      // Emit to chat component to handle streaming
      this.streamToChat.emit({
        userMessage: userMessageText,
        streamObservable: streamObservable,
        fileName: this.uploadedFile.name,
        metadata: metadata
      });
      
      // Reset state
      this.isGenerating = false;
      this.refinedContent = '';
      this.refinedTitle = '';
      this.refinedContentBody = '';
    } catch (error) {
      console.error('[RefineContentFlow] Exception:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Close panel
      this.tlFlowService.closeFlow();
      
      // Build error message for chat
      let chatErrorMessage = 'I apologize, but I encountered an error refining your content.';
      if (errorMessage.includes('extract text') || errorMessage.includes('read file')) {
        chatErrorMessage = `Error: ${errorMessage}\n\nPlease ensure your PDF file is not corrupted and try again.`;
      } else {
        chatErrorMessage = `Error: ${errorMessage}\n\nPlease try again or contact support if the issue persists.`;
      }
      
      // Build error metadata
      const errorMetadata: ThoughtLeadershipMetadata = {
        contentType: 'article',
        topic: 'Error',
        fullContent: chatErrorMessage,
        showActions: false
      };
      
      // Add error message to chat
      this.streamToChat.emit({
        userMessage: 'Refine content',
        streamObservable: new Observable(observer => {
          observer.next({ type: 'content', content: chatErrorMessage });
          observer.complete();
        }),
        metadata: errorMetadata
      });
      
      // Reset state
      this.isGenerating = false;
      this.refinedContent = '';
      this.refinedTitle = '';
      this.refinedContentBody = '';
    }
  }

  downloadContent(format: 'txt' | 'docx'): void {
    // Include title in download if present
    const contentToDownload = this.refinedTitle 
      ? `${this.refinedTitle}\n\n${this.refinedContentBody}`
      : this.refinedContent;
    const blob = new Blob([contentToDownload], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `refined-content.${format}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  copyToClipboard(): void {
    // Include title in copy if present
    const contentToCopy = this.refinedTitle 
      ? `${this.refinedTitle}\n\n${this.refinedContentBody}`
      : this.refinedContent;
    navigator.clipboard.writeText(contentToCopy);
  }
}
