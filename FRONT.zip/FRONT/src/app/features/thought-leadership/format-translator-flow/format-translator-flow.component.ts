import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { ThoughtLeadershipMetadata } from '../../../core/models';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { TlRequestFormComponent } from '../../phoenix/TL/request-form';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
@Component({
    selector: 'app-format-translator-flow',
    imports: [FormsModule, MatSelectModule, MatFormFieldModule, MatOptionModule, MatInputModule, FileUploadComponent, TlRequestFormComponent],
    templateUrl: './format-translator-flow.component.html',
    styleUrls: ['./format-translator-flow.component.scss']
})
export class FormatTranslatorFlowComponent implements OnInit, OnDestroy {
  maxWordLimit = 400;
  wordLimitError = '';
  isGenerating = false;
  translatedContent = '';
  // When Webpage Ready is ON we keep streamed HTML/text here and do NOT show it in the modal
  hiddenTranslatedHtmlContent = '';
  // Audio handling
  audioUrl: string | null = null;
  audioBlob: Blob | null = null;
  audioBase64: string | null = null;  // Store base64 for creating chat-owned blob
  hasAudio = false;
 
  // File upload
  uploadedFile: File | null = null;
  uploadedFileWordCount = 'uploaded content';
  translatedHtmlUrl: string | null = null;
  
  // Basic fields
  wordLimit = '';
    onWordLimitChange(value: any): void {
      // If Social Media Post is selected, enforce maxWordLimit on socialMediaLength
      if (this.formatSocialMedia) {
        const num = Number(this.socialMediaLength);
        if (!isNaN(num) && num > this.maxWordLimit) {
          this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
          this.socialMediaLength = this.maxWordLimit.toString();
        } else {
          this.wordLimitError = '';
          this.socialMediaLength = this.socialMediaLength.toString();
        }
      } else {
        // Default word limit logic for other formats
        if (value && Number(value) > this.maxWordLimit) {
          this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
          this.wordLimit = this.maxWordLimit.toString();
        } else {
          this.wordLimitError = '';
          this.socialMediaLength = this.socialMediaLength.toString();
        }
      }
    }
  // ensure any created blob URL is revoked when not needed
  private revokeTranslatedHtmlUrl(): void {
    if (this.translatedHtmlUrl && this.translatedHtmlUrl.startsWith('blob:')) {
      try { URL.revokeObjectURL(this.translatedHtmlUrl); } catch { /* ignore */ }
    }
    this.translatedHtmlUrl = null;
  }
  // Format selection - only ONE format can be ON at a time (handled via exclusive toggle logic)
  formatSocialMedia = false;
  formatWebpageReady = false;
  formatPlacemat = false;
  formatPodcast = false;
 
  // Social Media Post conditional fields
  socialMediaPlatform = '';
  socialMediaLength = '';
 
  // Placemat conditional fields
  placematPageType = 'one-page'; // 'one-page' or 'two-page'
  placematNumPages = '';
  downloadPlacematUrl = '';
  showCreateRequestButton = false;
  showRequestForm = false;
  _send_To_Chat: boolean = true;
 
  //WebArticle
  
  cleanHtmlContent(text: string): string {
    if (!text) return '';

    return text
      .trim()                       // remove leading/trailing spaces
      .replace(/\n{2,}/g, '\n')     // collapse multiple blank lines
      .replace(/\n/g, '</p><p>')    // convert lines to paragraphs
      .replace(/^/, '<p>')          // wrap with paragraph
      .replace(/$/, '</p>');
  }
 
  // Podcast conditional fields
  podcastFormat = 'monologue'; // 'monologue' or 'dialogue'
  speaker1Name = '';
  speaker1Voice = '';
  speaker1Accent = '';
  speaker2Name = '';
  speaker2Voice = '';
  speaker2Accent = '';
  podcastTheme = '';
  podcastAudience = '';
  podcastDuration = '';
  enrichPodcast = false;
 
  // Research sub-options (same as Refine Content)
  researchTopics = '';
  pwcContentLink = false;
  pwcProprietaryResearch = false;
  pwcLicensedThirdParty = false;
  externalResearch = false;
  researchDocumentFile: File | null = null;
  researchLinks = '';
  wordLimitResearch = '';
  selectSpecificPwcSources = false;
  allPwcProprietarySources = false;
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;
  allPwcThirdPartySources = false;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;
 
pwcProprietarySources = [
    { name: 'PwC Industry Edge', selected: false },
    { name: 'PwC.com', selected: true },
    { name: 'PwC Insights', selected: false },
    { name: 's+b Journal', selected: false },
    { name: 'Executive Leadership Hub', selected: false },
    { name: 'The Exchange', selected: false },
    { name: 'PwC Connected Source', selected: false },
    { name: 'PwC Benchmarking', selected: false },
    //{ name: 'Insights Factory', selected: false },
    //{ name: 'PwC Intelligence', selected: false },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    // { name: 'Client Success Stories', selected: true },
    // { name: 'Inside Industries', selected: false },
    // { name: 'Value Store', selected: false }
  ];
 
  pwcThirdPartySources = [
  { name: 'Factiva, WSJ, Dow Jones', selected: false },
  { name: 'S&P Global- Capital IQ Xpressfeed', selected: false },
  { name: 'IBIS World', selected: false },
  { name: 'BoardEx', selected: false },
  // { name: 'S&P Global- Connect', selected: false },
  // { name: 'Audit Analytics', selected: false },
  // { name: 'S&P Global- SNL Insurance', selected: false },
  // { name: 'Claritas', selected: false },
  // { name: 'Equifax', selected: false },
  // { name: 'Equifax IXI', selected: false },
  // { name: 'Definitive Healthcare Provider Database', selected: false },
  // { name: 'Sg2 Health Care Intelligence', selected: false },
  // { name: 'Strata Market Insights', selected: false },
  // //{ name: 'CompanyIQ', selected: false },
  // { name: 'Global Data(Retail)', selected: false },
  // { name: 'Technology Business Review', selected: false },
  
  // //{ name: 'IDC', selected: false },
  // { name: 'CFRA Industry Surveys', selected: false }
];
 
  socialMediaPlatforms = [
    'x.com',
    'LinkedIn'
  ];
 
  voiceOptions = ['Male', 'Female'];
  accentOptions = ['American', 'British', 'Australian', 'Canadian', 'Indian'];
 
  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;
 
  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private tlChatBridge: TlChatBridgeService,
    private authFetchService: AuthFetchService
  ) {}
 
  ngOnInit(): void {
    this.tlFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe((flow: any) => {
        if (flow === 'format-translator') {
          this.resetForm();
        }
      });
  }
 
  ngOnDestroy(): void {
    this.cancelStream();
    this.cleanupAudio();
    this.revokeTranslatedHtmlUrl();
    this.destroy$.next();
    this.destroy$.complete();
  }
 
  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[FormatTranslatorFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }
 
  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'format-translator';
  }
 
  onClose(): void {
    this.cancelStream();
    this.tlFlowService.closeFlow();
    this.revokeTranslatedHtmlUrl();
  }
 
  back(): void{
    this.cancelStream();
    this.tlFlowService.closeFlow();
    this.tlFlowService.openGuidedDialog();
  }
 
  resetForm(): void {
    this.uploadedFile = null;
    this.uploadedFileWordCount = 'uploaded content';
    this.formatSocialMedia = false;
    this.formatWebpageReady = false;
    this.formatPlacemat = false;
    this.formatPodcast = false;
    this.clearAllFormatFields();
    this.translatedContent = '';
    this.hiddenTranslatedHtmlContent = '';
    this.revokeTranslatedHtmlUrl();
    this.cleanupAudio();
  }
 
  private cleanupAudio(): void {
    if (this.audioUrl) {
      URL.revokeObjectURL(this.audioUrl);
      this.audioUrl = null;
    }
    this.audioBlob = null;
    this.audioBase64 = null;
    this.hasAudio = false;
  }
 
private async extractTextFromPDF(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    // Note: This requires pdf.js library. For now, return plain text extraction
    const text = await file.text();
    return text.replace(/\x00/g, ''); // Remove null characters
  } catch (error) {
    console.error('Error extracting PDF:', error);
    return '';
  }
}
 
private async extractTextFromDOCX(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    // Simple DOCX extraction - get XML and extract text
    const text = await this.extractDOCXText(arrayBuffer);
    return text;
  } catch (error) {
    console.error('Error extracting DOCX:', error);
    return '';
  }
}
 
private async extractDOCXText(arrayBuffer: ArrayBuffer): Promise<string> {
  try {
    // DOCX is a ZIP file, we need to extract document.xml
    const view = new Uint8Array(arrayBuffer);
    const text = new TextDecoder().decode(view);
   
    // Extract text between XML tags
    const textMatches = text.match(/<w:t[^>]*>(.*?)<\/w:t>/gs);
    if (textMatches) {
      return textMatches
        .map(match => match.replace(/<w:t[^>]*>(.*?)<\/w:t>/s, '$1'))
        .join(' ')
        .trim();
    }
   
    return text;
  } catch (error) {
    console.error('Error parsing DOCX:', error);
    return '';
  }
}
 
  private clearAllFormatFields(): void {
    // Clear Social Media fields
    this.socialMediaPlatform = '';
    this.socialMediaLength = '';
   
    // Clear Placemat fields
    this.placematPageType = 'one-page';
    this.placematNumPages = '';
   
    // Clear Podcast fields
    this.podcastFormat = 'monologue';
    this.speaker1Name = '';
    this.speaker1Voice = '';
    this.speaker1Accent = '';
    this.speaker2Name = '';
    this.speaker2Voice = '';
    this.speaker2Accent = '';
    this.podcastTheme = '';
    this.podcastAudience = '';
    this.podcastDuration = '';
    this.enrichPodcast = false;
    this.clearResearchOptions();
  }

  private resetGeneratedOutput(): void {
  this.translatedContent = '';
  //this.outputHeading = '';
  this.hasAudio = false;
  this.audioUrl = null;

  this.downloadPlacematUrl = '';
  this.showCreateRequestButton = false;
}
 
  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }
 
  onFormatToggle(format: string, newValue: boolean): void {
    // Ensure only ONE format is ON at a time (exclusive selection)
    if (newValue) {
      // When turning ON a format, turn OFF all others
      switch (format) {
        case 'social-media':
          this.formatWebpageReady = false;
          this.formatPlacemat = false;
          this.formatPodcast = false;
          break;
        case 'webpage-ready':
          this.formatSocialMedia = false;
          this.formatPlacemat = false;
          this.formatPodcast = false;
          break;
        case 'placemat':
          this.formatSocialMedia = false;
          this.formatWebpageReady = false;
          this.formatPodcast = false;
          break;
        case 'podcast':
          this.formatSocialMedia = false;
          this.formatWebpageReady = false;
          this.formatPlacemat = false;
          break;
      }
    }
    // Clear all format-specific fields when toggling
    this.clearAllFormatFields();

     // Clear generated output
    this.resetGeneratedOutput();
  }
 
  onEnrichPodcastToggle(): void {
    if (!this.enrichPodcast) {
      this.clearResearchOptions();
    }
  }
 
  clearResearchOptions(): void {
    this.researchTopics = '';
    this.pwcContentLink = false;
    this.pwcProprietaryResearch = false;
    this.pwcLicensedThirdParty = false;
    this.externalResearch = false;
    this.researchDocumentFile = null;
    this.researchLinks = '';
    this.wordLimitResearch = '';
    this.selectSpecificPwcSources = false;
    this.allPwcProprietarySources = false;
    this.pwcSource1 = false;
    this.pwcSource2 = false;
    this.pwcSource3 = false;
    this.pwcSource4 = false;
    this.allPwcThirdPartySources = false;
    this.pwcThirdPartySource1 = false;
    this.pwcThirdPartySource2 = false;
    this.pwcThirdPartySource3 = false;
    this.pwcThirdPartySource4 = false;
 
    // Reset all proprietary sources array
  this.pwcProprietarySources.forEach(source => source.selected = false);
 
  // Reset all third party sources array
  this.pwcThirdPartySources.forEach(source => source.selected = false);
  }
 
  onResearchDocumentSelected(file: File): void {
    this.researchDocumentFile = file;
  }
 
  onAllPwcProprietarySourcesChange(): void {
    const value = this.allPwcProprietarySources;
    this.pwcSource1 = value;
    this.pwcSource2 = value;
    this.pwcSource3 = value;
    this.pwcSource4 = value;
  }
 
onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}
 
 
onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}
 
onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }
 
  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }
 
  onAllPwcThirdPartySourcesChange(): void {
    const value = this.allPwcThirdPartySources;
    this.pwcThirdPartySource1 = value;
    this.pwcThirdPartySource2 = value;
    this.pwcThirdPartySource3 = value;
    this.pwcThirdPartySource4 = value;
  }
 
  get showPwcSourceSelection(): boolean {
    return this.enrichPodcast && (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }
 
  get showDialogueSpeakers(): boolean {
    return this.formatPodcast && this.podcastFormat === 'dialogue';
  }
 
  
  get canTranslate(): boolean {
    if (!this.uploadedFile) return false;
   
    // At least one format must be selected
    if (!this.formatSocialMedia && !this.formatWebpageReady && !this.formatPlacemat && !this.formatPodcast) {
      return false;
    }
   
    // Validate format-specific required fields
    if (this.formatSocialMedia) {
      return !!(this.socialMediaPlatform); //&& this.socialMediaLength.trim());
    }
   
    if (this.formatWebpageReady) {
      return true; // No additional required fields
    }
   
    if (this.formatPlacemat) {
      // if (this.placematPageType === 'two-page') {
      //   return !!this.placematNumPages.trim();
      // }
      return true;
    }
   
    if (this.formatPodcast) {
      // Basic podcast required fields
      // if (!this.podcastAudience.trim() || !this.podcastDuration.trim()) {
      //   return false;
      // }
      // Speaker 1 required fields
      // if (!this.speaker1Name.trim() || !this.speaker1Voice || !this.speaker1Accent) {
      //   return false;
      // }
      // Speaker 2 required if dialogue
      // if (this.podcastFormat === 'dialogue') {
      //   if (!this.speaker2Name.trim() || !this.speaker2Voice || !this.speaker2Accent) {
      //     return false;
      //   }
      // }
      return true;
    }
   
    return false;
  }
   get outputHeading(): string {
  if (this.formatSocialMedia) {
    return `${this.socialMediaPlatform} Content`;
  }
  if (this.formatWebpageReady) {
    return 'Web Article Content';
  }
  if (this.formatPlacemat) {
    return '';//Placemat Content
  }
  if (this.formatPodcast) {
    return 'Podcast Content';
  }
return 'Translated Content';

}
  async translateFormat(): Promise<void> {

    if (
    this.formatPlacemat &&
    this.placematPageType === 'custom' &&
    !this.canTranslatePlacemat()
  ) {
    this.translatedContent =
      '❌ Please enter a valid number of pages (1-10) for Custom placemat.';
    this.isGenerating = false;
    return;
  }
    
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }
 
    this.isGenerating = true;
    this.translatedContent = '';
 
    try {
      // Extract text from uploaded file based on type
    let contentText = '';
    const fileName = this.uploadedFile.name.toLowerCase();
   
    if (fileName.endsWith('.txt') || fileName.endsWith('.md')) {
      // Plain text files
      contentText = await this.uploadedFile.text();
    } else if (fileName.endsWith('.pdf')) {
      // PDF files - needs special handling
      contentText = await this.extractTextFromPDF(this.uploadedFile);
    } else if (fileName.endsWith('.docx')) {
      // DOCX files - needs special handling
      contentText = await this.extractTextFromDOCX(this.uploadedFile);
    } else {
      // Fallback to text extraction
      contentText = await this.uploadedFile.text();
    }
   
    if (!contentText.trim()) {
      this.translatedContent = 'Could not extract text from the file. Please ensure the file contains readable text content.';
      this.isGenerating = false;
      return;
    }
 
    // Determine source format from file extension
    let sourceFormat = 'text';
    if (fileName.endsWith('.docx')) sourceFormat = 'Word';
    else if (fileName.endsWith('.pdf')) sourceFormat = 'PDF';
    else if (fileName.endsWith('.md')) sourceFormat = 'Markdown';
     
      // Build parameters based on which format is enabled
      let targetFormat = '';
      let customization = '';
      let podcastStyle = this.podcastFormat;
      let speaker1Name = this.speaker1Name;
      let speaker1Voice = this.speaker1Voice;
      let speaker1Accent = this.speaker1Accent;
      let speaker2Name = this.speaker2Name;
      let speaker2Voice = this.speaker2Voice;
      let speaker2Accent = this.speaker2Accent;
      let uploadedFile = this.uploadedFile;
     
      // Extract word limit from social media length if it's a social media post
      let wordLimit: string | undefined = undefined;
      if (this.formatSocialMedia && this.socialMediaLength.trim()) {
        // Extract numeric value from socialMediaLength (e.g., "200 words" -> "200")
        const match = this.socialMediaLength.match(/(\d+)/);
        if (match) {
          wordLimit = match[1];
        }
      }
     
      if (this.formatSocialMedia) {
        targetFormat = 'Social Media Post';
        customization = `Platform: ${this.socialMediaPlatform}`;
         if(this.socialMediaLength.trim()){
          customization += `, Length: ${this.socialMediaLength}`;
         }
      } else if (this.formatWebpageReady) {
        targetFormat = 'Webpage Ready';
        customization = 'Optimized for web display';
      } else if (this.formatPlacemat) {
        targetFormat = 'Placemat';
        customization = `Layout: ${this.placematPageType}`;
        if(this.placematNumPages){
          customization += `,Pages: ${this.placematNumPages}`;
        }
        /*
        if (this.placematPageType === 'two-page' && this.placematNumPages) {
          customization += `, Pages: ${this.placematNumPages}`;
        }
          */
      } else if (this.formatPodcast) {
        targetFormat = 'Podcast';
        if(this.podcastAudience.trim()){
          customization = `Audience: ${this.podcastAudience}`;
        }
        if(this.podcastDuration.trim()){
          customization += `, Duration: ${this.podcastDuration} minutes`;
        }
        //customization = `Audience: ${this.podcastAudience}, Duration: ${this.podcastDuration} minutes`;
        if (this.podcastTheme) {
          customization += `, Theme: ${this.podcastTheme}`;
        }
      }
 
      console.log('[FormatTranslatorFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        sourceFormat,
        targetFormat,
        customization
      });
 
      this.streamSubscription = this.chatService.streamFormatTranslator({
        content: contentText,
        uploadedFile,
        sourceFormat,
        targetFormat,
        customization,
        podcastStyle,
        speaker1Name,
        speaker1Voice,
        speaker1Accent,
        speaker2Name,
        speaker2Voice,
        speaker2Accent,
        wordLimit: wordLimit
      }).subscribe({
        next: (data: any) => {
          console.log('[FormatTranslatorFlow] Received data:', data);
         
          if (data.type === 'progress') {
            console.log('[FormatTranslatorFlow] Progress:', data.message);
          }
          else if(data.type === 'placemat' && data.status === 'success')
          {
            
            if (data.url) {
              
              this.downloadPlacematUrl = data.url;
              this.showCreateRequestButton = false;
              this.translatedContent = '🎉 Placemat generated successfully!';
              this._send_To_Chat = false;
             }
 
          }          
          else if (data.type === 'script') {
            // scripts are visible in modal unless Webpage Ready is selected
            if (this.formatWebpageReady) {
              this.hiddenTranslatedHtmlContent += (data.content || '');
            } else {
              this.translatedContent = data.content || '';
            }
          } else if (data.type === 'complete') {
            if (data.audio) {
              console.log('[FormatTranslatorFlow] Audio received, creating blob');
              this.handleAudioResponse(data.audio);
            }
          } else if (data.type === 'content' && data.content) {
            // Handle content chunks from streaming response
            if (this.formatWebpageReady) {
              // accumulate but DO NOT show in modal
              this.hiddenTranslatedHtmlContent += data.content;
            } else {
              this.translatedContent += data.content;
            }
          }
          // ------- ADDED: handle backend-provided hosted HTML URL for Webpage Ready -------
          else if (data.type === 'content_url' && data.url) {
            // Backend provided a hosted HTML URL (e.g., S3/presigned or hosted HTML)
            this.translatedHtmlUrl = data.url;
            // Optionally set a user-facing message or keep the streamed content if any
           
            // keep hidden content as well (in case of fallback)
            if (this.formatWebpageReady && !this.hiddenTranslatedHtmlContent) {
              this.hiddenTranslatedHtmlContent = '';
            }
         
          } else if (data.url && !this.translatedHtmlUrl) {
            // Fallback: some responses include url without a type
            this.translatedHtmlUrl = data.url;
          }
          // -------------------------------------------------------------------------------
          else if (data.type === 'done') {
            
            // Stream complete - clean the final content
            if (this.formatWebpageReady) {
              // Clean hidden content and prepare a blob URL for opening when user clicks Download HTML Doc
              // const cleaned = this.cleanTranslatedContent(this.hiddenTranslatedHtmlContent || '');
              const cleaned = this.cleanHtmlContent(this.hiddenTranslatedHtmlContent);
              this.hiddenTranslatedHtmlContent = cleaned;
              // create blob url now so Download HTML Doc can immediately open it
              try {
                this.revokeTranslatedHtmlUrl();
                
                const htmlPayload = `<!DOCTYPE html>
                <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><body>${cleaned}</body>`;
                // ${cleaned.replace(/\n/g, '<br>')}</body></html>`;
                console.log("Generated HTML:", htmlPayload);
                const blob = new Blob([htmlPayload], { type: 'text/html;charset=utf-8' });
                this.translatedHtmlUrl = URL.createObjectURL(blob);
              } catch (e) {
                console.warn('[FormatTranslatorFlow] Could not create HTML blob URL', e);
              }
              // Do NOT expose full HTML content in modal — show completion message only
              // this.translatedContent = 'Click "Download HTML Doc" button to open the file';
              this.translatedContent = '✅ Translation Completed!';
            } else {
              this.translatedContent = this.cleanTranslatedContent(this.translatedContent);
            }
            console.log('[FormatTranslatorFlow] Stream done, cleaned content');
          } else if (data.error) {
            console.error('[FormatTranslatorFlow] Stream error:', data.error);
            this.translatedContent = 'Sorry, there was an error translating your content. Please try again.';
            this.isGenerating = false;
          } else if (typeof data === 'string') {
            // Fallback for string data
            if (this.formatWebpageReady) this.hiddenTranslatedHtmlContent += data; else this.translatedContent += data;
          } else if (data.content) {
            // Fallback: if data has content property, use it
            if (this.formatWebpageReady) this.hiddenTranslatedHtmlContent += data.content; else this.translatedContent += data.content;
          } else {
            console.warn('[FormatTranslatorFlow] Unhandled data format:', data);
          }
        },
        error: (error: any) => {
          console.error('[FormatTranslatorFlow] Error:', error);
          this.translatedContent = 'Sorry, there was an error translating your content. Please try again.';
          this.isGenerating = false;
        },
        complete: () => {
          console.log('[FormatTranslatorFlow] Translation complete');
         
          this.isGenerating = false;
         
          // Clean the translated content
          if (!this.formatWebpageReady && this.translatedContent) {
            this.translatedContent = this.cleanTranslatedContent(this.translatedContent);
          }

          if(this.translatedContent && this.downloadPlacematUrl)
          {
            
              console.log('create button');              
              this._send_To_Chat = false;
             }
          
          else if (!this.formatWebpageReady && (this.translatedContent || this.hasAudio)) {
            this.sendToChat();
          }

          // if (this.translatedContent || this.hasAudio) {
          //   this.sendToChat();
          // }
          // Note: Content is displayed in the modal, user can manually send to chat if needed
        }
      });
    } catch (error) {
      console.error('[FormatTranslatorFlow] Error reading file:', error);
      this.isGenerating = false;
    }
  }
 
  canTranslatePlacemat(): boolean {
  if (this.placematPageType !== 'custom') {
    return true;
  }

  const pages = Number(this.placematNumPages);

  return (
    Number.isInteger(pages) &&
    pages >= 1 &&
    pages <= 10
  );
}

  private handleAudioResponse(base64Audio: string): void {
    try {
      // Clean up previous audio if exists
      this.cleanupAudio();
     
      // Store base64 for creating chat-owned blob later
      this.audioBase64 = base64Audio;
     
      // Convert base64 to blob
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      this.audioBlob = new Blob([bytes], { type: 'audio/mpeg' });
      this.audioUrl = URL.createObjectURL(this.audioBlob);
      this.hasAudio = true;
     
      console.log('[FormatTranslatorFlow] Audio URL created:', this.audioUrl);
    } catch (error) {
      console.error('[FormatTranslatorFlow] Error creating audio blob:', error);
    }
  }
 
  downloadAudio(): void {
    if (!this.audioUrl || !this.audioBlob) return;
   
    const link = document.createElement('a');
    link.href = this.audioUrl;
    link.download = `podcast-${Date.now()}.mp3`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
 
  downloadPlacematFile(): void {
    if (!this.downloadPlacematUrl) {
      console.warn('[Placemat] No download URL available');
      return;
    }
    /*
    const link = document.createElement('a');
    link.href = this.downloadPlacematUrl;
    link.target = '_blank';
    link.download = 'placemat.pptx'; // default filename
    link.click();*/
   
    fetch(this.downloadPlacematUrl)
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
 
      link.href = url;
      link.download = 'Placemat.pptx';
      link.click();
 
      window.URL.revokeObjectURL(url);
    })
    .catch(err => console.error('Download error:', err))
    .finally(() => {
    this.downloadPlacematUrl = ''; // or null to hide button/clear state
    this.translatedContent = 'You may raise an issue by clicking on the button below.';
    this.showCreateRequestButton = true;
    //this._send_To_Chat = true;
    setTimeout(() => { this._send_To_Chat = true; }, 10000);
   
   
      });
  }

    openRequestForm() {
  this.showRequestForm = true;
}

phoenixRdpLink = '';

onTicketCreated(event: {
  requestNumber: string;
  phoenixRdpLink: string;
}): void {
  this.phoenixRdpLink = event.phoenixRdpLink;
  console.log('Ticket created:', event.requestNumber);
  this.translatedContent =`✅ Request created successfully! Your request number is: <a href="${event.phoenixRdpLink}" target="_blank" rel="noopener noreferrer">${event.requestNumber}</a>`.trim();
  this.showRequestForm = false;
  this.showCreateRequestButton = false;
}

sendToChat(): void {
  // Send podcast result to chat window with audio player and download
  if (!this.translatedContent && !this.hasAudio) {
    console.warn('[FormatTranslatorFlow] No content to send to chat');
    return;
    }
   
    // Determine content type based on selected format
    let contentType: string;
    if (this.formatPodcast) {
      contentType = 'podcast';
    } else if (this.formatSocialMedia) {
      contentType = 'socialMedia';
    } else {
      contentType = 'article';
    }
    
    const topic = this.uploadedFile?.name || '';
   
    // Create metadata for the message
    const metadata: ThoughtLeadershipMetadata = {
      contentType: contentType as any,
      topic: topic,
      fullContent: this.translatedContent,
      showActions: true
    };
   
    // Add podcast-specific metadata if we have audio
    // Create a NEW blob URL for the chat message to own independently
    if (this.hasAudio && this.audioBase64) {
      try {
        // Convert base64 to a new blob that the chat message will own
        const binaryString = atob(this.audioBase64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const chatAudioBlob = new Blob([bytes], { type: 'audio/mpeg' });
        const chatAudioUrl = URL.createObjectURL(chatAudioBlob);
       
        metadata.podcastAudioUrl = chatAudioUrl;
        metadata.podcastFilename = `${this.sanitizeFilename(topic)}_podcast.mp3`;
       
        console.log('[FormatTranslatorFlow] Created new audio URL for chat:', chatAudioUrl);
      } catch (error) {
        console.error('[FormatTranslatorFlow] Error creating chat audio blob:', error);
      }
    }
   
    // Send the translated content directly (preserving formatting)
    // Content will be formatted by the chat component's formatting methods
    const chatMessage = this.translatedContent;
   
    // Send to chat via bridge
    console.log('[FormatTranslatorFlow] ===== Sending Podcast to Chat =====', {
      metadata: {
        contentType: metadata.contentType,
        topic: metadata.topic,
        showActions: metadata.showActions,
        hasPodcastUrl: !!metadata.podcastAudioUrl,
        podcastUrlLength: metadata.podcastAudioUrl?.length
      },
      messageLength: chatMessage.length,
      timestamp: new Date().toISOString()
    });
    this.tlChatBridge.sendToChat(chatMessage, metadata);
   
    // Close the dialog (this will cleanup the dialog's audio URL, but chat has its own)
    this.onClose();
  }
 
  private sanitizeFilename(filename: string): string {
    return filename.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  }
 
  private cleanTranslatedContent(content: string): string {
    if (!content) return content;
   
    // First, try to find the actual translated content by looking for markers
    const markers = [
      /here is the rewritten response[^\n]*:?\s*/gi,
      /here is the converted content[^\n]*:?\s*/gi,
      /here is the translation[^\n]*:?\s*/gi,
      /here is the translated content[^\n]*:?\s*/gi,
      /here is the content[^\n]*:?\s*/gi,
      /rewritten response[^\n]*:?\s*/gi,
      /converted content[^\n]*:?\s*/gi,
      /translated content[^\n]*:?\s*/gi
    ];
   
    let cleaned = content;
   
    // Try to extract content after a marker
    for (const marker of markers) {
      const match = cleaned.search(marker);
      if (match !== -1) {
        const afterMarker = cleaned.substring(match).replace(marker, '');
        if (afterMarker.trim().length > 50) {
          cleaned = afterMarker.trim();
          break;
        }
      }
    }
   
    // Remove metadata patterns
    const skipPatterns = [
      /word count:\s*\d+\s*words?/gi,
      /source format:\s*[^\n]+/gi,
      /target format:\s*[^\n]+/gi,
      /output word limit:\s*[^\n]+/gi,
      /here is the converted content:/gi,
      /here is the content:/gi,
      /here is the translation:/gi,
      /here is the translated content:/gi,
      /here is the rewritten response[^\n]*:?\s*/gi,
      /converted content:/gi,
      /translated content:/gi,
      /rewritten response[^\n]*:?\s*/gi,
      /^output:\s*/gim,
      /^result:\s*/gim,
      /^\(source\)\s*$/gim,
      /since the content is already within[^\n]+/gi,
      /there is no need to prioritize[^\n]+/gi,
      /the content can be directly translated[^\n]+/gi,
      /with minor adjustments for[^\n]+/gi,
      /within the \d+-word limit[^\n]*/gi
    ];
   
    // Remove patterns
    for (const pattern of skipPatterns) {
      cleaned = cleaned.replace(pattern, '');
    }
   
    // Remove "Key Takeaways:" sections and everything before them if they appear early
    const keyTakeawaysIndex = cleaned.toLowerCase().indexOf('key takeaways:');
    if (keyTakeawaysIndex !== -1 && keyTakeawaysIndex < cleaned.length * 0.5) {
      // If "Key Takeaways" appears in the first half, remove everything up to and including it
      cleaned = cleaned.substring(keyTakeawaysIndex);
      // Remove the "Key Takeaways:" line and bullet points that follow
      const lines = cleaned.split('\n');
      let startIndex = 0;
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].toLowerCase().trim();
        if (line.includes('key takeaways') || line.startsWith('-') || line.startsWith('•') || line.startsWith('*')) {
          startIndex = i + 1;
        } else if (line && !line.match(/^[-•*]\s*/) && startIndex > 0) {
          // Found content after takeaways, start from here
          break;
        }
      }
      cleaned = lines.slice(startIndex).join('\n').trim();
    }
   
    // Remove lines that are just metadata labels or explanatory text
    const lines = cleaned.split('\n');
    const cleanedLines: string[] = [];
    let foundContent = false;
    let skipNextEmptyLines = false;
    let skipBulletPoints = false;
   
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const lineLower = line.toLowerCase();
     
      // Skip empty lines at the start
      if (!foundContent && !line) {
        continue;
      }
     
      // Skip "Key Takeaways:" and bullet points that follow
      if (lineLower.includes('key takeaways:')) {
        skipBulletPoints = true;
        continue;
      }
     
      if (skipBulletPoints && (line.startsWith('-') || line.startsWith('•') || line.startsWith('*') || !line)) {
        continue;
      } else if (skipBulletPoints && line) {
        skipBulletPoints = false;
      }
     
      // Skip metadata/explanatory lines
      if (!foundContent && (
        lineLower.includes('word count') ||
        lineLower.includes('source format') ||
        lineLower.includes('target format') ||
        lineLower.includes('output word limit') ||
        lineLower.startsWith('here is') ||
        lineLower.startsWith('converted content') ||
        lineLower.startsWith('translated content') ||
        lineLower.startsWith('rewritten response') ||
        lineLower.startsWith('since the content') ||
        lineLower.startsWith('there is no need') ||
        lineLower.startsWith('the content can be') ||
        lineLower.startsWith('with minor adjustments') ||
        lineLower.includes('no need to prioritize') ||
        lineLower.includes('can be directly translated') ||
        lineLower.includes('within the') && lineLower.includes('word limit') ||
        (lineLower.includes(':') && (lineLower.includes('word') || lineLower.includes('format') || lineLower.includes('limit'))) ||
        (line.length > 0 && line.length < 200 && (
          lineLower.includes('since') && lineLower.includes('content') ||
          lineLower.includes('translation') && lineLower.includes('here') ||
          lineLower.includes('rewritten') && lineLower.includes('response')
        ))
      )) {
        skipNextEmptyLines = true;
        continue;
      }
     
      // Skip empty lines after metadata
      if (skipNextEmptyLines && !line) {
        continue;
      }
     
      // Once we find actual content (not metadata), include everything
      if (line && !lineLower.match(/^(word|source|target|output|here|converted|translated|since|there|the content can|rewritten|key takeaways)/)) {
        foundContent = true;
        skipNextEmptyLines = false;
      }
     
      if (foundContent) {
        cleanedLines.push(lines[i]);
      }
    }
   
    cleaned = cleanedLines.join('\n').trim();
   
    // Additional cleanup: remove any remaining explanatory sentences at the start
    const sentences = cleaned.split(/[.!?]\s+/);
    if (sentences.length > 1) {
      const firstSentence = sentences[0].toLowerCase();
      if (firstSentence.includes('since') ||
          firstSentence.includes('here is') ||
          firstSentence.includes('translation') ||
          firstSentence.includes('converted') ||
          firstSentence.includes('rewritten')) {
        cleaned = sentences.slice(1).join('. ').trim();
      }
    }
   
    // Final pass: remove any remaining "Key Takeaways:" sections
    cleaned = cleaned.replace(/key takeaways:[\s\S]*?(?=\n\n|\n[A-Z]|$)/gi, '').trim();
   
    // If cleaning removed too much, return original
    if (cleaned.length < content.length * 0.3 && content.length > 100) {
      return content;
    }
   
    return cleaned;
  }
 
  downloadAsHTML(): void {
    
    // Prefer the hosted/blob URL prepared after streaming. If not available, build from hidden content.
    if (!this.translatedHtmlUrl && !this.hiddenTranslatedHtmlContent) {
       console.warn('[FormatTranslatorFlow] No content or URL available to open');
       return;
     }  
    // Close the Format Translator window and clear state   <<<< --- HERE
    this.tlFlowService.closeFlow();
    this.cancelStream();
    this.isGenerating = false;
    this.translatedContent = '';
    this.hiddenTranslatedHtmlContent = '';
     // If backend provided a hosted URL (preferred), open it directly
     if (this.translatedHtmlUrl) {
       // If it's a relative or blob/data URL it still opens correctly
       window.open(this.translatedHtmlUrl, '_blank');
       console.log('[FormatTranslatorFlow] Opened provided HTML URL in new tab:', this.translatedHtmlUrl);
       return;
     }
 
    // Fallback: wrap hiddenTranslatedHtmlContent into an HTML blob and open
    const htmlContent = `<!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Webpage Ready Content</title>
   <style>
     body {
       font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
       line-height: 1.6;
       max-width: 900px;
       margin: 0 auto;
       padding: 40px 20px;
       color: #333;
     }
     h1, h2, h3 { color: #0066cc; margin-top: 1.5em; }
     p { margin-bottom: 1em; }
     a { color: #0066cc; text-decoration: none; }
     a:hover { text-decoration: underline; }
   </style>
 </head>
 <body>
-  ${this.translatedContent.replace(/\n/g, '<br>')}
+  ${this.hiddenTranslatedHtmlContent.replace(/\n/g, '<br>')}
 </body>
 </html>`;
 
     const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
     const url = URL.createObjectURL(blob);
     window.open(url, '_blank');
     setTimeout(() => URL.revokeObjectURL(url), 5000);
 
     console.log('[FormatTranslatorFlow] HTML opened in new tab (blob fallback)');
   }
}
