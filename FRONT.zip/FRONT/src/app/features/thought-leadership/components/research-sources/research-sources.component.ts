import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';

export interface ResearchSourceSelection {
  uploadedContent: boolean;
  pwcProprietary: boolean;
  pwcLicensed: boolean;
  externalResearch: boolean;
  selectedPwcProprietarySources?: string[];
  selectedPwcLicensedSources?: string[];
}

@Component({
  selector: 'app-research-sources',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './research-sources.component.html',
  styleUrls: ['./research-sources.component.scss']
})
export class ResearchSourcesComponent implements OnInit {
  @Input() showResearchOptions: boolean = false;
  @Output() selectionChange = new EventEmitter<ResearchSourceSelection>();

  // Toggle states
  uploadedContent: boolean = false;
  pwcProprietary: boolean = false;
  pwcLicensed: boolean = false;
  externalResearch: boolean = false;

  // Expansion states
  showPwcProprietaryList: boolean = false;
  showPwcLicensedList: boolean = false;

  // "All Sources" checkbox states
  pwcProprietaryAllSources: boolean = false;
  pwcLicensedAllSources: boolean = false;

  // Individual source selections
  selectedPwcProprietarySources: string[] = [];
  selectedPwcLicensedSources: string[] = [];

  // Source lists (placeholder - coming soon functionality)
  pwcProprietarySources = [
    { id: 'dealogic', name: 'Dealogic', comingSoon: true },
    { id: 'capital-iq', name: 'Capital IQ', comingSoon: true },
    { id: 'factset', name: 'FactSet', comingSoon: true },
    { id: 'pitchbook', name: 'PitchBook', comingSoon: true },
    { id: 'preqin', name: 'Preqin', comingSoon: true }
  ];

  pwcLicensedSources = [
    { id: 'bloomberg', name: 'Bloomberg Terminal', comingSoon: true },
    { id: 'thomson-reuters', name: 'Thomson Reuters', comingSoon: true },
    { id: 'sp-global', name: 'S&P Global', comingSoon: true },
    { id: 'refinitiv', name: 'Refinitiv', comingSoon: true },
    { id: 'moody', name: "Moody's Analytics", comingSoon: true }
  ];

  ngOnInit(): void {
    this.emitSelection();
  }

  onToggleChange(): void {
    // When toggling off, reset related selections
    if (!this.pwcProprietary) {
      this.pwcProprietaryAllSources = false;
      this.selectedPwcProprietarySources = [];
      this.showPwcProprietaryList = false;
    }
    if (!this.pwcLicensed) {
      this.pwcLicensedAllSources = false;
      this.selectedPwcLicensedSources = [];
      this.showPwcLicensedList = false;
    }
    
    this.emitSelection();
  }

  togglePwcProprietaryList(): void {
    this.showPwcProprietaryList = !this.showPwcProprietaryList;
  }

  togglePwcLicensedList(): void {
    this.showPwcLicensedList = !this.showPwcLicensedList;
  }

  onPwcProprietaryAllSourcesChange(): void {
    if (this.pwcProprietaryAllSources) {
      // Select all available sources
      this.selectedPwcProprietarySources = this.pwcProprietarySources
        .filter(source => !source.comingSoon)
        .map(source => source.id);
    } else {
      this.selectedPwcProprietarySources = [];
    }
    this.emitSelection();
  }

  onPwcLicensedAllSourcesChange(): void {
    if (this.pwcLicensedAllSources) {
      // Select all available sources
      this.selectedPwcLicensedSources = this.pwcLicensedSources
        .filter(source => !source.comingSoon)
        .map(source => source.id);
    } else {
      this.selectedPwcLicensedSources = [];
    }
    this.emitSelection();
  }

  onIndividualSourceChange(sourceId: string, type: 'proprietary' | 'licensed', checked: boolean): void {
    if (type === 'proprietary') {
      if (checked) {
        if (!this.selectedPwcProprietarySources.includes(sourceId)) {
          this.selectedPwcProprietarySources.push(sourceId);
        }
      } else {
        this.selectedPwcProprietarySources = this.selectedPwcProprietarySources.filter(id => id !== sourceId);
        this.pwcProprietaryAllSources = false;
      }
    } else {
      if (checked) {
        if (!this.selectedPwcLicensedSources.includes(sourceId)) {
          this.selectedPwcLicensedSources.push(sourceId);
        }
      } else {
        this.selectedPwcLicensedSources = this.selectedPwcLicensedSources.filter(id => id !== sourceId);
        this.pwcLicensedAllSources = false;
      }
    }
    this.emitSelection();
  }

  isSourceSelected(sourceId: string, type: 'proprietary' | 'licensed'): boolean {
    if (type === 'proprietary') {
      return this.selectedPwcProprietarySources.includes(sourceId);
    } else {
      return this.selectedPwcLicensedSources.includes(sourceId);
    }
  }

  private emitSelection(): void {
    this.selectionChange.emit({
      uploadedContent: this.uploadedContent,
      pwcProprietary: this.pwcProprietary,
      pwcLicensed: this.pwcLicensed,
      externalResearch: this.externalResearch,
      selectedPwcProprietarySources: this.selectedPwcProprietarySources,
      selectedPwcLicensedSources: this.selectedPwcLicensedSources
    });
  }
}
