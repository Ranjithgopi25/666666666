import { Component, Output, EventEmitter, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';

export interface StartingMaterial {
  type: 'file' | 'text' | null;
  file?: File;
  text?: string;
}

@Component({
  selector: 'app-starting-material',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './starting-material.component.html',
  styleUrls: ['./starting-material.component.scss']
})
export class StartingMaterialComponent implements OnInit {
  @Output() materialChange = new EventEmitter<StartingMaterial>();

  uploadedFile: File | null = null;
  pastedText: string = '';
  materialType: 'file' | 'text' | null = null;

  ngOnInit(): void {
    this.emitMaterial();
  }

  onFileSelect(event: any): void {
    const files = event.target.files;
    if (files && files.length > 0) {
      this.uploadedFile = files[0];
      this.pastedText = ''; // Clear text when file is uploaded
      this.materialType = 'file';
      this.emitMaterial();
    }
  }

  onTextChange(): void {
    if (this.pastedText.trim().length > 0) {
      this.uploadedFile = null; // Clear file when text is entered
      this.materialType = 'text';
    } else {
      this.materialType = null;
    }
    this.emitMaterial();
  }

  removeFile(): void {
    this.uploadedFile = null;
    this.materialType = null;
    // Reset file input
    const fileInput = document.getElementById('starting-material-file') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
    this.emitMaterial();
  }

  clearText(): void {
    this.pastedText = '';
    this.materialType = null;
    this.emitMaterial();
  }

  private emitMaterial(): void {
    this.materialChange.emit({
      type: this.materialType,
      file: this.uploadedFile || undefined,
      text: this.pastedText || undefined
    });
  }

  get hasValidMaterial(): boolean {
    return this.materialType !== null;
  }
}
