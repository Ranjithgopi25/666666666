import { Injectable } from '@angular/core';
import { ReplaySubject, Observable } from 'rxjs';
import { Message, ThoughtLeadershipMetadata } from '../models';

export interface ThoughtLeadershipMessage {
  message: Message;
  metadata: ThoughtLeadershipMetadata;
}

export interface DraftGenerationContext {
  contentType: string;
  topic: string;
  wordLimit?: string;
  audienceTone?: string;
  outlineDoc?: string;
  supportingDoc?: string;
  useFactivaResearch?: boolean;
  generatedContent?: string;
}

@Injectable({
  providedIn: 'root'
})
export class TlChatBridgeService {
  // Use ReplaySubject to buffer the last message in case of timing issues
  private messageSubject = new ReplaySubject<Message>(1);
  
  // Observable that components can subscribe to
  public message$ = this.messageSubject.asObservable();

  // Track draft generation context for improvement handling
  private draftContextSubject = new ReplaySubject<DraftGenerationContext | null>(1);
  public draftContext$: Observable<DraftGenerationContext | null> = this.draftContextSubject.asObservable();
  private currentDraftContext: DraftGenerationContext | null = null;

  constructor() {
    console.log('[TlChatBridge] Service instance created');
    this.draftContextSubject.next(null);
  }

  /**
   * Store draft generation context for handling subsequent improvement requests
   * @param context - The draft generation parameters and content
   */
  setDraftContext(context: DraftGenerationContext): void {
    console.log('[TlChatBridge] Draft context set');
    this.currentDraftContext = context;
    this.draftContextSubject.next(context);
  }

  /**
   * Get current draft context
   */
  getDraftContext(): DraftGenerationContext | null {
    return this.currentDraftContext;
  }

  /**
   * Clear draft context when no longer needed
   */
  clearDraftContext(): void {
    console.log('[TlChatBridge] Draft context cleared');
    this.currentDraftContext = null;
    this.draftContextSubject.next(null);
  }

  /**
   * Check if we're awaiting user satisfaction feedback on a draft
   */
  isAwaitingDraftFeedback(): boolean {
    return this.currentDraftContext !== null;
  }

  /**
   * Send Thought Leadership content to the chat window
   * @param content - The generated content (markdown/text or HTML)
   * @param metadata - Metadata about the content type, topic, etc.
   * @param isHtml - Optional flag to indicate content is already HTML formatted
   */
  sendToChat(content: string, metadata: ThoughtLeadershipMetadata, isHtml?: boolean): void {
    console.log('[TlChatBridge] sendToChat() called');
    console.log('[TlChatBridge] Content:', content.substring(0, 100) + '...');
    console.log('[TlChatBridge] Metadata:', metadata);
    console.log('[TlChatBridge] isHtml:', isHtml);
    
    const message: Message = {
      role: 'assistant',
      content: content,
      timestamp: new Date(),
      isHtml: isHtml,
      thoughtLeadership: metadata
    };

    console.log('[TlChatBridge] Emitting message via messageSubject');
    this.messageSubject.next(message);
    console.log('[TlChatBridge] Message emitted');
  }

  /**
   * Send a pre-formatted Message directly to chat
   * @param message - The complete message object
   */
  sendMessage(message: Message): void {
    console.log('[TlChatBridge] sendMessage() called');
    console.log('[TlChatBridge] Message:', message);
    this.messageSubject.next(message);
  }
}
