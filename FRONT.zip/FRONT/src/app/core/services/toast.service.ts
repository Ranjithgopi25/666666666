import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  private toasts$ = new BehaviorSubject<Toast[]>([]);
  private toastCounter = 0;

  /**
   * Observable stream of toasts for components to display
   */
  getToasts(): Observable<Toast[]> {
    return this.toasts$.asObservable();
  }

  /**
   * Show a success toast notification
   * @param message - Toast message to display
   * @param duration - Duration in milliseconds (default: 4000)
   */
  success(message: string, duration: number = 4000): void {
    this.show(message, 'success', duration);
  }

  /**
   * Show an error toast notification
   * @param message - Toast message to display
   * @param duration - Duration in milliseconds (default: 5000)
   */
  error(message: string, duration: number = 5000): void {
    this.show(message, 'error', duration);
  }

  /**
   * Show a warning toast notification
   * @param message - Toast message to display
   * @param duration - Duration in milliseconds (default: 4000)
   */
  warning(message: string, duration: number = 4000): void {
    this.show(message, 'warning', duration);
  }

  /**
   * Show an info toast notification
   * @param message - Toast message to display
   * @param duration - Duration in milliseconds (default: 4000)
   */
  info(message: string, duration: number = 4000): void {
    this.show(message, 'info', duration);
  }

  /**
   * Show a generic toast notification
   * @param message - Toast message to display
   * @param type - Toast type (success, error, warning, info)
   * @param duration - Duration in milliseconds before auto-dismiss
   */
  show(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info', duration: number = 4000): void {
    const id = `toast-${++this.toastCounter}-${Date.now()}`;
    const toast: Toast = {
      id,
      message,
      type,
      duration
    };

    // Add toast to the stream
    const currentToasts = this.toasts$.value;
    this.toasts$.next([...currentToasts, toast]);

    // Auto-dismiss after duration
    if (duration > 0) {
      setTimeout(() => {
        this.dismiss(id);
      }, duration);
    }
  }

  /**
   * Dismiss a specific toast by ID
   * @param id - Toast ID to dismiss
   */
  dismiss(id: string): void {
    const currentToasts = this.toasts$.value;
    this.toasts$.next(currentToasts.filter(t => t.id !== id));
  }

  /**
   * Dismiss all toasts
   */
  dismissAll(): void {
    this.toasts$.next([]);
  }
}
