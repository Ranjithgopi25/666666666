export type JourneyType = 'thought-leadership' | 'ddc' | 'market-intelligence';

export interface WorkflowCard {
  id: string;
  icon: string;
  title: string;
  subtitle?: string;
  description: string;
  disabled?: boolean;
}

export interface GuidedJourneyConfig {
  type: JourneyType;
  title: string;
  workflows: WorkflowCard[];
}

// Intro text shown above workflows in Guided Journey dialogs
export const DDC_INTRO_TEXT = '';
export const DDC_SUB_INTRO_TEXT = 'PwC quality presentations at the speed of thought';
export const TL_INTRO_TEXT = 'Where all firm intelligence is created, curated, and deployed';

export const TL_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'draft-content',
    icon: '✍️',
    title: 'Draft Content',
    description: 'Create articles, blogs, white papers, and podcasts'
  },
  {
    id: 'conduct-research',
    icon: '🔍',
    title: 'Conduct Research',
    description: 'Synthesize insights from multiple documents'
  },
  {
    id: 'edit-content',
    icon: '✏️',
    title: 'Edit Content',
    description: 'Align with PwC brand and style'
  },
  {
    id: 'refine-content',
    icon: '💎',
    title: 'Refine Content',
    description: 'Expand, compress, or adjust tone'
  },
  {
    id: 'format-translator',
    icon: '🔄',
    title: 'Format Translator',
    description: 'Convert between content formats'
  }
];

export const DDC_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'slide-creation-prompt',
    icon: '📝',
    // title: 'New Deck Development',
    title: 'Prompt to Draft',
    description: 'Quickly turn an objective or idea into a starter deck​'
  },
  {
    id: 'slide-creation',
    icon: '📚',
    // title: 'New Deck Development',
    title: 'Outline to Deck',
    description: 'Transform a detailed outline into a client-ready presentation'
  },
  {
    id: 'sanitization',
    //icon: '🔒',
    icon:'🧹',
    // title: 'Sanitization',
    title: 'Doc Sanitization',
    description: 'Remove sensitive data to create shareable documents'
  },
  // {
  //   id: 'brand-format',
  //   icon: '🎨',
  //   title: 'Template Conversion',
  //   description: 'Apply PwC brand guidelines and professional polish',
  //   disabled: true
  // },
  // {
  //   id: 'professional-polish',
  //   icon: '✨',
  //   title: 'Professional Polish',
  //   description: 'Enhance visuals and language quality'
  // },
  {
    id: 'client-customization',
    icon: '🎯',
    // title: 'Existing Deck Refinement',
    title: 'Draft Refinement',
    description: 'Edit existing documents with a few clicks​',
    disabled: true
  },
  // {
  //   id: 'rfp-response',
  //   icon: '📋',
  //   title: 'RFP Response',
  //   description: 'Customize presentations for RFPs'
  // },
  // {
  //   id: 'ddc-format-translator',
  //   icon: '🔄',
  //   title: 'Format Translator',
  //   description: 'Convert PPTX to case studies or podcasts',
  //   disabled: true
  // }
  // {
  //   id: 'slide-creation',
  //   icon: '➕',
  //   title: 'New Slide Creation',
  //   description: 'Generate slides from images or content'
  // }
];

export const MI_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'market-intelligence',
    icon: '🔍',
    title: 'Market Intelligence & Insights',
    description: 'Analyze market and prepare insights'
  },
  {
    id: 'conduct-research',
    icon: '🔍',
    title: 'Conduct Research',
    description: 'Analyze and synthesize research'
  },
  {
    id: 'target-industry-insights',
    icon: '📋',
    title: 'Generate Industry Insights',
    description: 'Target Industry Insights'
  },
  {
    id: 'prepare-client-meeting',
    icon: '📋',
    title: 'Prepare for Client Meeting',
    description: 'Prepare for a Client Meeting'
  },
  {
    id: 'create-pov',
    icon: '✏️',
    title: 'Create Point of View',
    description: 'Create a Point of View'
  },
  {
    id: 'gather-proposal-insights',
    icon: '📋',
    title: 'Gather Proposal Inputs',
    description: 'Gather Proposal Insights'
  },
];
