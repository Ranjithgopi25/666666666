/**
 * Shared utility functions for paragraph edit operations
 * Used by both Guided Journey and Quick Start flows
 * 
 * NOTE: splitIntoParagraphs() and createParagraphEditsFromComparison() logic
 * matches backend _split_into_paragraphs() and _create_paragraph_edits_from_comparison()
 * in edit_content_service.py for consistency
 */

import { ParagraphEdit } from '../models/message.model';

function normalizeForComparison(text: string): string {
  if (!text) {
    return '';
  }
  return text
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n');
}

export function validateStringEquality(original: string, edited: string): boolean {
  if (!original && !edited) {
    return true;
  }
  
  const normalizedOriginal = normalizeForComparison(original || '');
  const normalizedEdited = normalizeForComparison(edited || '');
  
  if (normalizedOriginal === normalizedEdited) {
    return true;
  }
  
  const escapedOriginal = normalizedOriginal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`^${escapedOriginal}$`, 'u');
  
  return pattern.test(normalizedEdited);
}

export function splitIntoParagraphs(content: string): string[] {
  if (!content || !content.trim()) {
    return [];
  }
  
  const paragraphs = content.split('\n\n').map(p => p.trim()).filter(p => p.length > 0);
  
  // If no double newlines found, treat entire content as single paragraph
  if (paragraphs.length === 0) {
    return [content.trim()];
  }
  
  return paragraphs;
}

/**
 * Create paragraph edits by comparing original and edited content
 * @param original - Original content text
 * @param edited - Edited content text
 * @param editorNames - Array of editor names to include in tags
 * @returns Array of ParagraphEdit objects
 */
export function createParagraphEditsFromComparison(
  original: string,
  edited: string,
  editorNames: string[]
): ParagraphEdit[] {
  if (!original || !original.trim()) {
    // If no original content, create edits from edited content only
    const editedParagraphs = splitIntoParagraphs(edited);
    return editedParagraphs.map((editedPara, i) => ({
      index: i,
      original: '',
      edited: editedPara,
      tags: editorNames.map(name => `${name} (Reviewed)`),
      approved: null
    }));
  }

  const originalParagraphs = splitIntoParagraphs(original);
  const editedParagraphs = splitIntoParagraphs(edited);
  
  const paragraphEdits: ParagraphEdit[] = [];
  const maxLen = Math.max(originalParagraphs.length, editedParagraphs.length);
  
  for (let i = 0; i < maxLen; i++) {
    const originalPara = (i < originalParagraphs.length && originalParagraphs[i]) ? originalParagraphs[i].trim() : '';
    const editedPara = (i < editedParagraphs.length && editedParagraphs[i]) ? editedParagraphs[i].trim() : '';
    const paragraphChanged = originalPara !== editedPara;

    const isIdentical = validateStringEquality(originalPara, editedPara);
    
    // Always include ALL editors that were used
    const tags = editorNames.map(editorName => {
      if (paragraphChanged) {
        return `${editorName} (Editorial rule)`;
      } else {
        return `${editorName} (Reviewed)`;
      }
    });
    
    paragraphEdits.push({
      index: i,
      original: originalPara,
      edited: editedPara,
      tags: tags,
      autoApproved: isIdentical,
      approved: isIdentical ? true : null
    });
  }
  
  return paragraphEdits;
}

/**
 * Check if all paragraphs have been decided (approved or declined)
 * @param paragraphEdits - Array of paragraph edits
 * @returns True if all paragraphs have been decided
 */
export function allParagraphsDecided(paragraphEdits: ParagraphEdit[]): boolean {
  const paragraphsForReview = paragraphEdits.filter(p => p.autoApproved !== true);
  return paragraphsForReview.length === 0 || 
         paragraphsForReview.every(p => p.approved !== null);
}

