import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import DOMPurify from 'dompurify';

/**
 * Configure DOMPurify globally to prevent XSS attacks
 * Allows safe SVG elements and attributes while blocking dangerous content
 */
DOMPurify.setConfig({
  ALLOWED_TAGS: ['svg', 'path', 'circle', 'rect', 'line', 'g', 'polyline', 'polygon', 'ellipse', 'text', 'tspan', 'use', 'defs', 'clipPath'],
  ALLOWED_ATTR: [
    'viewBox', 'width', 'height', 'd', 'cx', 'cy', 'r', 'x', 'y', 'x1', 'y1', 'x2', 'y2',
    'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'class',
    'transform', 'points', 'rx', 'ry', 'text-anchor', 'font-size', 'font-family',
    'font-weight', 'opacity', 'href', 'id', 'clip-path', 'preserveAspectRatio'
  ],
  KEEP_CONTENT: true,
  FORCE_BODY: false,
  RETURN_DOM: false
});

/**
 * Add DOMPurify hook to remove javascript: protocols from href and xlink:href
 * This provides defense-in-depth against XSS via SVG script elements
 */
DOMPurify.addHook('afterSanitizeAttributes', function(node) {
  if (node.nodeType === 1) { // Element node
    // Remove href with javascript: protocol
    if (node.getAttribute && node.getAttribute('href')) {
      const href = node.getAttribute('href');
      if (href && href.toLowerCase().includes('javascript:')) {
        node.removeAttribute('href');
      }
    }
    // Remove xlink:href with javascript: protocol
    if (node.getAttribute && node.getAttribute('xlink:href')) {
      const xlinkHref = node.getAttribute('xlink:href');
      if (xlinkHref && xlinkHref.toLowerCase().includes('javascript:')) {
        node.removeAttribute('xlink:href');
      }
    }
    // Remove any event handlers
    const attributes = Array.from(node.attributes || []);
    attributes.forEach((attr) => {
      if (attr.name.toLowerCase().startsWith('on')) {
        node.removeAttribute(attr.name);
      }
    });
  }
});

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
