export const environment = {
  production: false,
  authLogLevel: 'warn',
  apiUrl: 'http://localhost:8080',
  settingsUrl: '',
  issuer: 'https://login.microsoftonline.com/d4093791-9818-48dc-8880-35d134b8c79d/v2.0',
  clientId: '6e658362-b527-4141-8fa1-17c4ac17ce3d',
  scope: 'openid profile email',
  responseType: 'code',
  redirectUrl: '',
  postLogoutRedirectUri: '',
  useAuth: true,
  revokeTokenEndpoint: 'revokeToken',
  datadogApplicationId: '',
  datadogClientToken: ''
};
