// export const environment = {
//   production: true,
//   apiUrl: 'https://webapp-bsc-mcx.dev.ngc.pwcinternal.com'
// };
export const environment = {
  // production: false,
  // apiUrl: 'http://localhost:8000',
  production: true,
  authLogLevel: 'warn',
  apiUrl: 'https://webapp-bsc-mcx.dev.ngc.pwcinternal.com',
  settingsUrl: '',
  issuer: 'https://login.microsoftonline.com/d4093791-9818-48dc-8880-35d134b8c79d/v2.0',
  clientId: '6e658362-b527-4141-8fa1-17c4ac17ce3d',
  scope: 'openid profile email',
  responseType: 'code',
  redirectUrl: 'https://webapp-bsc-mcx.dev.ngc.pwcinternal.com',
  postLogoutRedirectUri: '',
  useAuth: true,
  revokeTokenEndpoint: 'revokeToken',
  datadogApplicationId: '',
  datadogClientToken: ''
};
